"""Recheck captured functional AVD evidence; this does not benchmark a phone."""
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPECTED_APK = "1a1be366b67a5158da241a7be662b9991c3d2c9a6805c2d4c99acbae6a0b7219"
EXPECTED_SOURCE = "8069aab8fec930d5ba4bbeb9985f6b44256ccd58cd56b127c2a6796c69d80b0b"


def read(name):
    return json.loads((HERE / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


components = read("final-components-report.json")
battery = read("final-battery-report.json")
interrupted = read("final-interruption-report.json")
single = read("final-single-scene-report.json")
events = [json.loads(line) for line in (HERE / "session-events.jsonl").read_text().splitlines()]
assertions = []


def check(name, condition):
    assertions.append({"name": name, "passed": bool(condition)})


for name, report in [("components", components), ("battery", battery), ("interruption", interrupted), ("single scene", single)]:
    check(name + " final build identity", report["sourceId"] == EXPECTED_SOURCE and report["appVersion"] == "2.0.0")

check("all five components complete", components["complete"] and components["plannedRuns"] == 5 and [r["kind"] for r in components["results"]] == list(range(5)))
for result in components["results"]:
    check(result["name"] + " load 1 passed", result["load"] == 1 and result["passed"] and result["complete"] and result["checks"] > 0 and result["failures"] == 0)

check("eight scenes complete", battery["complete"] and battery["plannedRuns"] == 8 and [r["configuration"]["scene"] for r in battery["results"]] == list(range(8)))
for result in battery["results"]:
    conf, metrics = result["configuration"], result["metrics"]
    prefix = conf["name"] + ": "
    check(prefix + "fixed measured configuration", conf["load"] == 1 and conf["resolutionScale"] == .75 and conf["seed"] == 37 and conf["warmupMs"] == 2000 and conf["requestedMeasurementMs"] == 12000)
    check(prefix + "native completion and intervals", result["complete"] and result["reason"] == "completed" and metrics["renderedCount"] > 1 and metrics["intervalCount"] == metrics["renderedCount"] - 1)
    check(prefix + "whole-window rate", metrics["elapsedNs"] > 0 and math.isclose(metrics["swapFps"], metrics["intervalCount"] * 1e9 / metrics["elapsedNs"], rel_tol=1e-12))
    check(prefix + "serials and sample integrity", metrics["firstSerial"] > 1 and metrics["lastSerial"] - metrics["firstSerial"] + 1 == metrics["renderedCount"] and metrics["invalidSamples"] == 0 and metrics["failedSwapCount"] == 0 and metrics["quantilesComplete"])
    check(prefix + "unavailable timing stays unavailable", metrics["presentedCount"] == 0 and metrics["presentationFps"] is None and metrics["gpuSamples"] == 0 and metrics["gpuMs"] is None)

original = HERE / "final-battery-report.json"
exported = HERE / "final-battery-exported.json"
digest = sha(original)
check("SAF export byte-for-byte equality", original.read_bytes() == exported.read_bytes())
check("SAF export valid JSON", read("final-battery-exported.json") == battery)
check("staged private export hash matches report", (HERE / "pending-export-sha256.txt").read_text().split()[0] == digest)
before_pid = (HERE / "export-before-kill-pid.txt").read_text().strip()
after_kill_pid = (HERE / "export-after-kill-pid.txt").read_text().strip()
recreated_pid = (HERE / "export-recreated-pid.txt").read_text().strip()
check("export survived app process death", bool(before_pid) and not after_kill_pid and bool(recreated_pid) and before_pid != recreated_pid)
check("pending export removed after successful SAF write", any(e.get("request", {}).get("save") == "export-after-save-files.txt" and "pending-export.data: No such file or directory" in e.get("result", {}).get("stderr", "") for e in events))
check("history lists saved battery after process recreation", "Ocho escenarios · 8 mediciones" in (HERE / "final-history.xml").read_text())
check("history reopened report screenshot retained", (HERE / "final-history-reopened.png").is_file())

pause_result = interrupted["results"][0]
pause_metrics = pause_result["metrics"]
check("HOME interruption is partial and persisted", not interrupted["complete"] and len(interrupted["results"]) == 1 and not pause_result["complete"] and pause_result["reason"] == "activity_or_surface_paused")
check("interrupted interval data is valid", pause_metrics["renderedCount"] > 1 and pause_metrics["intervalCount"] == pause_metrics["renderedCount"] - 1 and 0 < pause_metrics["measuredSeconds"] < 30 and pause_metrics["invalidSamples"] == 0)
check("additional single scene completed", single["complete"] and len(single["results"]) == 1 and single["results"][0]["reason"] == "completed")
check("no app ANR in collected event log", "x.lab.gaming" not in (HERE / "final-anr-events.txt").read_text())
check("no app crash in collected crash log", "x.lab.gaming" not in (HERE / "final-crash-log.txt").read_text())
check("owned emulator and ADB shut down normally", any(e.get("event") == "session_closed" for e in events))

apk = HERE.parents[1] / "dist" / "X-Gaming-Lab-2.0.0.apk"
if apk.exists():
    check("final APK bytes", sha(apk) == EXPECTED_APK)

evidence_files = ["final-components-report.json", "component-validation.json", "final-battery-report.json", "battery-validation.json", "final-battery-exported.json", "final-single-scene-report.json", "final-interruption-report.json", "final-components.png", "final-battery-start.png", "final-battery-native.png", "final-battery-result.png", "final-export-picker.png", "final-export-returned.png", "final-history.xml", "final-history-reopened.png", "final-interruption-result.png", "session-events.jsonl", "final-anr-events.txt", "final-crash-log.txt", "validate_evidence.py"]
report = {
    "schema": "x-gaming-lab-android-functional-validation-v2",
    "status": "passed" if all(a["passed"] for a in assertions) else "failed",
    "apkSha256": EXPECTED_APK,
    "sourceId": EXPECTED_SOURCE,
    "appVersion": "2.0.0",
    "package": "x.lab.gaming",
    "scope": "Functional execution on an owned AOSP Android 15/API35 x86_64 AVD using TCG and Google SwiftShader. No physical-phone FPS, real GPU timing, thermal endurance, or physical quantum performance conclusion.",
    "emulator": {"name": "XLab", "serial": "emulator-5556", "bootSeconds": 248.38, "earlyAdbRootUsed": False, "lateAdbRootPurpose": "Read own AVD app-private reports only, after framework was stable and component checks completed.", "displayHz": 60, "closedUtc": next(e["atUtc"] for e in reversed(events) if e.get("event") == "session_closed")},
    "componentVerification": {"load": 1, "complete": True, "count": 5, "checks": sum(r["checks"] for r in components["results"]), "failures": sum(r["failures"] for r in components["results"]), "components": [{k: r[k] for k in ["kind", "name", "load", "complete", "passed", "checks", "failures"]} for r in components["results"]]},
    "battery": {"complete": True, "scenes": 8, "load": 1, "resolutionScale": .75, "warmupMsPerScene": 2000, "requestedMeasurementMsPerScene": 12000, "measuredNativeFrames": sum(r["metrics"]["renderedCount"] for r in battery["results"]), "invalidSamples": sum(r["metrics"]["invalidSamples"] for r in battery["results"]), "failedSwaps": sum(r["metrics"]["failedSwapCount"] for r in battery["results"]), "presentationTimestampsAvailable": False, "gpuTimerAvailable": False, "instancingRouteObserved": battery["results"][0]["capabilities"]["renderer"]["graphics_route"]},
    "export": {"actualSafWriteVerified": True, "path": "/storage/emulated/0/Download/XGamingLab_1794209736963.json", "bytes": exported.stat().st_size, "sha256": digest, "byteIdenticalToPersistedReport": True, "processDeathRecoveryVerified": True, "pidBefore": before_pid, "pidAfterRecreation": recreated_pid, "pendingFileRemovedAfterSuccess": True},
    "history": {"reopenedAfterProcessRecreation": True, "batteryRunCountVisible": 8},
    "interruption": {"method": "HOME during 30-second MOBA test, then reopen task", "sessionComplete": interrupted["complete"], "reason": pause_result["reason"], "measuredNativeFrames": pause_metrics["renderedCount"], "validIntervals": pause_metrics["intervalCount"], "measuredSeconds": pause_metrics["measuredSeconds"], "partialResultsVisibleAndPersisted": True},
    "environmentIncidents": ["Early AOSP System UI startup ANR dialog was dismissed with Wait; phone/media startup ANRs and Bluetooth crash are recorded separately. No x.lab.gaming ANR or crash appears in collected logs.", "Initial DocumentsUI accessibility dump returned no XML; a later dump succeeded without reboot. Real SAF file export subsequently completed.", "First manual interruption attempt arrived after the 30-second scene completed due tool latency; this additional complete result is retained. A controlled short sequence subsequently verified genuine interruption."],
    "limitations": ["Only the x86_64 ABI ran on this emulator; ARM installation/device behavior requires a physical device or corresponding emulator.", "Software-emulator FPS and temperature values are not handset performance measurements. ADB/screenshot activity occurred during functional testing.", "No physical presentation timestamps or GPU timer were available; reports correctly serialize them as null rather than estimated values.", "This QA covers five components at load1 and eight scenes at load1. Larger loads, campaign order/statistics, and native correctness have separate host evidence; they were not rerun as Android performance tests here.", "CSV and HTML were not exported through SAF in this session; the real SAF test used JSON."],
    "assertions": assertions,
    "passedAssertions": sum(a["passed"] for a in assertions),
    "totalAssertions": len(assertions),
    "evidence": [{"file": name, "sha256": sha(HERE / name), "bytes": (HERE / name).stat().st_size} for name in evidence_files],
}
(HERE / "validation.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"status": report["status"], "assertions": len(assertions), "passed": report["passedAssertions"], "components": report["componentVerification"]["checks"], "scenes": 8, "frames": report["battery"]["measuredNativeFrames"], "exportSha256": digest}, indent=2))
if report["status"] != "passed":
    raise SystemExit(1)
