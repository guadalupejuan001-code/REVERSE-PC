package x.lab.gaming;

import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static x.lab.gaming.FrameStats.Metric.*;

/** Deterministic host tests, independent of Android/EGL and real-time scheduling. */
public final class FrameStatsTest {
    private static int checks;
    private static final long START=2_000_000_000L;

    public static void main(String[] args) throws Exception {
        if(args.length>0&&args[0].equals("--json")) {
            FrameStats s=new FrameStats(120);s.record(sample(1,START));s.record(sample(2,START+10_000_000L));
            System.out.println(new RunResult("MOBA \"test\"\n","coordinated",true,null,s.snapshot()).toJson());return;
        }
        startupAndExact120();
        slowSpikeAndOnePercentLow();
        missingAndDelayedPresentation();
        presentationValidation();
        asynchronousGpuAndDisjoint();
        malformedFramesAndFailedSwaps();
        componentMeansAndCounters();
        sourceStatesAreNotUniqueImages();
        resetsAndContextChanges();
        overflowAndSnapshotImmutability();
        nativeAbi(args.length==0?"native/lab_api.hpp":args[0]);
        jsonSafety();
        allocationFreeRecord();
        System.out.println("FrameStats: "+checks+" deterministic checks passed");
    }

    private static double[] sample(long serial,long end) {
        double[] m=new double[FrameStats.METRIC_COUNT];
        m[SERIAL]=serial;m[SOURCE_REVISION]=serial;m[BEGIN_NS]=end-4_000_000L;m[END_NS]=end;
        m[CPU_NS]=1_000_000L;m[QSSD_NS]=200_000L;m[VIRTUAL_GPU_NS]=300_000L;
        m[GEOMETRY_NS]=400_000L;m[DRAW_SUBMIT_NS]=500_000L;m[SWAP_NS]=600_000L;
        m[STATE_AGE_NS]=700_000L;m[INPUT_TO_SUBMIT_NS]=-1;
        m[GPU_NS]=-1;m[PRESENT_NS]=-1;m[PRESENT_ID]=-1;m[GPU_SAMPLE_ID]=-1;
        m[CONTEXT_GENERATION]=1;m[SWAP_SUCCEEDED]=1;m[BUDGET_NS]=1e9/120;
        m[OBJECTS]=100;m[TRIANGLES]=1200;m[DRAW_CALLS]=3;m[UPLOAD_BYTES]=240;
        m[WORK_ITEMS]=16;m[PHYSICS_STEPS]=1;
        m[RENDER_WIDTH]=960;m[RENDER_HEIGHT]=540;m[SURFACE_WIDTH]=1920;m[SURFACE_HEIGHT]=1080;
        return m;
    }

    private static void startupAndExact120() {
        FrameStats s=new FrameStats(120);
        FrameStats.Snapshot empty=s.snapshot();
        unavailable(empty.swapFps,"empty rate");unavailable(empty.frameMsP95,"empty quantile");
        unavailable(empty.gpuMs,"empty GPU");unavailable(empty.onePercentLow,"empty 1% low");
        s.record(sample(10,START));
        FrameStats.Snapshot first=s.snapshot();
        eq(1,first.renderedCount,"first completion");eq(0,first.intervalCount,"no invented first interval");
        unavailable(first.swapFps,"one completion has no rate");
        for(int i=1;i<=120;i++)s.record(sample(10+i,START+Math.round(i*1e9/120)));
        FrameStats.Snapshot r=s.snapshot();
        eq(121,r.renderedCount,"121 endpoints");eq(120,r.intervalCount,"120 intervals");
        close(120,r.swapFps,1e-12,"counts over full second");
        eq(1_000_000_000L,r.elapsedNs,"full second elapsed");
        eq(0,r.missedIntervals,"nanosecond rounding not a missed deadline");
        close(8.333333,r.frameMsP50,1e-9,"120 Hz median");
        close(8.333334,r.frameMsP99,1e-9,"120 Hz p99");
        close(120,r.sourceStateHz,1e-12,"source rate excludes baseline");
        unavailable(r.presentationFps,"no timestamps means no presented FPS");
        unavailable(r.gpuMs,"no query result means no GPU duration");
        close(0,r.presentationCoverage,0,"zero measured presentation coverage");
        eq(0,r.invalidMetricValues,"normal fixtures valid");
    }

    private static void slowSpikeAndOnePercentLow() {
        FrameStats s=new FrameStats(120);long end=START;s.record(sample(1,end));
        for(int i=1;i<=100;i++){end+=i==100?40_000_000L:8_000_000L;s.record(sample(i+1,end));}
        FrameStats.Snapshot r=s.snapshot();
        close(100/0.832,r.swapFps,1e-10,"rate is not arithmetic mean of instantaneous FPS");
        close(8,r.frameMsP50,0,"spike p50");close(8,r.frameMsP95,0,"spike p95");
        close(8,r.frameMsP99,0,"nearest-rank p99 excludes final worst 1% sample");
        close(40,r.maxFrameMs,0,"maximum spike");close(25,r.onePercentLow,0,"mean worst 1% reciprocal");
        close(.01,r.missedBudgetRatio,0,"one deadline miss among 100 intervals");
        double[] recent=r.recentFrameMs();eq(100,recent.length,"all short-run chart intervals");
        close(8,recent[0],0,"chart chronological first");close(40,recent[99],0,"chart chronological last");
        long sum=0;for(long count:r.histogramCounts())sum+=count;eq(100,sum,"histogram covers all intervals");
    }

    private static void missingAndDelayedPresentation() {
        FrameStats s=new FrameStats(120);
        double[] a=sample(101,START);a[PRESENT_SUPPORTED]=1;a[PRESENT_ID]=100;a[PRESENT_NS]=START-2_000_000L;
        a[PRESENT_PROCESSED]=50;a[PRESENT_PENDING]=3;s.record(a);
        double[] b=sample(102,START+10_000_000L);b[PRESENT_SUPPORTED]=1;b[PRESENT_ID]=101;
        b[PRESENT_NS]=START+1_000_000L;b[PRESENT_PROCESSED]=51;b[PRESENT_PENDING]=2;s.record(b);
        double[] c=sample(103,START+20_000_000L);c[PRESENT_SUPPORTED]=1;c[PRESENT_ID]=102;
        c[PRESENT_NS]=START+11_000_000L;c[PRESENT_PROCESSED]=52;c[PRESENT_PENDING]=1;s.record(c);
        FrameStats.Snapshot r=s.snapshot();
        eq(1,r.warmupPresentationSamples,"delayed warmup sample filtered by ID");
        eq(2,r.presentedCount,"two matched physical samples");close(100,r.presentationFps,0,"presentation clock rate");
        close(2.0/3,r.presentationCoverage,0,"coverage has successful submissions as denominator");
        eq(2,r.nativePresentProcessed,"native counter warmup baseline subtracted");
        eq(1,r.presentPending,"pending is a gauge");
        s.reset();s.record(sample(1,START));
        double[] no=sample(2,START+10_000_000L);no[PRESENT_SUPPORTED]=1;s.record(no);
        unavailable(s.snapshot().presentationFps,"extension support alone proves no presentation");
    }

    private static void presentationValidation() {
        FrameStats s=new FrameStats(120);s.record(sample(1,START));
        double[] b=sample(2,START+10_000_000L);b[PRESENT_SUPPORTED]=1;b[PRESENT_ID]=1;b[PRESENT_NS]=START+1_000_000L;s.record(b);
        double[] duplicate=sample(3,START+20_000_000L);duplicate[PRESENT_SUPPORTED]=1;
        duplicate[PRESENT_ID]=1;duplicate[PRESENT_NS]=START+1_000_000L;s.record(duplicate);
        double[] missing=sample(4,START+30_000_000L);missing[PRESENT_SUPPORTED]=1;
        missing[PRESENT_ID]=999;missing[PRESENT_NS]=START+21_000_000L;s.record(missing);
        double[] future=sample(5,START+40_000_000L);future[PRESENT_SUPPORTED]=1;
        future[PRESENT_ID]=2;future[PRESENT_NS]=START+99_000_000L;s.record(future);
        double[] old=sample(6,START+50_000_000L);old[PRESENT_SUPPORTED]=1;
        old[PRESENT_ID]=2;old[PRESENT_NS]=START;s.record(old);
        FrameStats.Snapshot r=s.snapshot();
        eq(1,r.presentedCount,"bad samples cannot invent presented frames");
        eq(1,r.duplicatePresentationSamples,"duplicate ID diagnosed");
        eq(1,r.unmatchedPresentationSamples,"unknown future ID diagnosed");
        eq(1,r.invalidPresentationSamples,"future time diagnosed");
        eq(1,r.outOfOrderPresentationSamples,"nonmonotonic physical timestamp diagnosed");
        unavailable(r.presentationFps,"one valid point insufficient");
    }

    private static void asynchronousGpuAndDisjoint() {
        FrameStats s=new FrameStats(120);
        double[] a=sample(101,START);a[GPU_TIMER_SUPPORTED]=1;a[GPU_NS]=99_000_000;
        a[GPU_SAMPLE_ID]=100;a[GPU_DISCARDED]=7;s.record(a);
        double[] b=sample(102,START+10_000_000);b[GPU_TIMER_SUPPORTED]=1;b[GPU_NS]=-1;
        b[GPU_DISCARDED]=8;s.record(b);
        unavailable(s.snapshot().gpuMs,"warmup and disjoint results excluded");
        double[] c=sample(103,START+20_000_000);c[GPU_TIMER_SUPPORTED]=1;c[GPU_NS]=2_000_000;
        c[GPU_SAMPLE_ID]=101;c[GPU_DISCARDED]=8;s.record(c);
        double[] d=sample(104,START+30_000_000);d[GPU_TIMER_SUPPORTED]=1;d[GPU_NS]=4_000_000;
        d[GPU_SAMPLE_ID]=102;d[GPU_DISCARDED]=8;s.record(d);
        double[] e=sample(105,START+40_000_000);e[GPU_TIMER_SUPPORTED]=1;e[GPU_NS]=9_000_000;
        e[GPU_SAMPLE_ID]=102;e[GPU_DISCARDED]=8;s.record(e);
        FrameStats.Snapshot r=s.snapshot();
        eq(2,r.gpuSamples,"two valid asynchronous query IDs");close(3,r.gpuMs,0,"GPU average uses valid queries only");
        eq(1,r.warmupGpuSamples,"warmup GPU query excluded");eq(1,r.duplicateGpuSamples,"duplicate query not counted");
        eq(1,r.gpuDiscarded,"disjoint native counter baseline removed");close(.4,r.gpuCoverage,0,"GPU sample coverage");
    }

    private static void malformedFramesAndFailedSwaps() {
        FrameStats s=new FrameStats(120);yes(!s.record(null),"null rejected");
        yes(!s.record(new double[3]),"short protocol rejected");
        s.record(sample(1,START));
        double[] bad=sample(2,START+10_000_000);bad[END_NS]=Double.NaN;
        yes(!s.record(bad),"NaN timestamp rejected");
        bad[END_NS]=START;yes(!s.record(bad),"backward/duplicate timestamp rejected");
        bad[END_NS]=0;yes(!s.record(bad),"zero timestamp rejected");
        s.record(sample(2,START+10_000_000));
        yes(!s.record(sample(2,START+20_000_000)),"duplicate serial rejected");
        yes(!s.record(sample(1,START+20_000_000)),"old serial rejected");
        double[] failed=sample(3,START+20_000_000);failed[SWAP_SUCCEEDED]=0;s.record(failed);
        s.record(sample(4,START+30_000_000));
        FrameStats.Snapshot r=s.snapshot();
        eq(4,r.attemptedCount,"valid attempts counted");eq(3,r.renderedCount,"failed swap excluded from successful frames");
        eq(2,r.intervalCount,"only consecutive successful endpoints");
        close(20,r.maxFrameMs,0,"failed swap gap remains in timing");eq(1,r.failedSwapCount,"failed swap visible");
        eq(7,r.invalidSamples,"all rejected samples diagnosed");
        eq(3,r.invalidTimestampSamples,"timestamp failure count");eq(1,r.duplicateSamples,"duplicate sample count");
    }

    private static void componentMeansAndCounters() {
        FrameStats s=new FrameStats(120);
        double[] a=sample(1,START);a[CACHE_HITS]=100;a[CACHE_MISSES]=20;
        a[PREPARED_REGIONS]=40;a[HOT_REGION_BUILDS]=10;a[INPUT_EVENTS]=5;s.record(a);
        double[] b=sample(2,START+10_000_000);b[CACHE_HITS]=103;b[CACHE_MISSES]=21;
        b[PREPARED_REGIONS]=44;b[HOT_REGION_BUILDS]=12;b[INPUT_EVENTS]=6;
        b[CPU_NS]=3_000_000;b[INPUT_TO_SUBMIT_NS]=8_000_000;s.record(b);
        FrameStats.Snapshot r=s.snapshot();
        close(2,r.cpuMs,0,"stage arithmetic duration mean");close(.2,r.qssdMs,1e-12,"QSSD duration");
        close(.3,r.virtualGpuMs,1e-12,"virtual executor duration");close(8,r.inputToSubmitMs,0,"absent input not averaged as zero");
        eq(3,r.cacheHits,"cache hit baseline");eq(1,r.cacheMisses,"cache miss baseline");
        eq(4,r.preparedRegions,"regions baseline");eq(2,r.hotRegionBuilds,"hot builds baseline");
        eq(1,r.inputEvents,"observed input timestamps baseline");eq(480,r.uploadBytes,"per-frame uploads summed");
        eq(32,r.workItems,"C12 per-frame lanes summed");eq(2,r.physicsSteps,"clock tick deltas summed");
        eq(100,r.objects,"latest objects");close(1200,r.trianglesMean,0,"mean triangles");
        double[] c=sample(3,START+20_000_000);c[CACHE_HITS]=1;c[CACHE_MISSES]=21;
        c[PREPARED_REGIONS]=44;c[HOT_REGION_BUILDS]=12;c[INPUT_EVENTS]=6;s.record(c);
        eq(1,s.snapshot().counterResets,"decreasing cumulative counter diagnosed");
        eq(3,s.snapshot().cacheHits,"reset cannot add negative or warmup counts");
    }

    private static void sourceStatesAreNotUniqueImages() {
        FrameStats s=new FrameStats(120);
        for(int i=0;i<=120;i++){double[] m=sample(i+1,START+Math.round(i*1e9/120));m[SOURCE_REVISION]=7;s.record(m);}
        FrameStats.Snapshot r=s.snapshot();eq(1,r.sourceStatesObserved,"one observed source state");
        eq(120,r.reusedSourceStates,"reused states separate from swaps");
        close(120,r.swapFps,1e-12,"same source can still render new camera images");
        close(0,r.sourceStateHz,0,"no source-state updates after baseline");
    }

    private static void resetsAndContextChanges() {
        FrameStats s=new FrameStats(120);s.record(sample(200,START));
        double[] changed=sample(201,START+10_000_000);changed[CONTEXT_GENERATION]=2;
        yes(!s.record(changed),"contexts not silently mixed");eq(1,s.snapshot().contextChanges,"context change reported");
        s.reset();s.record(sample(1,START+100_000_000));s.record(sample(2,START+108_000_000));
        FrameStats.Snapshot r=s.snapshot();eq(2,r.renderedCount,"reset clears old count");
        eq(0,r.invalidSamples,"reset clears diagnostics");eq(1,r.firstSerial,"new serial domain accepted");
        close(8,r.frameMsP99,0,"pause outside new measurement scope");
    }

    private static void overflowAndSnapshotImmutability() {
        FrameStats s=new FrameStats(120,2);long end=START;s.record(sample(1,end));
        for(int i=1;i<=3;i++){end+=i*10_000_000L;s.record(sample(i+1,end));}
        FrameStats.Snapshot r=s.snapshot();yes(!r.quantilesComplete,"overflow explicitly marked");
        eq(1,r.intervalOverflowCount,"one interval evicted");unavailable(r.frameMsP95,"no rolling quantile advertised as whole run");
        unavailable(r.onePercentLow,"no whole-run 1% low after overflow");
        close(50,r.swapFps,0,"whole count and elapsed retained");close(30,r.maxFrameMs,0,"whole maximum retained");
        double[] recent=r.recentFrameMs();eq(2,recent.length,"bounded chart ring");
        close(20,recent[0],0,"ring chronological oldest");close(30,recent[1],0,"ring chronological latest");
        recent[0]=999;close(20,r.recentFrameMs()[0],0,"immutable chart copy");
        long[] histogram=r.histogramCounts();long total=Arrays.stream(histogram).sum();eq(3,total,"histogram whole run not ring");
        histogram[0]=999;yes(r.histogramCounts()[0]!=999,"immutable histogram copy");
        s.reset();eq(4,r.renderedCount,"snapshot not attached to mutable accumulator");
    }

    private static void nativeAbi(String filename) throws Exception {
        String header=new String(Files.readAllBytes(Paths.get(filename)),StandardCharsets.UTF_8);
        for(java.lang.reflect.Field field:FrameStats.Metric.class.getFields()){
            Matcher m=Pattern.compile("\\b"+field.getName()+"\\s*=\\s*(\\d+)\\b").matcher(header);
            yes(m.find(),"native metric exists: "+field.getName());
            eq(field.getInt(null),Integer.parseInt(m.group(1)),"native metric ABI "+field.getName());
        }
        Matcher count=Pattern.compile("METRIC_COUNT\\s*=\\s*(\\d+)").matcher(header);
        yes(count.find(),"metric count declared");eq(FrameStats.METRIC_COUNT,Integer.parseInt(count.group(1)),"metric count ABI");
    }

    private static void jsonSafety() {
        FrameStats s=new FrameStats(120);
        String json=new RunResult("MOBA \"x\"\n\u0001","coordinated",false,"paused",s.snapshot()).toJson();
        yes(json.contains("MOBA \\\"x\\\"\\n\\u0001"),"JSON strings escaped");
        yes(json.contains("\"gpuMs\":null"),"unavailable GPU serializes as null");
        yes(json.contains("\"missedIntervals\":0"),"raw missed interval count exported");
        yes(!json.contains("NaN")&&!json.contains("Infinity"),"nonfinite tokens never emitted");
        yes(json.contains("\"completed\":false"),"canceled scope preserved");
    }

    private static void allocationFreeRecord() {
        java.lang.management.ThreadMXBean platform=ManagementFactory.getThreadMXBean();
        if(!(platform instanceof com.sun.management.ThreadMXBean)) {
            System.out.println("Allocation counter unavailable on this JVM; source hot-path review still applies.");return;
        }
        com.sun.management.ThreadMXBean bean=(com.sun.management.ThreadMXBean)platform;
        if(!bean.isThreadAllocatedMemorySupported()) {
            System.out.println("Thread allocation measurement unsupported on this JVM.");return;
        }
        bean.setThreadAllocatedMemoryEnabled(true);
        FrameStats s=new FrameStats(120);double[] m=sample(1,START);
        for(int i=1;i<=50_000;i++){
            m[SERIAL]=i;m[SOURCE_REVISION]=i;m[BEGIN_NS]=START+i*8_000_000L;
            m[END_NS]=m[BEGIN_NS]+4_000_000;s.record(m);
        }
        s.reset();long thread=Thread.currentThread().getId();long before=bean.getThreadAllocatedBytes(thread);
        for(int i=1;i<=20_000;i++){
            m[SERIAL]=i;m[SOURCE_REVISION]=i;m[BEGIN_NS]=START+i*8_000_000L;
            m[END_NS]=m[BEGIN_NS]+4_000_000;s.record(m);
        }
        long allocated=bean.getThreadAllocatedBytes(thread)-before;
        eq(0,allocated,"record with reused native array allocates zero bytes after warmup");
        System.out.println("FrameStats.record: "+allocated+" allocated bytes across 20000 reused-array records after JVM warmup");
    }

    private static void unavailable(double value,String name){yes(Double.isNaN(value),name+" unavailable");}
    private static void yes(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    private static void eq(long expected,long actual,String name){checks++;if(expected!=actual)
        throw new AssertionError(name+": expected "+expected+", got "+actual);}
    private static void close(double expected,double actual,double tolerance,String name){checks++;
        if(!Double.isFinite(actual)||Math.abs(expected-actual)>tolerance)
            throw new AssertionError(name+": expected "+expected+", got "+actual);}
}
