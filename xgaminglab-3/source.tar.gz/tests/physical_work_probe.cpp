#include "trabajo_fisico.hpp"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

int main(){
  xgpu::PhysicalWorkAuthority authority;
  std::vector<std::uint32_t> vertices{36,24};
  std::vector<xgpu::PhysicalCandidate> in{
    {1,10,20,0,10.f,8.f,true,true},
    {2,11,20,1,.25f,.25f,true,true},
    {3,12,21,0,0.f,0.f,false,false}
  };
  auto a=authority.plan(in,vertices,101,true,true,true,.5f,.5f);
  assert(a.source_objects==3);
  assert(a.camera_candidates==2 && a.shadow_candidates==2);
  assert(a.camera_indices.size()==1 && a.shadow_indices.size()==1);
  assert(a.camera_rejected==1 && a.shadow_rejected==1);
  assert(a.changed_objects==3 && a.reused_objects==0);
  assert(a.baseline_instance_bytes==4*112ULL);
  assert(a.planned_instance_bytes==2*44ULL);
  assert(a.camera_baseline_vertices==60 && a.shadow_baseline_vertices==60);
  assert(a.camera_planned_vertices==36 && a.shadow_planned_vertices==36);
  auto b=authority.plan(in,vertices,102,true,true,true,.5f,.5f);
  assert(b.changed_objects==0 && b.reused_objects==3);
  in[0].transform_revision++;
  auto c=authority.plan(in,vertices,103,false,true,false,.5f,.5f);
  assert(c.changed_objects==1 && c.reused_objects==2);
  assert(c.camera_indices.size()==2 && c.shadow_indices.size()==2);
  assert(c.planned_instance_bytes==4*112ULL);
  bool rejected=false;try{auto bad=in;bad[0].mesh=99;(void)authority.plan(bad,vertices,1,true,true,true);}catch(const std::out_of_range&){rejected=true;}
  assert(rejected);
  xgpu::PhysicalWorkAuthority billboards;
  std::vector<std::uint32_t> billboard_vertices{36,24,18,6};
  std::vector<xgpu::PhysicalCandidate> billboard{{9,1,1,3,12.f,0.f,true,false}};
  auto d=billboards.plan(billboard,billboard_vertices,1,true,true,true);
  assert(d.baseline_instance_bytes==112 && d.planned_instance_bytes==112);
  std::cout << "PhysicalWorkAuthority: 21 checks passed\n";
}
