#include "lab_api.hpp"
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

// Inject only a driver validity signal; timer commands and rendered pixels are real.
static bool inject_disjoint=false;
extern "C" void __real_glGetIntegerv(GLenum pname,GLint* value);
extern "C" void __wrap_glGetIntegerv(GLenum pname,GLint* value){
  if(pname==GL_GPU_DISJOINT_EXT&&inject_disjoint){*value=1;return;}
  __real_glGetIntegerv(pname,value);
}

namespace {
int checks=0;
void require(bool value,const char* message){++checks;if(!value)throw std::runtime_error(message);}
struct HostContext {
  EGLDisplay display=EGL_NO_DISPLAY;EGLContext context=EGL_NO_CONTEXT;EGLSurface surface=EGL_NO_SURFACE;EGLConfig config{};int width=0,height=0;
  HostContext(int w,int h){
    auto get_platform=reinterpret_cast<PFNEGLGETPLATFORMDISPLAYEXTPROC>(eglGetProcAddress("eglGetPlatformDisplayEXT"));
    display=get_platform?get_platform(0x31DD,EGL_DEFAULT_DISPLAY,nullptr):eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLint major=0,minor=0;require(display!=EGL_NO_DISPLAY&&eglInitialize(display,&major,&minor),"Initialize real surfaceless EGL");
    const EGLint attrs[]={EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_DEPTH_SIZE,16,EGL_NONE};EGLint count=0;
    require(eglChooseConfig(display,attrs,&config,1,&count)&&count==1,"Select GLES2 pbuffer configuration");
    require(eglBindAPI(EGL_OPENGL_ES_API),"Bind actual GLES API");const EGLint ctx[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE};context=eglCreateContext(display,config,EGL_NO_CONTEXT,ctx);require(context!=EGL_NO_CONTEXT,"Create GLES2 context");resize(w,h);
    const std::string version=reinterpret_cast<const char*>(glGetString(GL_VERSION));require(version.find("OpenGL ES 2.0")!=std::string::npos,"Probe must run on strict GLES2, not desktop GL");
  }
  void resize(int w,int h){
    eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);if(surface!=EGL_NO_SURFACE)eglDestroySurface(display,surface);
    const EGLint attrs[]={EGL_WIDTH,w,EGL_HEIGHT,h,EGL_NONE};surface=eglCreatePbufferSurface(display,config,attrs);require(surface!=EGL_NO_SURFACE&&eglMakeCurrent(display,surface,surface,context),"Attach replacement pbuffer to preserved context");width=w;height=h;
  }
  ~HostContext(){eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);if(surface!=EGL_NO_SURFACE)eglDestroySurface(display,surface);if(context!=EGL_NO_CONTEXT)eglDestroyContext(display,context);if(display!=EGL_NO_DISPLAY)eglTerminate(display);}
  std::vector<unsigned char> pixels(){std::vector<unsigned char> out(width*height*4);glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,out.data());require(glGetError()==GL_NO_ERROR,"Real framebuffer readback has no GL error");return out;}
};
xlab::Instance object(int mesh,float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,float alpha=1){
  xlab::Instance out;out.mesh=mesh;out.x=x;out.y=y;out.z=z;out.sx=sx;out.sy=sy;out.sz=sz;out.r=r;out.g=g;out.b=b;out.a=alpha;return out;
}
// Test-only geometry fixture. Production world state is exclusively Backend::sample.
xlab::Packet fixture(){
  xlab::Packet p;p.eye={9,10,13};p.look={0,.5,0};p.sun={-.8f,1,.35f};p.light_energy=1.15f;p.fog={.025f,.045f,.085f};
  p.objects.push_back(object(2,0,-.05,0,32,1,32,.31,.4,.46));p.objects.back().casts_shadow=false;
  p.objects.push_back(object(0,-2,1.2,0,2.4,2.4,2.4,.95,.22,.16));p.objects.back().yaw=.3f;
  p.objects.push_back(object(1,2,1.6,0,2.6,3.2,2.6,.12,.85,.65));
  p.objects.push_back(object(4,0,1,-3,2,2,2,.2,.48,.92));
  p.objects.push_back(object(3,0,3,2,3.2,3.2,1,1,.45,.1,.45));p.objects.back().casts_shadow=false;
  p.objects.push_back(object(3,0,3,-1,3.5,3.5,1,.1,.4,1,.5));p.objects.back().casts_shadow=false;
  return p;
}
std::size_t changed_pixels(const std::vector<unsigned char>& a,const std::vector<unsigned char>& b){
  require(a.size()==b.size(),"Comparable framebuffer dimensions");std::size_t changed=0;for(std::size_t i=0;i<a.size();i+=4)if(a[i]!=b[i]||a[i+1]!=b[i+1]||a[i+2]!=b[i+2])++changed;return changed;
}
void save_ppm(const std::filesystem::path& path,const std::vector<unsigned char>& pixels,int w,int h){
  std::ofstream out(path,std::ios::binary);out<<"P6\n"<<w<<' '<<h<<"\n255\n";
  for(int y=h-1;y>=0;--y)for(int x=0;x<w;++x)out.write(reinterpret_cast<const char*>(pixels.data()+(y*w+x)*4),3);
  require(bool(out),"Save image produced by actual renderer");
}
}
int main(int argc,char** argv){
  try{
    const std::filesystem::path output=argc>1?argv[1]:"build/graphics-probe";std::filesystem::create_directories(output);
    std::vector<unsigned char> first_image;std::string capabilities;std::size_t shadow_pixels=0,offscreen_shadow_pixels=0;int gpu_samples=0;
    for(int epoch=0;epoch<2;++epoch){
      HostContext context(320,240);xlab::Renderer renderer;renderer.initialize();renderer.resize(context.width,context.height);
      xlab::Config config;config.resolution=.75f;config.graphics_path=1;renderer.configure(config);auto packet=fixture();std::uint64_t serial=1;
      const auto initial=renderer.draw(packet,serial++);auto baseline=context.pixels();
      require(initial.width==240&&initial.height==180,"Resolution FBO is 75 percent of physical size");require(initial.bytes_uploaded>0,"Initial real mesh VBO upload reported");require(initial.draw_calls>7&&initial.triangles>100,"Shadow, scene and upscale commands actually execute");
      std::set<std::uint32_t> colors;for(std::size_t i=0;i<baseline.size();i+=4)colors.insert((baseline[i]<<16)|(baseline[i+1]<<8)|baseline[i+2]);require(colors.size()>300,"Rendered scene has spatial/color content, not a clear-only frame");
      if(epoch==0){first_image=baseline;save_ppm(output/"renderer-shadow.ppm",baseline,context.width,context.height);}else require(baseline==first_image,"Destroyed/recreated context renders identical pixels");
      const auto second=renderer.draw(packet,serial++);require(second.bytes_uploaded==0,"Meshes retained across frames without reupload");
      if(second.gpu_ns>=0){require(second.gpu_serial>0&&second.gpu_serial<serial-1,"Asynchronous GPU sample carries earlier original serial");++gpu_samples;}
      auto shadows_off=packet;for(auto& item:shadows_off.objects)item.casts_shadow=false;
      renderer.draw(shadows_off,serial++);const auto unshadowed=context.pixels();shadow_pixels=changed_pixels(baseline,unshadowed);require(shadow_pixels>100,"Actual directional shadows change real image pixels");
      if(epoch==0)save_ppm(output/"renderer-no-shadow.ppm",unshadowed,context.width,context.height);
      auto reversed=packet;std::swap(reversed.objects[4],reversed.objects[5]);renderer.draw(reversed,serial++);require(context.pixels()==baseline,"Alpha objects sorted by camera depth, independent of input ordering");
      auto without_alpha=packet;without_alpha.objects.resize(4);renderer.draw(without_alpha,serial++);require(changed_pixels(context.pixels(),baseline)>50,"Real alpha particles contribute visible pixels");
      auto outside=packet;outside.objects.push_back(object(0,10000,1,10000,2,2,2,1,0,1));const auto culled=renderer.draw(outside,serial++);require(culled.draw_calls==initial.draw_calls,"Out-of-frustum object excluded from camera and shadow draws");require(context.pixels()==baseline,"Culled object does not alter image");
      auto offscreen=packet;offscreen.objects.push_back(object(0,-12.8,16,5.6,4,3,4,1,0,1));
      const auto offscreen_draw=renderer.draw(offscreen,serial++);const auto shadow_from_outside=context.pixels();offscreen_shadow_pixels=changed_pixels(baseline,shadow_from_outside);
      require(offscreen_draw.draw_calls==initial.draw_calls+1,"Offscreen occluder adds a shadow pass draw but no camera draw");require(offscreen_shadow_pixels>100,"Object outside camera casts a visible directional shadow");
      offscreen.objects.back().casts_shadow=false;const auto hidden=renderer.draw(offscreen,serial++);require(hidden.draw_calls==initial.draw_calls,"Disabling offscreen caster removes only shadow draw");require(context.pixels()==baseline,"Offscreen caster was not visible camera geometry");
      if(epoch==0)save_ppm(output/"renderer-offscreen-shadow.ppm",shadow_from_outside,context.width,context.height);
      if(initial.gpu_timer_supported){inject_disjoint=true;const auto disjoint=renderer.draw(packet,serial++);inject_disjoint=false;require(disjoint.gpu_ns==-1&&disjoint.gpu_serial==0&&disjoint.gpu_discarded>0,"Disjoint signal discards actual pending GPU results instead of reporting CPU timing");}
      config.resolution=.5f;renderer.configure(config);const auto resized=renderer.draw(packet,1);require(resized.width==160&&resized.height==120,"Configure reallocates low resolution framebuffer");require(resized.gpu_ns==-1&&resized.gpu_serial==0,"Configure drops old asynchronous timer scope");context.pixels();
      context.resize(360,200);renderer.resize(context.width,context.height);const auto replacement=renderer.draw(packet,2);require(replacement.width==180&&replacement.height==100,"Preserved-context replacement surface resizes FBO");const auto wide=context.pixels();require(wide.size()==360*200*4,"New physical surface receives a full-size presentation pass");
      require(replacement.bytes_uploaded==0,"Surface replacement retains original mesh VBOs");
      if(epoch==0)save_ppm(output/"renderer-wide.ppm",wide,context.width,context.height);
      capabilities=renderer.capabilities();require(eglSwapBuffers(context.display,context.surface),"Actual pbuffer swap succeeds; no physical display claim");
    }
    std::cout<<"{\"suite\":\"xlab-gles2-renderer\",\"passed\":true,\"checks\":"<<checks<<",\"contexts\":2,\"shadow_pixels_changed\":"<<shadow_pixels<<",\"offscreen_shadow_pixels_changed\":"<<offscreen_shadow_pixels<<",\"gpu_samples_observed\":"<<gpu_samples<<",\"disjoint_signal_injected\":true,\"real_android_surface_tested\":false,\"physical_fps_claim\":false,\"renderer\":"<<capabilities<<"}\n";
  }catch(const std::exception& error){std::cerr<<"Renderer probe failed: "<<error.what()<<'\n';return 1;}
}
