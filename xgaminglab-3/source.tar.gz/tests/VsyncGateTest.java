package x.lab.gaming;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;

/** Constructed callback timestamps: scheduler logic, not a device FPS result. */
public final class VsyncGateTest {
    private static final long START=2_000_000_000L;
    private static int checks;

    public static void main(String[] args) {
        cadence(120,120,120);cadence(60,120,60);cadence(120,90,90);
        cadence(60,90,60);cadence(90,120,90);cadence(60,60,60);
        quantized60On90();roundingTolerance();missedAndBusyPeriods();
        invalidAndReset();longClockRanges();allocationFree();
        System.out.println("VsyncGate: "+checks+" deterministic checks passed");
    }

    private static void cadence(int target,int callbacks,int expectedIntervals) {
        VsyncGate g=new VsyncGate(target);List<Long> admitted=new ArrayList<>();
        for(int i=0;i<=callbacks;i++) {
            long t=START+Math.round(i*1e9/callbacks);
            if(g.shouldRender(t))admitted.add(t);
        }
        eq(expectedIntervals+1,admitted.size(),"inclusive one-second endpoints "+target+" on "+callbacks);
        eq(START,admitted.get(0),"first callback is baseline");
        eq(START+1_000_000_000L,admitted.get(admitted.size()-1),"last callback at one second");
        double fps=(admitted.size()-1)*1e9/(admitted.get(admitted.size()-1)-admitted.get(0));
        close(expectedIntervals,fps,"interval count over elapsed second");
    }

    private static void quantized60On90() {
        VsyncGate g=new VsyncGate(60);
        int[] expected={0,2,3,5,6,8,9};int next=0;
        for(int i=0;i<=9;i++)if(g.shouldRender(START+Math.round(i*1e9/90))) {
            eq(expected[next++],i,"60 on 90 uses available callback indices");
        }
        eq(expected.length,next,"all quantized callbacks observed");
    }

    private static void roundingTolerance() {
        VsyncGate g=new VsyncGate(120);yes(g.shouldRender(START),"baseline admitted");
        yes(!g.shouldRender(START+8_332_332L),"more than 1 us early rejected");
        yes(g.shouldRender(START+8_332_334L),"within 1 us early admitted");
        yes(!g.shouldRender(START+8_333_334L),"same period cannot be admitted twice");
        yes(g.shouldRender(START+16_666_666L),"sub-nanosecond rounded boundary admitted");
        VsyncGate stable=new VsyncGate(120);int count=0;
        for(int i=0;i<=36_000;i++)if(stable.shouldRender(START+Math.round(i*1e9/120)))count++;
        eq(36_001,count,"five minutes has no rounded-period drift");
    }

    private static void missedAndBusyPeriods() {
        VsyncGate g=new VsyncGate(60);g.shouldRender(START);
        yes(g.shouldRender(START+Math.round(1e9/60)),"busy worker still consumes due period");
        // Simulate caller dropping that request because the worker is busy.
        yes(!g.shouldRender(START+25_000_000L),"no intermediate catch-up after busy worker");
        yes(g.shouldRender(START+1_000_000_000L),"long gap admits one current callback");
        yes(!g.shouldRender(START+1_000_000_001L),"long gap does not cause catch-up burst");
        yes(g.shouldRender(START+1_016_666_667L),"original phase resumes after skipped periods");
    }

    private static void invalidAndReset() {
        VsyncGate g=new VsyncGate(60);
        yes(!g.shouldRender(0),"zero timestamp rejected");
        yes(!g.shouldRender(-1),"negative timestamp rejected");
        eq(2,g.invalidTimestampCount(),"invalid count");
        yes(g.shouldRender(START),"valid baseline after invalid timestamp");
        yes(!g.shouldRender(START),"duplicate timestamp rejected");
        eq(1,g.duplicateTimestampCount(),"duplicate count");
        yes(!g.shouldRender(START+1),"duplicate does not shift phase");
        yes(!g.shouldRender(START-10),"reverse timestamp rejected");
        eq(1,g.reversedTimestampCount(),"reverse count");
        yes(g.shouldRender(START-9),"valid callback after discontinuity starts new phase");
        g.reset();eq(0,g.invalidTimestampCount(),"explicit reset clears invalid diagnostics");
        eq(0,g.duplicateTimestampCount(),"explicit reset clears duplicate diagnostics");
        eq(0,g.reversedTimestampCount(),"explicit reset clears reverse diagnostics");
        yes(g.shouldRender(1),"reset accepts new positive clock domain");
        boolean threw=false;try{new VsyncGate(0);}catch(IllegalArgumentException expected){threw=true;}
        yes(threw,"invalid target rejected");
    }

    private static void longClockRanges() {
        VsyncGate g=new VsyncGate(120);yes(g.shouldRender(1),"small initial time");
        yes(g.shouldRender(Long.MAX_VALUE-2_000L),"huge gap cannot overflow phase calculation");
        yes(!g.shouldRender(Long.MAX_VALUE-1_999L),"huge clock no catch-up");
        VsyncGate dense=new VsyncGate(1_000_000_000);dense.shouldRender(1);
        yes(dense.shouldRender(Long.MAX_VALUE),"maximum target phase arithmetic stays in long range");
    }

    private static void allocationFree() {
        java.lang.management.ThreadMXBean platform=ManagementFactory.getThreadMXBean();
        if(!(platform instanceof com.sun.management.ThreadMXBean))return;
        com.sun.management.ThreadMXBean bean=(com.sun.management.ThreadMXBean)platform;
        if(!bean.isThreadAllocatedMemorySupported())return;
        bean.setThreadAllocatedMemoryEnabled(true);
        VsyncGate g=new VsyncGate(60);
        for(int i=0;i<50_000;i++)g.shouldRender(START+i*8_333_333L);
        g.reset();long id=Thread.currentThread().getId(),before=bean.getThreadAllocatedBytes(id);
        for(int i=0;i<20_000;i++)g.shouldRender(START+i*8_333_333L);
        long allocated=bean.getThreadAllocatedBytes(id)-before;
        eq(0,allocated,"gate allocates no objects per callback after warmup");
        System.out.println("VsyncGate.shouldRender: "+allocated+" allocated bytes across 20000 calls after JVM warmup");
    }

    private static void yes(boolean value,String message){checks++;if(!value)throw new AssertionError(message);}
    private static void eq(long expected,long actual,String message){checks++;if(expected!=actual)
        throw new AssertionError(message+": expected "+expected+", got "+actual);}
    private static void close(double expected,double actual,String message){checks++;if(Math.abs(expected-actual)>1e-9)
        throw new AssertionError(message+": expected "+expected+", got "+actual);}
}
