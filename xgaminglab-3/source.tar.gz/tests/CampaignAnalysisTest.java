package x.lab.gaming;

import java.util.Arrays;
import static x.lab.gaming.ComparisonAnalysis.*;

/** Constructed run results: verifies analysis, not device performance. */
public final class CampaignAnalysisTest {
    private static int checks;
    private static final Environment NORMAL=new Environment("phone/build",120,120,0,0,false);
    public static void main(String[] args) {
        if(args.length>0&&args[0].equals("--json")) {
            CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},1);
            Observation[] o={observation(0,1200,10_000_000_000L),observation(1,1000,10_000_000_000L)};
            System.out.println(analyze(p,o).toJson());return;
        }
        planOrder();pairedArithmetic();outlierRetention();mismatchesAndMissing();
        contextWarnings();unavailableMetrics();reconstructionAndImmutability();heuristics();
        System.out.println("Campaign analysis: "+checks+" deterministic checks passed");
    }

    private static Measurement.Builder measurement(long intervals,long elapsed) {
        return new Measurement.Builder().cadence(intervals+1,intervals,elapsed).targetHz(120)
                .dimensions(960,540,1920,1080).frameTimes(10,15,60)
                .stages(1,.2,.3,.4,.5,1,2).coverage(100,1,1).integrity(0,0,true);
    }
    private static Observation observation(int index,long intervals,long elapsed) {
        return new Observation(index,"build=2;seed=37;audio=false;input=auto",2000,10000,
                measurement(intervals,elapsed).build(),true,NORMAL);
    }
    private static Observation changed(Observation o,String key,long warm,long duration,Measurement m,
                                       boolean completed,Environment env) {
        return new Observation(o.entryIndex,key,warm,duration,m,completed,env);
    }
    private static Observation[] normalBlock() {
        return new Observation[]{observation(0,1200,10_000_000_000L),observation(1,1000,10_000_000_000L),
                observation(2,1000,20_000_000_000L),observation(3,1800,20_000_000_000L)};
    }
    private static void planOrder() {
        CampaignPlan p=CampaignPlan.scaleAbba(3,2);eq(40,p.runCount,"five loads, two ABBA blocks");
        eq(20,p.pairCount,"two pairs per ABBA block");
        for(int i=0;i<p.runCount;i++) {
            CampaignPlan.Entry e=p.entry(i);eq(i,e.index,"stable entry index");
            eq(i/8,e.load,"loads 0..4 in requested order");eq((i/4)%2,e.block,"block within load");
            yes(e.coordinated==(i%4==0||i%4==3),"ABBA mode order");
            eq((i/4)*2+(i%4>=2?1:0),e.pairIndex,"AB and BA pairing");
        }
        eq(560000,p.nominalDurationMs(2000,12000),"duration includes warmup for each run");
        CampaignPlan.Entry[] copy=p.entries();copy[0]=null;yes(p.entry(0)!=null,"plan array defensive copy");
        expectThrow(()->CampaignPlan.abba(new int[]{1,1},new int[]{0},1),"duplicate scenes rejected");
        expectThrow(()->CampaignPlan.abba(new int[]{1},new int[]{5},1),"unsupported load rejected");
        expectThrow(()->CampaignPlan.scaleAbba(1,0),"empty repetition rejected");
    }
    private static void pairedArithmetic() {
        CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},1);Observation[] o=normalBlock();
        Summary s=analyze(p,new Observation[]{o[3],o[1],o[0],o[2]});
        eq(2,s.usablePairs,"pair by declared identity, not observation array order");
        PairResult[] pairs=s.pairs();close(20,pairs[0].swapFpsChangePct,"AB relative change");
        close(80,pairs[1].swapFpsChangePct,"BA relative change has same A/B direction");
        GroupSummary g=s.groups()[0];close(50,g.swapFpsChangePct.mean,"mean of all paired changes");
        close(50,g.swapFpsChangePct.median,"median of paired changes");
        close(100,g.pooledSwapFpsA,"pooled A uses total intervals / total elapsed");
        close(2000/30.0,g.pooledSwapFpsB,"pooled B is not arithmetic mean 75 FPS");
        yes(!s.toJson().contains("\"pooledP99\""),"no fabricated pooled frame percentile");
        yes(s.spanishSummary().contains("Resumen descriptivo"),"Spanish summary includes limitation");
    }
    private static void outlierRetention() {
        CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},2);Observation[] o=new Observation[8];
        for(int i=0;i<o.length;i++)o[i]=observation(i,i==7?10000:1000,10_000_000_000L);
        Summary s=analyze(p,o);Changes c=s.groups()[0].swapFpsChangePct;
        eq(4,c.count,"all pairs including extreme value retained");close(225,c.mean,"extreme value affects mean");
        close(0,c.median,"median describes typical paired value");close(900,c.max,"extreme value remains visible");
        eq(8,s.observations().length,"all original runs retained");
    }
    private static void mismatchesAndMissing() {
        CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},1);Observation[] o=normalBlock();
        Observation b=o[1];o[1]=changed(b,"different-seed",b.warmupMs,b.requestedMeasurementMs,b.metrics,true,NORMAL);
        Summary s=analyze(p,o);eq(1,s.usablePairs,"configuration mismatch not pooled");
        yes(s.pairs()[0].reason.equals("configuration_mismatch"),"explicit mismatch reason");eq(4,s.observationCount,"mismatch result preserved");
        o=normalBlock();b=o[1];o[1]=changed(b,b.configurationKey,3000,10000,b.metrics,true,NORMAL);
        yes(analyze(p,o).pairs()[0].reason.equals("duration_or_warmup_mismatch"),"warmup mismatch checked explicitly");
        o=normalBlock();b=o[1];o[1]=changed(b,b.configurationKey,2000,12000,b.metrics,true,NORMAL);
        yes(analyze(p,o).pairs()[0].reason.equals("duration_or_warmup_mismatch"),"duration mismatch checked explicitly");
        o=normalBlock();b=o[1];o[1]=changed(b,b.configurationKey,2000,10000,
                measurement(1000,10_000_000_000L).dimensions(800,450,1920,1080).build(),true,NORMAL);
        yes(analyze(p,o).pairs()[0].reason.equals("resolution_mismatch"),"actual dimensions checked");
        o=normalBlock();b=o[1];o[1]=changed(b,b.configurationKey,2000,10000,b.metrics,false,NORMAL);
        yes(analyze(p,o).pairs()[0].reason.equals("incomplete_run"),"interrupted run preserved but not paired");
        o=normalBlock();s=analyze(p,new Observation[]{o[0],o[0],o[1],observation(999,1000,10_000_000_000L),null});
        eq(1,s.duplicateObservations,"duplicate observation diagnosed");eq(2,s.unexpectedObservations,"unplanned/null observations diagnosed");
        eq(2,s.missingRuns,"unobserved entries diagnosed");eq(0,s.usablePairs,"duplicates never choose the best result");
        eq(5,s.observations().length,"unexpected observations are not silently erased");
        yes(s.pairs()[0].reason.equals("duplicate_run"),"duplicate pair explicit");
        yes(s.pairs()[1].reason.equals("missing_run"),"missing pair explicit");
    }
    private static void contextWarnings() {
        CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},1);Observation[] o=normalBlock();
        Observation b=o[1];Environment hot=new Environment("phone/build",60,90,1,3,true);
        o[1]=changed(b,b.configurationKey,2000,10000,b.metrics,true,hot);
        Summary s=analyze(p,o);eq(2,s.usablePairs,"thermal/display contaminated pairs remain in descriptive summary");
        String[] w=s.pairs()[0].warnings();has(w,"thermal_context_differs");has(w,"severe_thermal_status_reported");
        has(w,"display_differs_between_runs");has(w,"display_changed_within_run");has(w,"power_save_differs");
        o[1]=changed(b,b.configurationKey,2000,10000,b.metrics,true,new Environment("other-device",120,120,0,0,false));
        yes(analyze(p,o).pairs()[0].reason.equals("device_mismatch"),"different known devices not pooled");
    }
    private static void unavailableMetrics() {
        CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},1);Observation[] o=normalBlock();Observation a=o[0];
        Measurement m=measurement(1200,10_000_000_000L).frameTimes(Double.NaN,Double.NaN,Double.NaN)
                .stages(1,.2,.3,.4,.5,1,Double.NaN).coverage(Double.NaN,0,0).integrity(0,0,false).build();
        o[0]=changed(a,a.configurationKey,2000,10000,m,true,NORMAL);Summary s=analyze(p,o);
        eq(2,s.usablePairs,"missing GPU/quantiles do not erase completion evidence");
        yes(Double.isNaN(s.pairs()[0].p99ChangePct),"missing percentile change unavailable");
        eq(1,s.groups()[0].p99ChangePct.count,"each metric states available pair count");
        yes(Double.isNaN(s.pairs()[0].presentationFpsChangePct),"missing presentation cannot become zero FPS");
        has(s.pairs()[0].warnings(),"gpu_timer_unavailable_or_partial");
        String json=s.toJson();yes(!json.contains("NaN")&&!json.contains("Infinity"),"strict JSON for unavailable values");
    }
    private static void reconstructionAndImmutability() {
        FrameStats stats=new FrameStats(120);double[] m=new double[FrameStats.METRIC_COUNT];m[FrameStats.Metric.GPU_NS]=-1;
        m[FrameStats.Metric.PRESENT_NS]=-1;m[FrameStats.Metric.SWAP_SUCCEEDED]=1;m[FrameStats.Metric.CONTEXT_GENERATION]=1;
        m[FrameStats.Metric.SERIAL]=1;m[FrameStats.Metric.BEGIN_NS]=1_000_000_000;m[FrameStats.Metric.END_NS]=1_001_000_000;stats.record(m);
        m[FrameStats.Metric.SERIAL]=2;m[FrameStats.Metric.BEGIN_NS]=1_010_000_000;m[FrameStats.Metric.END_NS]=1_011_000_000;stats.record(m);
        Measurement reconstructed=Measurement.fromSnapshot(stats.snapshot());close(100,reconstructed.swapFps(),"snapshot adapts to primitive domain");
        Measurement.Builder builder=measurement(1200,10_000_000_000L);Measurement immutable=builder.build();
        builder.cadence(2,1,1);close(120,immutable.swapFps(),"builder cannot mutate built measurement");
        CampaignPlan p=CampaignPlan.abba(new int[]{1},new int[]{2},1);Summary s=analyze(p,normalBlock());
        PairResult[] copy=s.pairs();copy[0]=null;yes(s.pairs()[0]!=null,"pair array defensive copy");
        Observation[] observations=s.observations();observations[0]=null;yes(s.observations()[0]!=null,"observation array defensive copy");
    }
    private static void heuristics() {
        Measurement m=measurement(1000,20_000_000_000L).stages(1,.2,.3,.4,.5,15,Double.NaN)
                .coverage(Double.NaN,0,0).build();
        BottleneckAnalysis.Result h=BottleneckAnalysis.inspect(m,NORMAL,true);
        yes(h.candidate.equals("swap_wait_candidate"),"swap wait does not prove GPU bottleneck");
        yes(h.confidence.equals("heuristic"),"explicit heuristic confidence");
        m=measurement(1000,20_000_000_000L).stages(1,.2,.3,.4,.5,2,15).build();
        yes(BottleneckAnalysis.inspect(m,NORMAL,true).candidate.equals("physical_gpu_candidate"),"covered GPU time can identify candidate");
        m=measurement(1000,20_000_000_000L).stages(1,.2,.3,.4,.5,2,15).coverage(100,1,.2).build();
        yes(!BottleneckAnalysis.inspect(m,NORMAL,true).candidate.equals("physical_gpu_candidate"),"low coverage cannot assert GPU candidate");
        m=measurement(1000,20_000_000_000L).stages(1,.2,15,.4,.5,2,1).build();
        yes(BottleneckAnalysis.inspect(m,NORMAL,true).candidate.equals("virtual_gpu_cpu_candidate"),"GPU Virtual labeled CPU execution");
        h=BottleneckAnalysis.inspect(new Measurement.Builder().build(),null,true);
        yes(h.candidate.equals("insufficient_data"),"empty data has no invented bottleneck");
        yes(h.toJson().contains("\"meanFrameMs\":null"),"unavailable heuristic evidence is null");
    }
    private static void has(String[] values,String value){yes(Arrays.asList(values).contains(value),"warning: "+value);}
    private static void expectThrow(Runnable task,String name){boolean threw=false;try{task.run();}catch(IllegalArgumentException expected){threw=true;}yes(threw,name);}
    private static void yes(boolean value,String name){checks++;if(!value)throw new AssertionError(name);}
    private static void eq(long expected,long actual,String name){checks++;if(expected!=actual)throw new AssertionError(name+": "+expected+" != "+actual);}
    private static void close(double expected,double actual,String name){checks++;if(!Double.isFinite(actual)||Math.abs(expected-actual)>1e-8)
        throw new AssertionError(name+": "+expected+" != "+actual);}
}
