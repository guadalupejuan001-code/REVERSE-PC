#!/usr/bin/env bash
set -euo pipefail
stats_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
stats_classes="$(mktemp -d)"
trap 'rm -rf -- "$stats_classes"' EXIT
"${FRAME_STATS_JAVAC:-javac}" -encoding UTF-8 -d "$stats_classes" \
  "$stats_root/src/x/lab/gaming/FrameStats.java" \
  "$stats_root/src/x/lab/gaming/RunResult.java" \
  "$stats_root/tests/FrameStatsTest.java"
"${FRAME_STATS_JAVA:-java}" -cp "$stats_classes" x.lab.gaming.FrameStatsTest "$stats_root/native/lab_api.hpp"
"${FRAME_STATS_JAVA:-java}" -cp "$stats_classes" x.lab.gaming.FrameStatsTest --json > "$stats_classes/result.json"
python3 - "$stats_classes/result.json" <<'PY'
import json
import sys
with open(sys.argv[1], encoding='utf-8') as source:
    result = json.load(source, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
assert result['metrics']['gpuMs'] is None
assert result['metrics']['renderedCount'] == 2
assert result['metrics']['histogramUpperMs'][-1] is None
assert result['scene'] == 'MOBA "test"\n'
print('RunResult: independent JSON parser accepted escaped metadata and unavailable metrics')
PY
