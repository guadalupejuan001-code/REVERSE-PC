#include "component_lab.hpp"
#include "qssd/c12_bridge.hpp"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>
#include <unistd.h>
using namespace xlab;
int main(int argc, char **argv) {
  char pattern[] = "build/component-lab-test-XXXXXX";
  char *directory = ::mkdtemp(pattern);
  if (!directory) {
    std::cerr << "temporary directory unavailable\n";
    return 2;
  }
  try {
    if (argc == 2 && std::string(argv[1]) == "--capabilities") {
      std::cout << component_capabilities() << '\n';
      ::rmdir(directory);
      return 0;
    }
    std::uint64_t checks = 0;
    for (int kind = 0; kind < 5; ++kind)
      for (int load = 0; load < 5; ++load) {
        ComponentRequest q;
        q.kind = kind;
        q.load = load;
        q.directory = directory;
        auto r = run_component(q);
        checks += r.checks;
        std::cout << r.json() << '\n';
        if (!r.passed)
          throw std::runtime_error("component " + std::to_string(kind) +
                                   " load " + std::to_string(load) + " failed");
        if (r.checks == 0 || r.work_items == 0)
          throw std::runtime_error("empty diagnostic");
        if (load == 0) {
          auto repeated = run_component(q);
          if (!repeated.passed || repeated.checksum != r.checksum)
            throw std::runtime_error("non-deterministic diagnostic checksum");
        }
      }
    // Actual production circuit adapter, with the T gate removed only here:
    // the original quantum observable and the CPU-authored field must change.
    qssd::Space with_phase, without_phase;
    auto phased = prepare_scene_quantum(with_phase, 37, true);
    auto no_phase = prepare_scene_quantum(without_phase, 37, false);
    if (std::abs(phased.xx - std::sqrt(.5)) > 2e-12 || no_phase.xx != 1 ||
        phased.projected_q10 == no_phase.projected_q10 || phased.gates != 1001 ||
        no_phase.gates != 1000 || phased.qubits != 1000)
      throw std::runtime_error("scene quantum circuit causality failed");
    for (auto *s : {&with_phase, &without_phase}) {
      s->execute_cpu("#!reverse-pc-machine-v1\nload32 r0 4112\nadd r0 "
                     "37\nstore32 4096 r0\nstore32 4100 97\nhalt\n");
      s->publish_cpu_rule("causal", 64, "4096", 2);
      s->bind("gpu:causal", "causal");
    }
    if (with_phase.observe("gpu:causal", 0) ==
        without_phase.observe("gpu:causal", 0))
      throw std::runtime_error("quantum gate did not change CPU/QSSD field");
    using O = xgpu::StateOp;
    xgpu::Kernel k{
        {{O::Index, 0}, {O::LoadGlobal, 1, 0}, {O::Output, 1}, {O::Halt}}};
    qssd::C12Window a(with_phase.acquire("gpu:causal")),
        b(without_phase.acquire("gpu:causal"));
    auto ai = a.enqueue(k, 64), bi = b.enqueue(k, 64);
    if (!a.run() || !b.run() ||
        a.engine().dispatch(ai).output->at(0) ==
            b.engine().dispatch(bi).output->at(0))
      throw std::runtime_error(
          "quantum gate did not change GPU Virtual output");
    ComponentRequest invalid;
    invalid.kind = 9;
    invalid.directory = directory;
    if (run_component(invalid).passed)
      throw std::runtime_error("invalid component accepted");
    invalid.kind = QSSD;
    invalid.directory = "";
    if (run_component(invalid).passed)
      throw std::runtime_error("missing real checkpoint directory accepted");
    ::rmdir(directory);
    std::cerr << "PASS all25 component/load combinations, " << checks
              << " component checks, deterministic repeats, circuit-removal "
                 "causality and invalid-input cases\n";
    return 0;
  } catch (const std::exception &e) {
    ::rmdir(directory);
    std::cerr << "FAIL " << e.what() << '\n';
    return 1;
  }
}
