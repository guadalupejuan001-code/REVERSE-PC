#!/usr/bin/env bash
set -euo pipefail
gate_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
gate_classes="$(mktemp -d)"
trap 'rm -rf -- "$gate_classes"' EXIT
"${FRAME_STATS_JAVAC:-javac}" -encoding UTF-8 -d "$gate_classes" \
  "$gate_root/src/x/lab/gaming/VsyncGate.java" \
  "$gate_root/tests/VsyncGateTest.java"
"${FRAME_STATS_JAVA:-java}" -cp "$gate_classes" x.lab.gaming.VsyncGateTest
