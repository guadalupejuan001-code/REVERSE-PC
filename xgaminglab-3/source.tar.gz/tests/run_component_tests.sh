#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
python3 scripts/prepare_vendor.py
mkdir -p build
${CXX:-g++} -std=c++20 -O2 -pthread -DREVERSE_PC_HAVE_BOUNDED_PRODUCT_IMPORT=1 \
 -Ibuild/qssd-compat -Ibuild/ether-compat -Ivendor/mundo/native/include \
 -Ivendor/reverse/src -Ivendor/qssd/include -Ivendor/gpu/include -Inative \
 native/component_lab.cpp tests/component_lab_test.cpp -o build/component_lab_test
./build/component_lab_test
