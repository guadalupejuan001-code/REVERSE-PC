#include "lab_api.hpp"
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
int checks=0;
void require(bool condition,const char* message){++checks;if(!condition)throw std::runtime_error(message);}
struct Egl {
  EGLDisplay display=EGL_NO_DISPLAY;EGLContext context=EGL_NO_CONTEXT;EGLSurface surface=EGL_NO_SURFACE;
  Egl(){
    auto platform=reinterpret_cast<PFNEGLGETPLATFORMDISPLAYEXTPROC>(eglGetProcAddress("eglGetPlatformDisplayEXT"));require(platform,"Surfaceless EGL API present");display=platform(0x31DD,EGL_DEFAULT_DISPLAY,nullptr);require(eglInitialize(display,nullptr,nullptr),"Initialize real Mesa EGL");
    EGLConfig config{};EGLint count=0;const EGLint attrs[]={EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_DEPTH_SIZE,16,EGL_NONE};require(eglChooseConfig(display,attrs,&config,1,&count)&&count==1,"Choose GLES2 framebuffer");
    const EGLint ctx[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE},buf[]={EGL_WIDTH,480,EGL_HEIGHT,270,EGL_NONE};require(eglBindAPI(EGL_OPENGL_ES_API),"Select GLES API");context=eglCreateContext(display,config,EGL_NO_CONTEXT,ctx);surface=eglCreatePbufferSurface(display,config,buf);require(context!=EGL_NO_CONTEXT&&surface!=EGL_NO_SURFACE&&eglMakeCurrent(display,surface,surface,context),"Create real GLES2 surface");
    require(std::string(reinterpret_cast<const char*>(glGetString(GL_VERSION))).find("OpenGL ES 2.0")!=std::string::npos,"Strict GLES2 runtime");
  }
  ~Egl(){eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);eglDestroySurface(display,surface);eglDestroyContext(display,context);eglTerminate(display);}
  std::vector<unsigned char> pixels(){std::vector<unsigned char> image(480*270*4);glReadPixels(0,0,480,270,GL_RGBA,GL_UNSIGNED_BYTE,image.data());require(glGetError()==GL_NO_ERROR,"Read actual native game pixels");return image;}
};
void save(const std::filesystem::path& path,const std::vector<unsigned char>& image){
  std::ofstream file(path,std::ios::binary);file<<"P6\n480 270\n255\n";for(int y=269;y>=0;--y)for(int x=0;x<480;++x)file.write(reinterpret_cast<const char*>(image.data()+(y*480+x)*4),3);require(bool(file),"Save original-backend render capture");
}
}
struct Difference {double mean=0,fraction_over_two=0;int maximum=0;};
Difference compare_pixels(const std::vector<unsigned char>& a,const std::vector<unsigned char>& b){
  require(a.size()==b.size(),"Comparable framebuffer size");std::uint64_t sum=0;std::size_t large=0;Difference out;
  for(std::size_t i=0;i<a.size();i+=4){bool over=false;for(int c=0;c<3;++c){const int delta=std::abs(int(a[i+c])-int(b[i+c]));sum+=delta;over|=delta>2;out.maximum=std::max(out.maximum,delta);}large+=over;}
  out.mean=double(sum)/(a.size()/4*3);out.fraction_over_two=double(large)/(a.size()/4);return out;
}
int main(int argc,char** argv){
  try{
    const std::filesystem::path path=argc>1?argv[1]:"build/graphics-probe";std::filesystem::create_directories(path);Egl egl;xlab::Renderer renderer;renderer.initialize();renderer.resize(480,270);std::vector<std::string> rows;
    const char* names[]={"calibration","moba","open-world","fighting","shooter","racing","effects","offscreen"};
    for(int load:{1,4})for(int scene=0;scene<8;++scene){
      xlab::Backend coordinated,direct;xlab::Config a;a.scene=scene;a.load=load;a.coordinated=true;a.resolution=.75f;xlab::Config b=a;b.coordinated=false;
      constexpr std::int64_t origin=1000000000LL;coordinated.configure(a,origin);direct.configure(b,origin);
      const auto now=origin+(scene==xlab::OFFSCREEN?14000000000LL:2500000000LL);
      const auto state_a=coordinated.sample(now,{}),state_b=direct.sample(now,{});
      require(state_a.state_hash==state_b.state_hash&&state_a.objects.size()==state_b.objects.size(),"A/B world comes from identical original-component state");
      require(state_a.cpu_ns>=0&&state_a.qssd_ns>=0&&state_a.virtual_gpu_ns>=0&&state_a.work_items>0,"Real CPU, QSSD and C12 work produces the scene");
      xlab::Config reference_config=a;reference_config.graphics_path=1;renderer.configure(reference_config);const auto reference_stats=renderer.draw(state_a,1);const auto reference_pixels=egl.pixels();
      renderer.configure(a);const auto stats=renderer.draw(state_a,1);const auto pixels_a=egl.pixels();renderer.configure(b);renderer.draw(state_b,1);const auto pixels_b=egl.pixels();
      require(pixels_a==pixels_b,"Coordinated and direct modes render bit-identical real pixels at identical source time");require(stats.width==360&&stats.height==203,"Original scenes pass through requested low-resolution FBO");require(stats.draw_calls>2&&stats.triangles>2,"Original scene objects reach real graphics draws");
      const auto auto_delta=compare_pixels(reference_pixels,pixels_a);require(auto_delta.mean<=.1&&auto_delta.fraction_over_two<=.002,"Auto/reference image difference is limited to defined numeric raster tolerance");
      require(stats.camera_instances==reference_stats.camera_instances&&stats.shadow_instances==reference_stats.shadow_instances&&stats.triangles==reference_stats.triangles,"Auto route preserves original scene and shadow geometry");
      std::ostringstream routes;routes<<"[{\"path\":0,\"draw_calls\":"<<stats.draw_calls<<",\"mean_rgb_error_255\":"<<auto_delta.mean<<",\"fraction_pixels_error_over_2\":"<<auto_delta.fraction_over_two<<",\"max_channel_error_255\":"<<auto_delta.maximum<<"}";
      for(int route:{2,3}){
        auto route_config=a;route_config.graphics_path=route;renderer.configure(route_config);const auto route_stats=renderer.draw(state_a,1);const auto delta=compare_pixels(reference_pixels,egl.pixels());
        require(route_stats.camera_instances==reference_stats.camera_instances&&route_stats.shadow_instances==reference_stats.shadow_instances&&route_stats.triangles==reference_stats.triangles,"Every route preserves original scene and shadow geometry");
        require(delta.mean<=.1&&delta.fraction_over_two<=.002,"Every route meets defined reference-image numeric tolerance");
        routes<<",{\"path\":"<<route<<",\"draw_calls\":"<<route_stats.draw_calls<<",\"mean_rgb_error_255\":"<<delta.mean<<",\"fraction_pixels_error_over_2\":"<<delta.fraction_over_two<<",\"max_channel_error_255\":"<<delta.maximum<<"}";
      }
      routes<<']';
      std::set<unsigned> colors;for(std::size_t i=0;i<pixels_a.size();i+=4)colors.insert((pixels_a[i]<<16)|(pixels_a[i+1]<<8)|pixels_a[i+2]);require(colors.size()>80,"Original scene has visible pixel detail");save(path/(std::string("scene-")+names[scene]+(load==4?"-massive":"")+".ppm"),pixels_a);
      std::ostringstream row;row<<"{\"name\":\""<<names[scene]<<"\",\"load\":"<<load<<",\"objects\":"<<state_a.objects.size()<<",\"camera_instances\":"<<stats.camera_instances<<",\"shadow_instances\":"<<stats.shadow_instances<<",\"triangles\":"<<stats.triangles<<",\"reference_draw_calls\":"<<reference_stats.draw_calls<<",\"auto_draw_calls\":"<<stats.draw_calls<<",\"distinct_colors\":"<<colors.size()<<",\"ab_pixels_equal\":true,\"routes\":"<<routes.str()<<"}";rows.push_back(row.str());
      std::cerr<<names[scene]<<" load="<<load<<" objects="<<state_a.objects.size()<<" draws="<<reference_stats.draw_calls<<" -> "<<stats.draw_calls<<" mean="<<auto_delta.mean<<'\n';
    }
    std::cout<<"{\"suite\":\"original-backend-to-real-gles2-v2\",\"scenes\":[";for(std::size_t i=0;i<rows.size();++i){if(i)std::cout<<',';std::cout<<rows[i];}
    std::cout<<"],\"passed\":true,\"checks\":"<<checks<<",\"physical_fps_claim\":false,\"android_surface_tested\":false}\n";
  }catch(const std::exception& e){std::cerr<<"Original renderer probe failed: "<<e.what()<<'\n';return 1;}
}
