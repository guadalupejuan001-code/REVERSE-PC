#!/usr/bin/env bash
set -euo pipefail
campaign_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
campaign_classes="$(mktemp -d)"
trap 'rm -rf -- "$campaign_classes"' EXIT
"${FRAME_STATS_JAVAC:-javac}" -encoding UTF-8 -d "$campaign_classes" \
  "$campaign_root/src/x/lab/gaming/FrameStats.java" \
  "$campaign_root/src/x/lab/gaming/CampaignPlan.java" \
  "$campaign_root/src/x/lab/gaming/ComparisonAnalysis.java" \
  "$campaign_root/src/x/lab/gaming/BottleneckAnalysis.java" \
  "$campaign_root/tests/CampaignAnalysisTest.java"
"${FRAME_STATS_JAVA:-java}" -cp "$campaign_classes" x.lab.gaming.CampaignAnalysisTest
"${FRAME_STATS_JAVA:-java}" -cp "$campaign_classes" x.lab.gaming.CampaignAnalysisTest --json > "$campaign_classes/comparison.json"
python3 - "$campaign_classes/comparison.json" <<'PY'
import json
import sys
with open(sys.argv[1], encoding='utf-8') as source:
    result = json.load(source, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
assert result['schema'] == 'x-gaming-lab-comparison-v2'
assert result['usablePairs'] == 1
assert result['pairs'][1]['reason'] == 'missing_run'
assert result['pairs'][1]['swapFpsChangePct'] is None
assert len(result['observations']) == 2
assert abs(result['groups'][0]['swapFpsChangePct']['mean'] - 20) < 1e-9
print('Campaign JSON: independent parser accepted preserved observations, pairing, nulls and grouped arithmetic')
PY
