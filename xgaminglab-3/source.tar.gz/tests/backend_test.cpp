#include "lab_api.hpp"
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <string>
using namespace xlab;
namespace {
int checks = 0;
void check(bool v, const char *why) {
  ++checks;
  if (!v)
    throw std::runtime_error(why);
}
std::int64_t at(int ticks) {
  return 1000000000LL + (std::int64_t(ticks) * 1000000000LL + 119) / 120;
}
void same(const Packet &a, const Packet &b) {
  check(a.state_hash == b.state_hash, "visible hash differs");
  check(a.objects.size() == b.objects.size(), "object count differs");
  check(a.source_revision == b.source_revision, "world revision differs");
  check(a.eye == b.eye && a.look == b.look && a.sun == b.sun,
        "camera/light differs");
  for (std::size_t i = 0; i < a.objects.size(); ++i) {
    const auto &x = a.objects[i];
    const auto &y = b.objects[i];
    check(x.x == y.x && x.y == y.y && x.z == y.z && x.sx == y.sx &&
              x.sy == y.sy && x.sz == y.sz && x.yaw == y.yaw && x.r == y.r &&
              x.g == y.g && x.b == y.b && x.a == y.a && x.mesh == y.mesh &&
              x.casts_shadow == y.casts_shadow,
          "instance differs");
  }
}
const Instance &ball(const Packet &p) {
  for (const auto &o : p.objects)
    if (o.mesh == 1 && o.x == 0 && o.z == 58 && o.sx == .6f)
      return o;
  throw std::runtime_error("missing ballistic object");
}
const Instance &hero(const Packet &p) {
  for (const auto &o : p.objects)
    if (o.mesh == 1 && o.sx == 1.2f && o.sy == 2.2f && o.sz == 1.2f)
      return o;
  throw std::runtime_error("missing controlled hero");
}
} // namespace
int main(int argc, char **argv) {
  try {
    if (argc == 2 && std::string(argv[1]) == "--provenance") {
      Backend b;
      Config c;
      c.scene = OFFSCREEN;
      b.configure(c, at(0));
      b.sample(at(120), {});
      std::cout << b.provenance() << "\n";
      return 0;
    }
    for (int scene = 0; scene < 8; ++scene)
      for (int load = 0; load < 5; ++load) {
        Backend a, b;
        Config ca;
        ca.scene = scene;
        ca.load = load;
        ca.coordinated = true;
        Config cb = ca;
        cb.coordinated = false;
        a.configure(ca, at(0));
        b.configure(cb, at(0));
        Input in;
        for (int tick : {0, 1, 15, 120, 480, 960, 1440, 2400}) {
          auto pa = a.sample(at(tick), in);
          auto pb = b.sample(at(tick), in);
          same(pa, pb);
          check(pa.work_items > 0 && pa.cpu_ns >= 0 && pa.qssd_ns >= 0 &&
                    pa.virtual_gpu_ns >= 0,
                "component work absent");
          check(pa.quantum_gates == 1001 && pa.quantum_circuits == 1 &&
                    pa.quantum_qubits == 1000 &&
                    std::abs(pa.quantum_signal - std::sqrt(.5f)) < 1e-6f,
                "quantum core circuit evidence absent or rerun per frame");
          if (load == 4 && scene != CALIBRATION)
            check(pa.objects.size() >= 12000,
                  "massive load did not produce the documented scene density");
          for (const auto &o : pa.objects)
            check(std::isfinite(o.x) && std::isfinite(o.y) &&
                      std::isfinite(o.z),
                  "nonfinite geometry");
        }
        auto reset = a.sample(at(2400), in);
        same(reset, b.sample(at(2400), in));
        check(reset.physics_steps == 0, "same tick advanced clock");
      }
    // Render cadence independence with identical event history, including
    // release.
    for (int scene : {MOBA, FIGHTING, OFFSCREEN}) {
      Backend fine, sparse;
      Config c;
      c.scene = scene;
      c.load = 0;
      fine.configure(c, at(0));
      sparse.configure(c, at(0));
      Input down{.65f, -.2f, at(0) + 1, true};
      fine.sample(at(1), down);
      sparse.sample(at(1), down);
      for (int t = 2; t <= 120; ++t)
        fine.sample(at(t), down);
      same(fine.sample(at(120), down), sparse.sample(at(120), down));
      Input release{0, 0, at(120), false};
      fine.sample(at(120), release);
      sparse.sample(at(120), release);
      for (int t = 121; t <= 180; ++t)
        fine.sample(at(t), release);
      same(fine.sample(at(180), release), sparse.sample(at(180), release));
    }
    // A delivered touch can be newer than the Choreographer frame being
    // sampled. Retain the previously accepted velocity until the original
    // event timestamp is eligible; never retimestamp it to an earlier frame.
    {
      Backend ahead, reference;
      Config c;
      c.scene = MOBA;
      c.load = 0;
      ahead.configure(c, at(0));
      reference.configure(c, at(0));
      Input initial{1, 0, at(0) + 1, true};
      Input future{-.5f, .25f, at(60) + 4000000, true};
      ahead.sample(at(1), initial);
      reference.sample(at(1), initial);
      for (int tick : {5, 20, 59, 60})
        same(ahead.sample(at(tick), future),
             reference.sample(at(tick), initial));
      same(ahead.sample(future.event_ns - 1, future),
           reference.sample(future.event_ns - 1, initial));
      auto eligible = ahead.sample(future.event_ns, future);
      same(eligible, reference.sample(future.event_ns, future));
      check(std::abs(hero(eligible).x - 1.5f) < 1e-6f,
            "future event changed motion before its timestamp");
      // Changing the payload while repeating an accepted timestamp must not
      // execute that event again. These coordinates independently check both
      // XI movement channels after thirty ticks at the accepted new velocity.
      Input duplicate{1, -1, future.event_ns, true};
      auto after = ahead.sample(at(90), duplicate);
      same(after, reference.sample(at(90), future));
      check(std::abs(hero(after).x - 1.125f) < 1e-6f &&
                std::abs(hero(after).z - .187f) < 1e-6f,
            "eligible event was skipped or applied more than once");
      same(ahead.sample(at(120), initial), reference.sample(at(120), future));
    }
    // Eligibility is independent of sampling cadence, including when the
    // sparse sampler skips directly over the event timestamp.
    for (int scene : {MOBA, FIGHTING, OFFSCREEN}) {
      Backend dense, sparse;
      Config c;
      c.scene = scene;
      c.load = 0;
      dense.configure(c, at(0));
      sparse.configure(c, at(0));
      Input initial{1, 0, at(0) + 1, true};
      Input future{-.5f, .25f, at(60) + 4000000, true};
      dense.sample(at(1), initial);
      sparse.sample(at(1), initial);
      for (int tick = 2; tick <= 180; ++tick) {
        auto frame = dense.sample(at(tick), future);
        if (tick == 20 || tick == 60 || tick == 180)
          same(frame, sparse.sample(at(tick), future));
      }
    }
    // C12 independent known-answer oracle: visible sparse octahedron positions.
    {
      Backend b;
      Config c;
      c.scene = CALIBRATION;
      c.load = 0;
      b.configure(c, at(0));
      for (int tick : {0, 13, 79, 513}) {
        auto p = b.sample(at(tick), {});
        for (int i = 0; i < 4; ++i) {
          float phase =
              float((std::uint64_t(tick) * 9 + 37 +
                     std::uint64_t(std::llround(std::sqrt(.5) * 1024)) +
                     std::uint64_t(i) * 97) &
                    4095) /
              4096.f;
          check(p.objects.at(2 + i).y == 1 + 2 * phase,
                "XI/QSSD/C12 value did not drive visible position");
        }
        check(p.source_revision == std::uint64_t(tick), "clock revision wrong");
      }
      std::string s = b.provenance();
      check(s.front() == '{' && s.back() == '}' &&
                s.find("\"shared_field_handoffs\":4") != std::string::npos,
            "missing original shared field evidence");
      check(s.find("\"cpu_rule_input_bytes\":32") != std::string::npos,
            "CPU coefficient reads absent");
    }
    // Causal continuous bounded collision: the left fighter cannot cross right.
    {
      Backend b;
      Config c;
      c.scene = FIGHTING;
      c.load = 0;
      b.configure(c, at(0));
      Input right{1, 0, at(0) + 1, true};
      auto p = b.sample(at(240), right);
      int flashes = 0;
      float left = 100, rightx = -100;
      for (const auto &o : p.objects) {
        if (o.sx == .85f && o.sy == 1.05f) {
          left = std::min(left, o.x);
          rightx = std::max(rightx, o.x);
        }
        if (o.sx == .12f && o.r == 1.f)
          ++flashes;
      }
      check(rightx - left >= 1.1999f, "fighters penetrated");
      check(flashes == 16, "contact did not cause visible collision effect");
      Input away{-1, 0, at(240), true};
      auto q = b.sample(at(300), away);
      float moved = 100;
      int remaining_flashes = 0;
      for (const auto &o : q.objects) {
        if (o.sx == .85f && o.sy == 1.05f)
          moved = std::min(moved, o.x);
        if (o.sx == .12f && o.r == 1.f)
          ++remaining_flashes;
      }
      check(std::abs(moved - (-.9f)) < 1e-5f,
            "reverse input did not produce the correct displacement");
      check(remaining_flashes == 0, "contact persisted after separation");
    }
    // Offscreen object follows an analytic ballistic clock without intervening
    // draws.
    {
      Backend a, b;
      Config c;
      c.scene = OFFSCREEN;
      c.load = 0;
      a.configure(c, at(0));
      b.configure(c, at(0));
      auto zero = a.sample(at(0), {});
      auto peak = a.sample(at(60), {});
      check(std::abs(ball(zero).y - .3f) < 1e-6, "ball start");
      check(std::abs(ball(peak).y - 3.3f) < 1e-6, "ballistic apex");
      check(peak.look[2] < peak.eye[2] && ball(peak).z > peak.eye[2],
            "test object was not behind eye");
      for (int t = 1; t <= 180; ++t)
        b.sample(at(t), {});
      same(a.sample(at(180), {}), b.sample(at(180), {}));
      check(std::abs(ball(a.sample(at(240), {})).y - .3f) < 1e-6,
            "ballistic rebound period");
    }
    // Fair cache comparison: both reuse; only streaming lookahead changes build
    // timing.
    {
      Backend a, b;
      Config c;
      c.scene = OPEN_WORLD;
      c.load = 0;
      a.configure(c, at(0));
      c.coordinated = false;
      b.configure(c, at(0));
      auto a0 = a.sample(at(0), {}), b0 = b.sample(at(0), {});
      same(a0, b0);
      check(a0.prepared_regions == 1 && b0.prepared_regions == 0,
            "prefetch mode difference absent");
      auto a1 = a.sample(at(1), {}), b1 = b.sample(at(1), {});
      check(a1.cache_misses == a0.cache_misses &&
                b1.cache_misses == b0.cache_misses,
            "stationary baseline rebuilt resources");
      auto a2 = a.sample(at(960), {}), b2 = b.sample(at(960), {});
      same(a2, b2);
      check(a2.hot_region_builds == a0.hot_region_builds,
            "prefetched region built on arrival");
      check(b2.hot_region_builds == b0.hot_region_builds + 1,
            "direct region not built once on arrival");
      for (int t = 2000; t < 25000; t += 1200)
        a.sample(at(t), {});
      auto s = a.provenance();
      check(s.find("\"retained_regions\":8") != std::string::npos,
            "LRU unbounded");
    }
    {
      Backend b;
      Config c;
      c.scene = CALIBRATION;
      b.configure(c, at(0));
      auto p = b.sample(at(120), {});
      same(p, b.sample(at(60), {}));
      b.configure(c, at(0));
      same(b.sample(at(120), {}), p);
    }
    std::cout << "PASS " << checks
              << " backend assertions; deterministic scenes, A/B equality, "
                 "cadence, original component oracle, collision, offscreen "
                 "clock and bounded fair cache\n";
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "FAIL after " << checks << ": " << e.what() << "\n";
    return 1;
  }
}
