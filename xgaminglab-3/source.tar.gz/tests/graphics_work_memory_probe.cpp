#include "qssd/graphics_work_state.hpp"
#include "trabajo_fisico.hpp"
#include <cassert>
#include <iostream>
int main(){
  qssd::GraphicsWorkMemory<xgpu::PhysicalWorkPlan> memory(4);
  auto initial=memory.snapshot();assert(initial && initial->value->completed_revision==0);
  xgpu::PhysicalWorkPlan p;p.revision=7;p.source_objects=50;p.planned_instance_bytes=320;
  auto v1=memory.publish(p,900,0);assert(v1->value->plan.revision==7);assert(v1->value->dependency_revision==900);assert(v1->value->completed_revision==0);
  p.revision=8;p.planned_instance_bytes=160;
  auto v2=memory.publish(p,901,42);assert(v2->value->plan.revision==8);assert(v2->value->completed_revision==42);assert(v1->value->plan.planned_instance_bytes==320);
  auto st=memory.stats();assert(st.serial>=2);
  memory.reset(8);assert(memory.snapshot()->value->completed_revision==0);
  std::cout << "GraphicsWorkMemory: 10 checks passed\n";
}
