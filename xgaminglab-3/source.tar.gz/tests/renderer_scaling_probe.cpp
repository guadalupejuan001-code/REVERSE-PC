#include "lab_api.hpp"
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

// All commands and pixels use real GLES2. Wrappers observe commands, and a second
// context masks optional capabilities to exercise the actual four-attribute path.
namespace observe {
bool baseline_only=false;
std::uint64_t draws=0,triangles=0,uploaded=0,instances=0,indexed=0;
PFNGLDRAWARRAYSINSTANCEDEXTPROC real_instances=nullptr;
std::map<GLuint,std::vector<unsigned char>> element_data;
bool invalid_indices=false;
void reset(){draws=triangles=uploaded=instances=indexed=0;invalid_indices=false;}
void GL_APIENTRY draw_instances(GLenum mode,GLint first,GLsizei count,GLsizei total){
  ++draws;++instances;if(mode==GL_TRIANGLES)triangles+=std::uint64_t(count/3)*total;
  real_instances(mode,first,count,total);
}
}
extern "C" __eglMustCastToProperFunctionPointerType __real_eglGetProcAddress(const char* name);
extern "C" __eglMustCastToProperFunctionPointerType __wrap_eglGetProcAddress(const char* name){
  auto proc=__real_eglGetProcAddress(name);
  if(proc&&std::strncmp(name,"glDrawArraysInstanced",21)==0){
    observe::real_instances=reinterpret_cast<PFNGLDRAWARRAYSINSTANCEDEXTPROC>(proc);
    return reinterpret_cast<__eglMustCastToProperFunctionPointerType>(&observe::draw_instances);
  }
  return proc;
}
extern "C" const GLubyte* __real_glGetString(GLenum name);
extern "C" const GLubyte* __wrap_glGetString(GLenum name){
  if(observe::baseline_only&&name==GL_EXTENSIONS)return reinterpret_cast<const GLubyte*>("");
  return __real_glGetString(name);
}
extern "C" void __real_glGetIntegerv(GLenum name,GLint* value);
extern "C" void __wrap_glGetIntegerv(GLenum name,GLint* value){
  if(observe::baseline_only&&name==GL_MAX_VERTEX_ATTRIBS){*value=8;return;}
  __real_glGetIntegerv(name,value);
}
extern "C" void __real_glDrawArrays(GLenum mode,GLint first,GLsizei count);
extern "C" void __wrap_glDrawArrays(GLenum mode,GLint first,GLsizei count){
  ++observe::draws;if(mode==GL_TRIANGLES)observe::triangles+=count/3;
  __real_glDrawArrays(mode,first,count);
}
extern "C" void __real_glDrawElements(GLenum mode,GLsizei count,GLenum type,const void* indices);
extern "C" void __wrap_glDrawElements(GLenum mode,GLsizei count,GLenum type,const void* indices){
  ++observe::draws;++observe::indexed;if(mode==GL_TRIANGLES)observe::triangles+=count/3;
  GLint id=0;__real_glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&id);
  const auto found=observe::element_data.find(GLuint(id));
  if(type!=GL_UNSIGNED_SHORT||indices||found==observe::element_data.end()||found->second.size()<std::size_t(count)*2)observe::invalid_indices=true;
  else for(int i=0;i<count;++i){std::uint16_t value=0;std::memcpy(&value,found->second.data()+i*2,2);if(value==65535)observe::invalid_indices=true;}
  __real_glDrawElements(mode,count,type,indices);
}
extern "C" void __real_glBufferData(GLenum target,GLsizeiptr size,const void* data,GLenum usage);
extern "C" void __wrap_glBufferData(GLenum target,GLsizeiptr size,const void* data,GLenum usage){
  if(data)observe::uploaded+=size;
  __real_glBufferData(target,size,data,usage);
}
extern "C" void __real_glBufferSubData(GLenum target,GLintptr offset,GLsizeiptr size,const void* data);
extern "C" void __wrap_glBufferSubData(GLenum target,GLintptr offset,GLsizeiptr size,const void* data){
  observe::uploaded+=size;
  if(target==GL_ELEMENT_ARRAY_BUFFER){
    GLint id=0;__real_glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING,&id);auto& bytes=observe::element_data[GLuint(id)];bytes.resize(std::max(bytes.size(),std::size_t(offset+size)));std::memcpy(bytes.data()+offset,data,size);
  }
  __real_glBufferSubData(target,offset,size,data);
}
namespace {
int checks=0;
void require(bool condition,const std::string& message){++checks;if(!condition)throw std::runtime_error(message);}
constexpr int width=400,height=300;
struct Context {
  EGLDisplay display=EGL_NO_DISPLAY;EGLContext context=EGL_NO_CONTEXT;EGLSurface surface=EGL_NO_SURFACE;
  Context(){
    auto platform=reinterpret_cast<PFNEGLGETPLATFORMDISPLAYEXTPROC>(eglGetProcAddress("eglGetPlatformDisplayEXT"));require(platform,"Surfaceless EGL available");display=platform(0x31DD,EGL_DEFAULT_DISPLAY,nullptr);require(eglInitialize(display,nullptr,nullptr),"Real EGL initialized");
    const EGLint attrs[]={EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_DEPTH_SIZE,16,EGL_NONE};EGLConfig config{};EGLint count=0;require(eglChooseConfig(display,attrs,&config,1,&count)&&count==1,"Real GLES2 configuration");require(eglBindAPI(EGL_OPENGL_ES_API),"Real GLES API bound");
    const EGLint ctx[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE},buffer[]={EGL_WIDTH,width,EGL_HEIGHT,height,EGL_NONE};context=eglCreateContext(display,config,EGL_NO_CONTEXT,ctx);surface=eglCreatePbufferSurface(display,config,buffer);require(context!=EGL_NO_CONTEXT&&surface!=EGL_NO_SURFACE&&eglMakeCurrent(display,surface,surface,context),"Real GLES2 pbuffer active");
    require(std::string(reinterpret_cast<const char*>(glGetString(GL_VERSION))).find("OpenGL ES 2.0")!=std::string::npos,"Test uses strict GLES2");
  }
  ~Context(){eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);eglDestroySurface(display,surface);eglDestroyContext(display,context);eglTerminate(display);}
  std::vector<unsigned char> pixels(){std::vector<unsigned char> out(width*height*4);glReadPixels(0,0,width,height,GL_RGBA,GL_UNSIGNED_BYTE,out.data());require(glGetError()==GL_NO_ERROR,"Real frame readback succeeds");return out;}
};
xlab::Instance object(int mesh,float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,float alpha=1){
  xlab::Instance out;out.mesh=mesh;out.x=x;out.y=y;out.z=z;out.sx=sx;out.sy=sy;out.sz=sz;out.r=r;out.g=g;out.b=b;out.a=alpha;return out;
}
xlab::Packet massive(){
  xlab::Packet p;p.eye={0,90,100};p.look={0,0,0};p.sun={-.8f,1,.35f};p.fog={.025f,.045f,.085f};
  p.objects.push_back(object(2,0,-.05f,0,100,1,100,.3f,.4f,.5f));p.objects.back().casts_shadow=false;
  for(int z=0;z<100;++z)for(int x=0;x<100;++x){auto item=object(0,(x-49.5f)*.8f,.5f,(z-49.5f)*.8f,.5f,1,.5f,.2f+.007f*x,.2f+.006f*z,.65f);item.yaw=float((x+z)%3)*.17f;p.objects.push_back(item);}
  return p;
}
xlab::Packet mixed(){
  xlab::Packet p;p.eye={11,17,22};p.look={0,0,0};p.sun={-.8f,1,.35f};p.fog={.025f,.045f,.085f};
  p.objects.push_back(object(2,0,-.05f,0,32,1,32,.3f,.4f,.5f));p.objects.back().casts_shadow=false;
  for(int z=0;z<20;++z)for(int x=0;x<24;++x){auto item=object((x+z)%3==2?4:(x+z)%3,(x-11.5f)*.65f,.6f,(z-9.5f)*.65f,.5f,1.2f,.5f,.2f+.025f*x,.2f+.025f*z,.65f);item.yaw=float((x+z)%5)*.31f;p.objects.push_back(item);}
  for(int i=0;i<40;++i){auto item=object(i%3==0?1:3,(i%10-4.5f)*.9f,2.0f+(i%3)*.1f,float(i/10)-2,1.6f,1.6f,.8f,.95f,.2f+.015f*i,.4f,.45f);item.casts_shadow=false;p.objects.push_back(item);}
  // Two equally distant translucent billboards deliberately depend on stable order.
  p.objects.push_back(object(3,0,3,4,4,4,1,.95f,.1f,.1f,.65f));p.objects.back().casts_shadow=false;
  p.objects.push_back(object(3,0,3,4,4,4,1,.1f,.5f,.95f,.65f));p.objects.back().casts_shadow=false;
  // Coplanar ground materials deliberately depend on original LEQUAL primitive order.
  p.objects.push_back(object(2,-6,.01f,6,3,1,3,.95f,.2f,.1f));p.objects.back().casts_shadow=false;
  p.objects.push_back(object(2,-6,.01f,6,3,1,3,.1f,.9f,.2f));p.objects.back().casts_shadow=false;
  // Far-off-camera caster remains in the light frustum.
  p.objects.push_back(object(0,-14,18,6,4,3,4,1,0,1));return p;
}
struct Difference {double mean=0,fraction_over_two=0;int maximum=0;std::size_t different=0;};
Difference difference(const std::vector<unsigned char>& a,const std::vector<unsigned char>& b){
  require(a.size()==b.size(),"Pixel dimensions equal");Difference d;std::uint64_t sum=0;std::size_t large=0;
  for(std::size_t i=0;i<a.size();i+=4){bool any=false,over=false;for(int c=0;c<3;++c){const int delta=std::abs(int(a[i+c])-int(b[i+c]));sum+=delta;d.maximum=std::max(d.maximum,delta);any|=delta!=0;over|=delta>2;}d.different+=any;large+=over;}
  d.mean=double(sum)/(a.size()/4*3);d.fraction_over_two=double(large)/(a.size()/4);return d;
}
void save(const std::filesystem::path& path,const std::vector<unsigned char>& image){std::ofstream f(path,std::ios::binary);f<<"P6\n"<<width<<' '<<height<<"\n255\n";for(int y=height-1;y>=0;--y)for(int x=0;x<width;++x)f.write(reinterpret_cast<const char*>(image.data()+(y*width+x)*4),3);require(bool(f),"Real image saved");}
void verify_commands(const xlab::DrawStats& stats){
  require(stats.draw_calls==int(observe::draws),"Reported total draws equal intercepted real commands");require(stats.triangles==int(observe::triangles),"Reported triangles equal intercepted real commands");
  require(stats.instanced_draws==int(observe::instances)&&stats.batched_draws==int(observe::indexed),"Reported paths equal actual driver commands");
  require(stats.draw_calls==stats.reference_draws+stats.batched_draws+stats.instanced_draws+1,"Scene/shadow counters exclude the one composition command");require(!observe::invalid_indices,"Every batch uses valid unsigned-short indices below 65535");
}
xlab::DrawStats draw(xlab::Renderer& renderer,const xlab::Packet& packet,std::uint64_t serial){observe::reset();const auto stats=renderer.draw(packet,serial);verify_commands(stats);return stats;}
std::string row(const char* name,int path,const xlab::DrawStats& stats,const Difference& d){std::ostringstream out;out<<"{\"fixture\":\""<<name<<"\",\"path\":"<<path<<",\"camera_instances\":"<<stats.camera_instances<<",\"shadow_instances\":"<<stats.shadow_instances<<",\"draw_calls\":"<<stats.draw_calls<<",\"instanced_draws\":"<<stats.instanced_draws<<",\"batched_draws\":"<<stats.batched_draws<<",\"triangles\":"<<stats.triangles<<",\"initial_upload_bytes\":"<<stats.bytes_uploaded<<",\"mean_rgb_error_255\":"<<d.mean<<",\"pixel_fraction_error_over_2\":"<<d.fraction_over_two<<",\"max_channel_error_255\":"<<d.maximum<<",\"different_pixels\":"<<d.different<<"}";return out.str();}
}
int main(int argc,char** argv){
  try{
    const std::filesystem::path output=argc>1?argv[1]:"build/graphics-scaling";std::filesystem::create_directories(output);std::vector<std::string> rows;std::vector<unsigned char> recreated_expected;std::string normal_caps,fallback_caps;
    {
      Context context;xlab::Renderer renderer;renderer.initialize();renderer.resize(width,height);std::uint64_t serial=1;xlab::Config config;config.resolution=1;
      for(int fixture=0;fixture<2;++fixture){
        const char* name=fixture?"mixed_alpha_order":"10000_boxes";auto packet=fixture?mixed():massive();config.graphics_path=1;renderer.configure(config);const auto reference=draw(renderer,packet,serial++);const auto pixels=context.pixels();rows.push_back(row(name,1,reference,{}));save(output/(std::string(name)+"-reference.ppm"),pixels);
        if(!fixture)require(reference.camera_instances==10001&&reference.shadow_instances==10000,"All 10000 boxes plus ground are camera-visible; all boxes cast shadows");
        for(int path:{2,0,3}){
          config.graphics_path=path;renderer.configure(config);const auto optimized=draw(renderer,packet,serial++);const auto optimized_pixels=context.pixels();const auto delta=difference(pixels,optimized_pixels);rows.push_back(row(name,path,optimized,delta));
          std::cerr<<name<<" path="<<path<<" draws="<<optimized.draw_calls<<" mean="<<delta.mean<<" fraction>2="<<delta.fraction_over_two<<" max="<<delta.maximum<<'\n';
          require(optimized.camera_instances==reference.camera_instances&&optimized.shadow_instances==reference.shadow_instances&&optimized.triangles==reference.triangles,"Paths preserve visible instances, shadow casters and complete triangle count");
          // CPU pretransformation changes floating-point association. Permit only
          // very sparse raster/PCF boundary differences, never altered scene content.
          require(delta.mean<=.1&&delta.fraction_over_two<=.002,"Optimized image within defined numeric raster tolerance: mean <=0.1/255; <=0.2% pixels differ >2/255");
          require(optimized.draw_calls*10<reference.draw_calls,"Real command count drops by at least 90 percent");
          if(path==2)require(optimized.instanced_draws==0&&optimized.batched_draws>0,"Forced GLES2 batching performs actual indexed draws");
          else require(optimized.instanced_draws>0,"Available EXT instancing performs actual instanced commands");
          const auto retained=draw(renderer,packet,serial++);require(retained.bytes_uploaded==0&&observe::uploaded==0,"Unchanged packets reuse real GPU buffers with zero upload");require(context.pixels()==optimized_pixels,"Retained frame reproduces identical pixels");
          auto changed=packet;changed.objects[1].r=.99f;const auto changed_stats=draw(renderer,changed,serial++);require(changed_stats.bytes_uploaded>0&&changed_stats.bytes_uploaded<optimized.bytes_uploaded,"One material change invalidates only its affected chunks");require(changed_stats.bytes_uploaded==int(observe::uploaded),"Actual upload bytes equal reported changed payload");context.pixels();
          draw(renderer,packet,serial++);require(context.pixels()==optimized_pixels,"Reverting a changed object restores identical image");
          if(!fixture&&path==0){normal_caps=renderer.capabilities();save(output/"10000_boxes-auto.ppm",optimized_pixels);}
          if(fixture&&path==0){recreated_expected=optimized_pixels;save(output/"mixed-alpha-auto.ppm",optimized_pixels);}
        }
        if(fixture){
          auto reversed=packet;std::swap(reversed.objects[packet.objects.size()-5],reversed.objects[packet.objects.size()-4]);config.graphics_path=1;renderer.configure(config);draw(renderer,reversed,serial++);const auto reverse_ref=context.pixels();require(difference(pixels,reverse_ref).different>100,"Fixture detects deliberate reversal of equal-depth alpha order");
          config.graphics_path=0;renderer.configure(config);draw(renderer,reversed,serial++);const auto reverse_delta=difference(reverse_ref,context.pixels());require(reverse_delta.mean<=.1&&reverse_delta.fraction_over_two<=.002,"Optimized route preserves equal-depth alpha input order");
        }
      }
    }
    {
      Context context;xlab::Renderer renderer;renderer.initialize();renderer.resize(width,height);xlab::Config config;config.resolution=1;renderer.configure(config);draw(renderer,mixed(),1);require(context.pixels()==recreated_expected,"Destroy/recreate context retains no stale optimized VBO or attribute-divisor state");
    }
    observe::baseline_only=true;
    {
      Context context;xlab::Renderer renderer;renderer.initialize();renderer.resize(width,height);xlab::Config config;config.resolution=1;config.graphics_path=2;renderer.configure(config);const auto packet=mixed();draw(renderer,packet,1);const auto batch_image=context.pixels();
      config.graphics_path=3;renderer.configure(config);const auto fallback=draw(renderer,packet,2);require(fallback.instanced_draws==0&&fallback.batched_draws>0,"Preferred instancing falls back to actual indexed GLES2 draws when extensions are unavailable");require(context.pixels()==batch_image,"Fallback produces exact forced-batch pixels");fallback_caps=renderer.capabilities();require(fallback_caps.find("\"instancing_supported\":false")!=std::string::npos&&fallback_caps.find("\"max_vertex_attributes\":8")!=std::string::npos,"Capabilities report masked eight-attribute GLES2 baseline honestly");
    }
    std::cout<<"{\"suite\":\"gles2-massive-renderer-paths\",\"passed\":true,\"checks\":"<<checks<<",\"numeric_tolerance\":{\"mean_rgb_error_255_max\":0.1,\"pixel_fraction_error_over_2_max\":0.002},\"rows\":[";for(std::size_t i=0;i<rows.size();++i){if(i)std::cout<<',';std::cout<<rows[i];}std::cout<<"],\"normal_capabilities\":"<<normal_caps<<",\"fallback_capabilities\":"<<fallback_caps<<",\"fallback_capabilities_masked\":true,\"physical_fps_claim\":false,\"android_surface_tested\":false}\n";
  }catch(const std::exception& error){std::cerr<<"Scaling renderer probe failed: "<<error.what()<<'\n';return 1;}
}
