#include "presentation_tracker.hpp"
#include <iostream>
#include <stdexcept>
#include <unordered_map>

namespace {
int checks=0;
void require(bool condition,const char* message){++checks;if(!condition)throw std::runtime_error(message);}
}
int main(){
  try{
    using Tracker=xlab::PresentationTracker;Tracker tracker;
    std::unordered_map<std::uint64_t,Tracker::Read> driver;
    const auto read=[&](std::uint64_t id){return driver.at(id);};
    tracker.submitted(9001,1,100);tracker.submitted(84567,2,200);
    driver[9001]={};driver[84567]={Tracker::State::measured,250};
    auto sample=tracker.poll(260,read);require(sample.serial==0&&sample.time_ns==-1,"Pending is not a fabricated presentation time");require(tracker.pending()==2&&tracker.processed()==0,"Later resolved frame does not replace oldest pending identity");
    driver[9001]={Tracker::State::measured,240};sample=tracker.poll(270,read);require(sample.serial==1&&sample.time_ns==240,"EGL id resolves to its original lab serial and measured timestamp");require(tracker.pending()==1&&tracker.processed()==1,"Only one measured record delivered per poll");
    sample=tracker.poll(280,read);require(sample.serial==2&&sample.time_ns==250,"Second measured record retains its own timestamp");require(tracker.poll(290,read).serial==0,"A measured record is never delivered twice");
    tracker.submitted(3,3,300);tracker.submitted(4,4,310);driver[3]={Tracker::State::invalid,-1};driver[4]={Tracker::State::measured,320};sample=tracker.poll(330,read);require(sample.serial==4&&tracker.lost()==1,"Invalid driver record does not block next valid presentation");
    tracker.untracked_swap();require(tracker.lost()==2,"Swap without queryable id is explicitly lost");
    tracker.submitted(5,5,400);tracker.submitted(6,6,410);tracker.discard_pending();require(tracker.pending()==0&&tracker.discarded()==2&&tracker.lost()==2,"Resize discards pending records without double-counting lost samples");
    tracker.submitted(7,7,500);driver[7]={};sample=tracker.poll(500+Tracker::timeout_ns+1,read);require(sample.serial==0&&tracker.discarded()==3&&tracker.pending()==0,"Expired pending timestamp is abandoned, not replaced with expected time");
    tracker.reset();require(tracker.pending()==0&&tracker.lost()==0&&tracker.discarded()==0&&tracker.processed()==0,"Configuration begins a clean measurement scope");
    for(std::uint64_t i=0;i<300;++i){tracker.submitted(1000+i,1+i,10000);driver[1000+i]={};}
    require(tracker.pending()==Tracker::capacity&&tracker.discarded()==300-Tracker::capacity,"Driver backlog is bounded and all evictions accounted for");
    driver[1044]={Tracker::State::measured,11000};sample=tracker.poll(12000,read);require(sample.serial==45&&sample.time_ns==11000,"Bounded queue preserves EGL-to-original-serial mapping after eviction");
    tracker.reset();tracker.submitted(5000,1,20000);driver[5000]={Tracker::State::measured,20100};sample=tracker.poll(20200,read);require(sample.serial==1&&sample.time_ns==20100,"Serial reuse after configuration cannot report old-scope data");
    tracker.submitted(5001,2,20300);driver[5001]={Tracker::State::measured,0};sample=tracker.poll(20400,read);require(sample.serial==0&&tracker.lost()==1,"Zero is not a valid actual display timestamp");
    std::cout<<"{\"suite\":\"native-presentation-tracker\",\"passed\":true,\"checks\":"<<checks<<",\"driver_results_simulated\":true,\"physical_presentation_tested\":false}\n";
  }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
