# X Gaming Lab 3.0 — physical-work integration

## Old route

The earlier lab could execute Ether/XI, QSSD and GPU Virtual but the physical renderer still received a largely materialized per-frame scene. A single GPU timer covered multiple render passes, making the reported physical cost hard to dissect.

## 3.0 route

1. Ether/XI publishes logical scene state and stable object revisions.
2. GPU Virtual turns that state into `PhysicalWorkPlan` before the physical renderer: camera/shadow candidate sets, explicit contribution criterion, revision reuse and PWR denominators.
3. QSSD retains immutable plan/completion revisions.
4. REgraphics retains buffers, updates sparse changed ranges, reuses exact shadow/scene targets and sends only surviving work.
5. The physical GPU rasterizes the irreducible shadow/scene/screen work.
6. Three asynchronous GPU timers and independent swap/presentation tracking keep physical execution separate from pacing/waits.

## What counts as physical work avoided

Exact: object submissions, mesh vertex invocations implied by those submissions, retained-pass avoidance, representation bytes, actual CPU-to-GPU upload bytes.

Estimated: projected fragment-area. It is explicitly labeled as an estimate and must not be read as a hardware fragment counter.

Not included in PWR denominator: the final screen/composition pass, Android compositor, display scanout.

## Correctness boundaries

- no hidden resolution change;
- no hidden object-count change;
- no shadow/effect disabling in the all-active case;
- camera-facing billboards retain their exact prepared matrix payload;
- compact ordinary instances preserve full-float RGBA;
- scene/shadow reuse requires exact dependency equality;
- sparse uploads fall back to a single full transfer when fragmentation would create excessive calls.
