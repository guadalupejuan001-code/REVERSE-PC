# Adaptador gráfico nativo y evidencia

El único estado de las escenas lo produce `Backend::sample`, mediante los
componentes originales XI/Ether, QSSD y GPU Virtual. `Renderer` recibe ese
`Packet`: no mantiene otra simulación, otra trayectoria ni un sustituto del
mundo. Los objetos de los tests del adaptador son únicamente fixtures de prueba.

## Dibujo físico

El adaptador compila shaders GLSL ES 1.00 y utiliza funciones GLES2. Conserva
cinco buffers de malla: caja, octaedro, plano, billboard y cilindro. Los tamaños
de las instancias son dimensiones completas; Y apunta arriba y `yaw` rota
alrededor de Y en radianes. La dirección `sun` apunta hacia la luz.

La v2 añade rutas de referencia, batches indexados GLES2 e instancing opcional,
con bloques retenidos y el mismo orden de primitivas. El contrato, los límites
de memoria y las comparaciones de píxeles/draws están en
[`GRAPHICS_SCALING_V2.md`](GRAPHICS_SCALING_V2.md).

Las matrices, el descarte por frustum y el orden de transparencias se calculan
desde el paquete actual. Las partículas usan alpha convencional y se ordenan
de atrás hacia delante. El paso opaco escribe profundidad; el transparente la
consulta sin escribirla. El buffer de escena tiene la escala de resolución
solicitada —75 % por defecto en cada dimensión— y se compone sobre toda la
superficie física mediante filtrado lineal.

Las sombras son un mapa direccional real de hasta 1024 × 1024, con profundidad
empaquetada en los canales RG de una textura RGBA8 y filtro de cuatro consultas.
La proyección de luz sigue la región de la cámara; tiene una sola cobertura
ortográfica, no cascadas. El frustum de luz se evalúa independientemente del de
cámara: un objeto que no aparece en pantalla puede proyectar una sombra visible.
Los materiales incluyen iluminación difusa, brillo especular y niebla; no son
un sistema completo de materiales PBR.

## Relojes y superficie Android

Todas las llamadas JNI/EGL pertenecen al mismo hilo de render. El formato de la
ventana se fija con `EGL_NATIVE_VISUAL_ID` antes de crear la superficie EGL. El
adaptador posee `eglSwapBuffers`, comprueba su resultado y detiene la sesión si
se pierde la superficie. La aplicación debe cerrarla y crear una sesión nueva.

Las duraciones de CPU usan `CLOCK_MONOTONIC`, compartido con los tiempos de
fotograma proporcionados desde Java. El tiempo esperado de presentación sólo se
envía como sugerencia mediante `eglPresentationTimeANDROID`, si existe; nunca se
exporta como tiempo observado. El modo coordinado solicita intervalo de swap 1;
el directo solicita 0. El resultado de esa solicitud no demuestra el intervalo
efectivo y el dispositivo puede seguir limitando ambos modos.

Cuando el sistema admite `EGL_ANDROID_get_frame_timestamps` y el evento
`EGL_DISPLAY_PRESENT_TIME_ANDROID`, el ID EGL se asocia al serial original antes
del swap. Se devuelve como máximo la muestra medida más antigua disponible por
fotograma, conservando esa asociación. Registros inválidos, pendientes,
expulsados y caducados se contabilizan por separado. La configuración reinicia
la ventana; una sustitución de superficie descarta sus pendientes.

La extensión opcional `GL_EXT_disjoint_timer_query` usa ocho consultas
asíncronas. La duración corresponde a comandos de sombras, escena y composición,
excluye el swap y el compositor, y lleva su serial de origen. Un resultado
pendiente, ausente o invalidado vale −1. No se llama a `glFinish` ni se sustituye
tiempo GPU por tiempo CPU. Los cambios de configuración invalidan consultas
anteriores; un driver que comunica `disjoint` descarta sus resultados pendientes.

`INPUT_TO_SUBMIT_NS` sólo se informa cuando el backend acepta un timestamp nuevo
de entrada: debe pertenecer a la configuración actual, superar el último
aceptado y no ser posterior al instante simulado. Un toque que llega después
del VSync queda pendiente hasta un fotograma elegible, sin adelantarse ni
contarse varias veces. Cuenta estos timestamps aceptados, no todos los eventos
táctiles del sistema. No es una medida táctil hasta el fotón. `STATE_HASH`
exporta los 53 bits inferiores del hash como huella exacta representable en el
buffer de doubles.

## Verificación local reproducible

Los scripts requieren headers oficiales Khronos y bibliotecas EGL/GLES. Las
variables permiten usar el despacho real de Mesa en el entorno local:

```sh
export XLAB_GL_HEADERS=/ruta/a/khronos-headers
export XLAB_EGL_LIBRARY=-l:libEGL.so.1
export XLAB_GLES_LIBRARY=-l:libGL.so.1
bash scripts/test-renderer.sh
bash scripts/test-renderer-scaling.sh
bash scripts/test-backend-renderer.sh
```

El probe fuerza OpenGL ES 2.0 real en Mesa y compila los shaders de producción.
Resultados obtenidos:

- 87 verificaciones del adaptador: dos contextos destruidos/recreados, píxeles
  idénticos después de recreación, resolución física/FBO, VBOs retenidos,
  transparencias, descarte y consultas GPU asíncronas.
- Desactivar sombras cambió 1592 píxeles de la escena de prueba; un objeto fuera
  de la cámara cambió 3268 píxeles mediante su sombra, sin añadir un draw de
  cámara.
- 15 verificaciones del rastreador de presentación con resultados de driver
  simulados. También se inyectó una señal `disjoint` sobre consultas GL reales
  para comprobar el descarte, sin afirmar que Mesa sufriera ese evento físico.
- 342 verificaciones de los ocho mundos del Backend original en cargas 1 y 4
  hasta píxeles GLES2. A igual tiempo y entradas, los modos coordinado y directo
  produjeron imágenes idénticas byte a byte en las 16 muestras. Referencia,
  batches, automática e instancing preferido también produjeron píxeles exactos
  entre sí en esas muestras, conservando triángulos e instancias de cada paso.
- 277 verificaciones específicas de escalado: 10.000 cajas visibles con sus
  sombras pasan de 20.002 a ocho draws, conservando sus 240.004 triángulos y
  píxeles exactos; fallback GLES2 de ocho atributos, índices de 16 bits,
  invalidación de bloques y subida cero para estados repetidos.
- Compilación de JNI y renderer con NDK r27d, API 26, arm64 y x86_64, con
  `-Wall -Wextra -Wpedantic -Werror`.
- 14 casos sobre la clase de admisión temporal productiva del puente JNI:
  evento futuro, frontera exacta, aceptación única, timestamp antiguo, nueva
  configuración y regresión del tiempo solicitado.

Los JSON y capturas de estas pruebas se generan en `build/graphics-probe`.
Comprueban el camino gráfico y los contratos indicados; no son una medición
de FPS de un teléfono ni verifican timestamps de presentación de una pantalla
Android física.
