# Original components: audit and v2 implementation

## What v1 actually executed

The v1 graphics lab reused the original `QuantumRuntime`, `qssd::Space`, `qssd::StateBus` and GPU Virtual. It exercised classical XI arithmetic and memory, immutable QSSD publication, and a C12 phase array consumed by visible actors. Merely owning a `QuantumRuntime` did not mean quantum gates were being exercised: its scene program contained integer `set/load/store/add/mul/div` instructions and no H, CX, T or measurement operations. Its C12 kernel was a small phase transform. Its normal scene path did not test QSSD checkpoint recovery, simulated Bell transfer or quantum GPU-port observations.

Those were real components with a narrow workload. V1 was not a measurement of quantum computation or a physical quantum GPU.

## V2: quantum state contributes to scene output

Each scene configuration now executes the **original H/T/CX circuit on two qubits**, owned by the original Mundo-X core through the original REVERSE integration. This prepares a coherent entangled phase state. The original `QuantumGpuView` observes its XX correlation without substituting an app-local state simulator.

The observed value is explicitly projected to a fixed-point classical number and stored by XI in `InverseMemory`. The per-sample XI program reads that stored result into its motion coefficient. Original QSSD publishes that coefficient as a shared immutable Field. Original C12 produces actor phases from it. Object motion, rotation and phase-linked audio/light consume those phases.

The expected XX correlation is `cos(pi/4)`, approximately 0.70710678. **That expected value is an oracle in tests, not the production result.** Production obtains it from the actual core observer. With Q10 scaling, the observed result rounds to 724. Removing T in the causal test changes the actual observed value to 1, the projected value to 1024, and the CPU field and original C12 output both change.

Three gate operations and one circuit execute once per configuration; there is no gate loop per rendered frame. Packet/provenance expose `quantum_gates`, `quantum_circuits`, `quantum_qubits`, and `quantum_signal`. The gate count comes from the original core's revision increase, not a presence flag. These are cumulative configuration counters. Their value must not be mistaken for per-frame quantum work.

C12 receives an explicitly classical observation. `QuantumGpuView` evaluates through XI/Ether on the host CPU. This is **not quantum gate execution on Android's physical GPU**, and no quantum hardware or quantum speedup is claimed.

## Five bounded diagnostic classes

The platform-independent API is in `native/component_lab.hpp`. `run_component(ComponentRequest)` returns a report; `report.json()` returns a valid JSON object. Requests include `kind`, `load`, `seed` and an existing private `directory`. The call performs one finite batch; callers can cancel between batches. There is no indefinite loop inside a diagnostic.

| Kind | Original work executed | Independent validation |
|---|---|---|
| CPU XI | Integer vector reduction in the original XI interpreter; durable output in `InverseMemory`; intentionally rejected transaction | Host modular-arithmetic oracle; a failed divide transaction must leave the complete committed runtime unchanged |
| Quantum core | Bell H/CX, seeded Born measurements, GHZ, inverse circuits, original T/TDG interference, two-qubit marked-state search | Known Pauli correlations and probabilities, independent MT19937-64 half-probability oracle, restored RNG replay, normalization, exact inverse and deterministic marked basis state |
| GPU Virtual | CPU-authored Field, two dependent C12 dispatches, binary32 affine/quadratic transform, group-local shared tile permutation and barriers | Every output word compared to an independent host IEEE float oracle; group isolation, dependency completion, shared source pointer, and original execution counters |
| QSSD | Original port aliases, revision-pinned leases, StateBus bookmark/fork/rewind, checkpoint serialization, real file write/fsync/reopen/read, restore, corruption rejection, simulated Bell byte transfer | Full byte equality, restored identities/aliases/CPU authority, every logical field word, old-lease retention, preserved non-Clifford phase and external entanglement |
| Integrated | Original quantum observable → XI vector arithmetic and coefficient → QSSD shared field → C12 transform and tile operation → complete checkpoint file restore | Independent vector/float oracles, actual observed quantum signal, exact restored field and quantum correlation |

The quantum tests exercise both the original compact Clifford representation and the already-vendored REVERSE integration's original non-Clifford representation. Reports expose active qubits, largest component, representation payload, Clifford/adaptive/reduced component counts, retained T instruction counts and stored factors. Payload sizes are representation payloads, **not whole-process RSS**.

The Bell byte transfer uses the original `Space::teleport_quantum_byte`, including its H/CX/Born measurement/X/Z protocol and 16 classical outcomes. Its destination remains correlated with an external reference. An old pinned view remains valid. A C12 arithmetic window must reject a quantum handle unless the application explicitly projects an observation. No physical teleportation or zero-time transport is implied.

## Load levels

| Workload | 0 | 1 | 2 | 3 | 4 |
|---|---:|---:|---:|---:|---:|
| XI vector elements | 64 | 512 | 4,096 | 16,384 | 65,536 |
| C12 lanes | 256 | 4,096 | 16,384 | 65,536 | 262,144 |
| C12 workgroups, 64 lanes each | 4 | 64 | 256 | 1,024 | 4,096 |
| Bell pairs | 1 | 8 | 32 | 64 | 128 |
| GHZ qubits | 3 | 8 | 16 | 32 | 64 |
| Independent one-qubit interference circuits | 1 | 8 | 32 | 128 | 256 |
| Two-qubit marked-state circuits | 1 | 2 | 4 | 8 | 16 |
| Normal scene actors | 24 | 80 | 240 | 2,400 | 12,000 |
| Effects scene particles | 96 | 320 | 960 | 6,000 | 24,000 |

Calibration remains intentionally sparse. Other level-4 scenes produce at least 12,000 instances; cars have multiple pieces and MOBA adds projectiles. The old 0–2 budgets remain unchanged. These are deliberate stress loads, not claims that every device can draw them at 120 FPS.

A 64-qubit GHZ test is a structured Clifford test; it does not materialize 2^64 arbitrary amplitudes. Hundreds of independent one-qubit circuits are not one general entangled state of the same total width. The C12 executor can retain compact relations while the diagnostic still explicitly observes and verifies every requested output word. `executorSteps` and `scalarLaneEvaluations` therefore have different meanings from `outputWordsObserved`.

## Report semantics

Each report includes its name/kind, load, seed, pass/fail, check/failure counts, work quantity and unit, hexadecimal checksum, maximum numeric error, elapsed nanoseconds, and subtest reports. Each subtest records its own scope, actual dimensions, counters, observations and bounded failure details. Checksums exclude timings and temporary filenames. Integer/C12 output checks are exact; floating quantum checks use explicit small tolerances and report the actual maximum error. Quantum checksum observations use a fixed 1e-9 quantization while pass/fail uses the unquantized error.

Gate counts refer to successfully executed original gate commands; representation statistics and revisions come from the original core. Simulated Bell protocol gate counts include the returned classical correction outcomes. Measurement receipts are retained as observations, not copied into a purported independent expected checksum.

QSSD diagnostics create a uniquely named temporary checkpoint file under the supplied directory, write and `fsync` it, close/reopen it, read its actual bytes, restore the original state, then remove the temporary file. Reports expose serialized bytes, read/write bytes, `fsync` count, serialization/restore time and filesystem read/write time. This is a filesystem recovery experiment. The OS cache may participate; it is not a raw storage-device bandwidth benchmark or a power-failure test.

The checkpoint contains the original QSSD Space's CPU/quantum state, classical source Fields, identities and port topology. The separate StateBus checks exercise retained versions in memory. These tests do not claim to serialize a physical GLES context, framebuffer, the scene's region cache, or a running C12 dispatch. The integrated restore validates the persisted C12 source Field and quantum correlation; the C12 transform itself is independently checked before that restore.

The integrated report records the full crossing between components. It does not infer correctness from loaded-library flags, resource filenames or successful creation of a context.

## Reproducible validation

- `tests/run_component_tests.sh` verifies immutable vendor hashes, builds the actual component implementation and checks all 25 kind/load combinations. Level-0 checksums are repeated for determinism. It also removes T through the actual shared production circuit adapter to prove downstream causality and rejects invalid requests/missing checkpoint directories.
- `tests/run_backend_tests.sh` checks all 40 scene/load combinations and keeps the prior cadence, input eligibility, collision, offscreen-clock and fair-cache regressions. It now checks original quantum counters/signal, independent quantum-influenced visible coordinates, and the level-4 density floor.
- No original vendored file was modified. The original hash-checked compatibility generators remain the only source of derived build overlays.

Host results establish bounded functional correctness of these workloads. Android device timing, thermal behavior, compositor presentation and the physical renderer must still be measured on the actual target hardware. The code is platform-independent and can be built for a PC prototype, but these results do not establish that an unbuilt PC architecture has particular performance.
