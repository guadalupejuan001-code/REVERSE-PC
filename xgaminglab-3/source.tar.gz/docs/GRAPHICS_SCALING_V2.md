# Escalado gráfico v2: rutas reales, orden y evidencia

## Qué componente hace cada trabajo

`Backend::sample` conserva la propiedad del mundo. XI/Ether calcula el estado de
CPU; QSSD conserva y suministra datos; GPU Virtual ejecuta su ruta lógica
original y produce valores consumidos por las escenas. C12 no se convierte en
un driver gráfico ni en silicio GPU por llamarse GPU-VIRTUAL. La rasterización,
los shaders, las sombras y el envío a la superficie pertenecen a este adaptador
GLES. Sus consultas GPU y los timestamps de presentación tienen ámbitos
separados del tiempo de ejecución C12.

La v2 cambia cómo se envían los mismos objetos de `Packet`, sin sustituir el
Backend, reducir sus cargas ni generar un segundo mundo. Los 10.000 cubos de la
prueba aislada son un fixture del adaptador; las capturas de escenas enlazan el
Backend original y sus componentes efectivos.

## Contrato de rutas

| `Config.graphics_path` | Ruta solicitada | Comportamiento |
| --- | --- | --- |
| 0 | Automática | Instancia tramos consecutivos de al menos cuatro objetos con la misma malla; combina el resto en batches GLES2. |
| 1 | Referencia | Conserva un draw por objeto por paso, las matrices originales y los uniforms por objeto. |
| 2 | Batches | Expande posiciones/normales en CPU y utiliza dibujos indexados, sin depender de extensiones. |
| 3 | Instancing preferido | Instancia tramos consecutivos desde dos objetos; utiliza batches cuando no corresponde o falta soporte. |

El mínimo continúa siendo GLES2/GLSL ES 1.00. La detección admite las funciones
core de un contexto que realmente sea ES3, `GL_EXT_instanced_arrays`,
`GL_ANGLE_instanced_arrays` y el par NV correspondiente. La extensión anunciada,
los puntos de entrada disponibles y el límite de atributos se comprueban en el
contexto actual. Un nombre de API o una versión de Android no sustituyen esas
comprobaciones.

La variante instanced utiliza diez atributos: tres de la malla y siete para
filas de la matriz, columnas de normales y color. Envía los mismos coeficientes
float preparados por la referencia, sin reconstrucciones trigonométricas ni
cuantización. Cada instancia ocupa 112 bytes por paso. Una GPU GLES2 que sólo
admita ocho atributos usa el fallback de cuatro atributos. Si falla el shader
opcional, también se conserva ese fallback y se informa el motivo en
`capabilities()`.

El modo preferido no garantiza menos draws que batches en una secuencia muy
heterogénea. Es un control de experimento: intercambia menos datos duplicados
por más grupos pequeños. El modo automático usa un umbral más conservador.
No existe una selección oculta de menor calidad para mejorar el resultado.

## Orden de primitivas y datos retenidos

Se conserva el orden original de los objetos opacos y de los casters. El orden
alpha sigue siendo estable, de atrás hacia delante. El agrupamiento respeta esa
secuencia: nunca agrupa globalmente por material o malla saltándose objetos
intermedios. Esto conserva la semántica de superficies coplanares con `LEQUAL`,
mezcla alpha y sombras. Los mismos casters fuera del frustum de cámara siguen
participando en el mapa de luz.

Los batches CPU utilizan índices `GL_UNSIGNED_SHORT` y como máximo 65.535
vértices por bloque; el índice máximo es 65.534. La malla se deduplica una sola
vez usando los bits completos de posición, normal y UV, manteniendo la secuencia
original de índices/triángulos. Cada vértice expandido ocupa 52 bytes: posición,
normal transformada todavía sin normalizar, UV/material y color float completo.
La normalización se mantiene en el shader. Instancing se limita a 4.096
instancias por comando.

Se retienen buffers, capacidad de vectores y los datos necesarios para comparar
el contenido. La clave es una comparación completa de los floats de matriz,
normal, color y malla; no una huella susceptible de colisión. Repetir un estado
sin cambios no vuelve a expandir ni subir sus vértices. Un cambio invalida sólo
los bloques afectados. Los índices se vuelven a subir cuando cambia su
contenido, no por un cambio de posición/color. Los buffers crecen por potencias
de dos, por lo que la memoria reservada puede superar el payload informado.
Una configuración nueva libera los bloques anteriores. Una recreación de
contexto crea todos los recursos otra vez.

La preparación de matrices/visibilidad y la comparación de claves siguen
recorriendo los objetos en CPU. La ordenación alpha mantiene su coste propio;
subida cero no significa coste CPU cero.

Los objetos dinámicos y billboards orientados hacia una cámara móvil siguen
requiriendo trabajo y, cuando cambian sus matrices, nuevas subidas. Batching no
elimina la transformación de vértices, la rasterización, el overdraw alpha ni
el coste de las sombras. La ruta CPU conserva más datos que instancing; para
muchos objetos móviles, memoria y ancho de banda pueden dominar aunque haya
pocos draws.

## Métricas

`camera_instances` cuenta objetos enviados a los pasos de cámara, y
`shadow_instances` objetos enviados al mapa de sombras. Un mismo objeto puede
aparecer en ambos. `instanced_draws`, `batched_draws` y `reference_draws` cuentan
comandos de escena más sombras. La composición final se excluye de esos tres
contadores y se incluye en `draw_calls`:

`draw_calls = instanced_draws + batched_draws + reference_draws + 1`

`bytes_uploaded` suma la inicialización real de mallas y el payload cambiado de
batches/instancias. Excluye el margen vacío de capacidad y las texturas de los
FBO. `geometry_ns` incluye preparación, descarte, orden y construcción de datos
de batch en CPU. `submit_ns` incluye llamadas GL, subidas y comandos; no se
renombra como tiempo GPU. La consulta GPU asíncrona conserva su serial de origen
y cubre los comandos de sombras, escena y composición, excluyendo el swap y el
compositor. Ninguna ruta introduce `glFinish`.

## Validación real y límites

Ejecutar con headers Khronos y bibliotecas EGL/GLES disponibles:

```sh
export XLAB_GL_HEADERS=/ruta/a/khronos-headers
export XLAB_EGL_LIBRARY=-l:libEGL.so.1
export XLAB_GLES_LIBRARY=-l:libGL.so.1
bash scripts/test-renderer.sh
bash scripts/test-renderer-scaling.sh
bash scripts/test-backend-renderer.sh
```

El probe de escalado fuerza un contexto GLES2 real sobre Mesa llvmpipe, compila
los shaders productivos y observa los comandos enviados al driver. No sustituye
el rasterizador por una simulación. La rama de fallback se ensaya ocultando
extensiones y limitando los atributos anunciados a ocho; sus comandos y píxeles
siguen siendo GL reales. Ese enmascaramiento se declara en el JSON.

Resultados del fixture de 10.000 cajas, más suelo, a 400 × 300, escala 100 %:

| Ruta | Objetos de cámara | Casters | Triángulos totales | Draws | Subida inicial |
| --- | ---: | ---: | ---: | ---: | ---: |
| Referencia | 10.001 | 10.000 | 240.004 | 20.002 | 8.448 bytes de mallas |
| Batches GLES2 | 10.001 | 10.000 | 240.004 | 11 | 30.560.324 bytes |
| Automática | 10.001 | 10.000 | 240.004 | 8 | 2.240.324 bytes |
| Instancing preferido | 10.001 | 10.000 | 240.004 | 8 | 2.240.324 bytes |

Las cuatro imágenes son idénticas byte a byte en esa prueba. La repetición de
cada estado optimizado sube cero bytes. La comparación comienza con la ruta
referencia y reutiliza el contexto: su subida inicial de 8.448 bytes es la
inicialización compartida de las cinco mallas; las otras cifras son el payload
nuevo de cada ruta, no una comparación de memoria total.

En un fixture de 526 objetos con distintas mallas, transparencias, superficies
coplanares y caster fuera de cámara, la referencia usa 1.007 draws; batches 4,
automática 6 e instancing preferido 25. Los 27.068 triángulos y las instancias de
cámara/sombra se conservan. Cada ruta optimizada difiere en dos píxeles por una
unidad de canal sobre 255; ninguna diferencia supera dos unidades. Invertir dos
capas alpha a la misma profundidad cambia la imagen de control, y las rutas
optimizadas conservan el nuevo orden correcto.

Hay 277 verificaciones en el probe de escalado. La tolerancia definida para
redondeo y bordes de raster/PCF es error RGB medio de como máximo 0,1 sobre 255 y
como máximo 0,2 % de píxeles con algún canal distinto en más de dos unidades.
Los resultados observados anteriores son mucho menores; el JSON conserva los
valores efectivos, no sólo aprobado/rechazado. La batería gráfica original
mantiene sus 87 comprobaciones y dos ciclos de contexto. Los dos ABI Android
arm64/x86_64 compilan con NDK r27d, API26 y warnings tratados como errores.

Los resultados están en `build/graphics-scaling/result.json`,
`build/graphics-probe/result.json` y
`build/graphics-probe/backend-render-result.json`; las capturas PPM se encuentran
en esos directorios. El último probe enlaza `x_backend.cpp` y
`component_lab.cpp` originales de la app y compara sus ocho escenas en cargas
1 y 4. El JSON distingue tamaño del mundo, instancias realmente dibujadas,
triángulos, ruta y coincidencia A/B a igual tiempo. Sus 342 verificaciones
pasaron: las 16 muestras producen píxeles idénticos entre las cuatro rutas y
entre los modos coordinado/directo. En carga 4:

| Escena original | Objetos del mundo | Instancias de cámara | Draws referencia | Draws auto |
| --- | ---: | ---: | ---: | ---: |
| MOBA | 15.107 | 15.107 | 27.211 | 16 |
| Mundo abierto | 12.411 | 5.688 | 18.070 | 8 |
| Lucha | 12.114 | 12.114 | 12.228 | 17 |
| Shooter | 16.053 | 16.046 | 28.099 | 13 |
| Carreras | 24.113 | 20.091 | 44.148 | 14 |
| Efectos | 24.002 | 24.002 | 24.004 | 9 |
| Fuera de cámara | 12.418 | 12.033 | 24.227 | 15 |

El modo preferido demuestra también el riesgo de grupos demasiado pequeños:
MOBA masivo emite 6.010 draws y shooter 8.006, con la misma imagen. Esas
secuencias alternan tramos cortos. La ruta automática conserva 16 y 13
respectivamente; el informe mantiene todas las cifras para comparar sin
seleccionar sólo los resultados favorables.

Reducir 20.002 comandos a ocho demuestra escalado del envío conservando el
contenido de este fixture. No demuestra 120 FPS, velocidad del hardware de un
teléfono, ganancia proporcional de rendimiento ni presentación física. Esas
conclusiones requieren las campañas y timestamps del dispositivo correspondiente.

## Fuentes primarias consultadas

- [Khronos EXT_instanced_arrays](https://registry.khronos.org/OpenGL/extensions/EXT/EXT_instanced_arrays.txt): extensión para GLES2, atributos con divisor y semántica secuencial de instancias.
- [Khronos ANGLE_instanced_arrays](https://registry.khronos.org/OpenGL/extensions/ANGLE/ANGLE_instanced_arrays.txt): equivalente disponible en implementaciones que anuncian esta extensión.
- [Especificación OpenGL ES 2.0](https://registry.khronos.org/OpenGL/specs/es/2.0/es_full_spec_2.0.pdf): contrato de atributos, dibujos indexados y límites mínimos de la API.
- [Android: OpenGL ES](https://developer.android.com/develop/ui/views/graphics/opengl/about-opengl): comprobar la implementación real del dispositivo al usar características opcionales de versiones superiores.
- [Khronos EXT_disjoint_timer_query](https://registry.khronos.org/OpenGL/extensions/EXT/EXT_disjoint_timer_query.txt): disponibilidad asíncrona, contador útil y validez de muestras ante `disjoint`.
