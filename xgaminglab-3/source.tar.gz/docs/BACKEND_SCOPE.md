# Standalone native benchmark backend — v2

The lab has its own low-poly workloads. It does not modify or invoke an existing game's world. It evaluates the user's original components in a controlled scene pipeline; results cannot establish that an existing game reaches 120 FPS.

## Original execution path

1. `qssd::Space::execute_cpu` runs the original Mundo-X `QuantumRuntime`, with the existing REVERSE XI machine extension. At configuration it executes original H/T/CX on two qubits; original `QuantumGpuView` observes XX and XI stores its explicit Q10 classical projection. XI owns persistent control anchors and velocities in `InverseMemory`. Its per-sample integer program computes bounded movement/contact, a ballistic object's height, and the world-time polynomial coefficients including that actual observed quantum value.
2. `Space::publish_cpu_rule` observes **eight actual CPU memory bytes** to construct the original immutable two-coefficient `xgpu::Field`. Existing CPU, SSD and GPU ports route the same identity. No dense field is copied into a new app-local replacement authority.
3. The original `qssd::C12Window` binds that exact shared Field to the original GPU Virtual `Execution`. The lab kernel reads the polynomial, wraps each actor's phase, and computes a normalized float array. Every dispatch checks that the original source pointer is preserved. C12 output directly controls visible actor position, articulation, effects, mill blades and source audio. A known-answer test independently checks actual visible coordinates against the expected XI-authored polynomial.
4. The original `qssd::StateBus<World>` publishes the complete retained scene inputs: the pinned CPU/field lease, immutable C12 phase array, control outputs, clock and shared resource-region map. The presentation packet is projected from this publication. The physical GLES adapter owns presentation only.

These original components execute on the host CPU. GPU Virtual is an interpreter for its own logical execution model, not an Android GPU driver. This lab does not claim quantum hardware, quantum acceleration, infinite physical memory or a measured 120-FPS result.

## Exact copies and compatibility

`vendor/manifest.json` pins the four source commits and records the SHA-256 and Git-blob hash of every copied original file. All copied source bytes remain unmodified. No license files were present at the inspected repository roots; none were invented.

The original QSSD `prepare_gpu.py` and `prepare_c12.py` scripts generate the already-reviewed shared-field API overlays in `build/qssd-compat`. The original REVERSE `prepare-ether-compat.py` plus `ether_integration.py` generates the existing XI/runtime extensions in `build/ether-compat`. Those tools verify their upstream hashes before applying exact anchors. The REVERSE script includes its established memory-capacity and representation adaptations as well as the XI profile; the lab does not secretly replace the original runtime with another arithmetic implementation. Generated overlays and their `changes.diff` are build products, distinct from the immutable copies.

Run `python3 scripts/prepare_vendor.py` before compiling. Include the two generated overlay directories **before** original include directories. C++20 and `REVERSE_PC_HAVE_BOUNDED_PRODUCT_IMPORT=1` match the existing integration.

## Controlled A/B comparison

Both modes retain the same bounded **eight-region LRU cache**, with the same deterministic region contents and dynamic object math. Neither mode rebuilds an unchanged resource every frame. The coordinated mode prebuilds one region beyond the current three-region working set in Open World and Offscreen. The direct mode builds a missing region on arrival. This intentionally modest difference measures whether moving that preparation earlier changes arrival work. It does not assert less total work: preparation itself is included in the QSSD/resource stage time.

The other six scene workloads have identical backend resource behavior in both modes. Both execute the original CPU/QSSD/C12 path. The modes have exactly equal visible outputs at the same world time and input history, including all camera, light, audio and instance fields. Timing, cache counters and coordination metadata are excluded from the visible state hash.

`load=0/1/2/3/4` changes scene object budgets. Typical dynamic phase counts are 24/80/240/2400/12000; Effects uses 96/320/960/6000/24000. Calibration always uses four. The renderer determines the resulting physical triangles, calls, upload traffic and fragment overdraw. Changing the requested display cadence does not change simulation speed.

## World time, input and the offscreen hypothesis

World time is an absolute monotonic clock quantized at 120 ticks per second. Input events anchor constant velocity segments. XI analytically evaluates each segment and clamps contact against scene bounds. This avoids an integration rate tied to drawing frequency. The fighting scene clamps the controlled fighter against the other fighter and shows contact sparks. It is a small contact experiment, not a general rigid-body solver.

A touch delivered after the timestamp of the frame currently being sampled remains pending. The backend keeps the previously accepted control state until the original event timestamp is no later than the monotonic sample time; it then accepts that timestamp once. It never moves a future event backward to a frame timestamp. Duplicate and older event timestamps cannot replace the accepted state. Tests cover the boundary immediately before eligibility, exact eligibility, repeated timestamps with changed payloads, and sparse sampling that skips over the event time.

The offscreen mill retains world coordinates while the camera initially faces away. Its C12-authored blade phase and XI-authored ballistic object continue with world time, including when no intermediate frames are sampled. The ball follows a closed-form periodic gravity/rebound trajectory. Source audio varies with that same phase and distance. Global light intensity varies with phase; shadow casters remain in the scene. This demonstrates independent object time and resource preparation. It does **not** implement acoustic propagation, acoustic occlusion, local indirect light transport, autonomous AI or an arbitrary offscreen rigid-body simulation.

Open-world wildlife identity is derived from its fixed region and local slot. Camera movement cannot drag wildlife with it; revisiting a region uses the same time-dependent motion for that spatial identity. Region presentation uses a bounded working set; the complete infinite world is not materialized.

## Counters

| Packet field | Meaning |
|---|---|
| `source_revision` | Deterministic 120-Hz world tick; independent of draw cadence |
| `source_ns` | Monotonic timestamp of that quantized world tick |
| `physics_steps` | World ticks crossed since the previous sample; **not** solver iterations |
| `work_items` | C12 output lanes evaluated/read in this sample |
| `cpu_ns` | XI execution including its transactional state publication |
| `qssd_ns` | CPU rule publication/routing plus resource/cache work and StateBus publication |
| `virtual_gpu_ns` | Original C12 dispatch plus output-array observation |
| `cache_hits`, `cache_misses` | Cumulative region lookups/builds since configure, including prefetch lookups |
| `prepared_regions` | Cumulative regions built by lookahead |
| `hot_region_builds` | Cumulative regions first built in the needed working set |

`Backend::provenance()` returns a valid JSON object with the exact original commit pins, interpretation limits, cumulative actual CPU/C12 dispatch counts, shared-pointer handoffs, eight-byte CPU rule observation count, routed references, StateBus serial and retained region count. V2 also reports the original two-qubit quantum circuit: three gates once per configure, its actual observed XX signal and Q10 projection. The packet exposes these configuration counters; they are not per-frame gates. The quantum contribution changes the initial phase compared with v1 while A/B remains identical. See `COMPONENT_AUDIT_V2.md` for the separate five-class diagnostic suite and its honest representation/storage scopes.

## Validation

`tests/run_backend_tests.sh` verifies all original source hashes, regenerates the official compatibility overlays, compiles the real backend and runs the host tests. The suite checks every scene/load pair, A/B equality, sparse versus dense sample cadence with the same input event history, an independent visible-coordinate oracle, causal contact, offscreen gravity/rebound time, resource reuse in both modes, bounded cache retention, reset and monotonic-clock behavior. Host execution time is not a device frame-rate measurement. Android APK/device timing and compositor presentation evidence belong to the full lab, outside this backend unit suite.
