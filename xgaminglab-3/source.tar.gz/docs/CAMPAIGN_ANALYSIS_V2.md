# Campañas y análisis pareado — v2

## Entrega implementada

`CampaignPlan`, `ComparisonAnalysis` y `BottleneckAnalysis` son clases Java sin dependencias Android ni paquetes externos. Se ejecutan al preparar o analizar una campaña; no añaden trabajo por fotograma. El código de medición `FrameStats` conserva su contrato.

`CampaignPlan.scaleAbba(scene, blocks)` produce las cargas 0, 1, 2, 3 y 4. Para cada carga ejecuta los bloques solicitados en orden **A, B, B, A**, con A = coordinado y B = libre. `CampaignPlan.abba(scenes, loads, blocks)` permite seleccionar escenas y cargas. La selección conserva el orden recibido, exige valores únicos y admite escenas 0..7, cargas 0..4 y 1..64 bloques.

Cada entrada conserva `index`, `scene`, `load`, `block`, `position`, `pairIndex` y `coordinated`. Dentro del bloque se emparejan las posiciones 0/1 y 3/2: un par AB y un par BA. La identidad procede de `entryIndex`; el orden en que llegan los resultados no modifica los pares. La app debe conservar esta identidad en su JSON y en cualquier reconstrucción desde el historial.

Un bloque en una escena y las cinco cargas contiene 20 ejecuciones y 10 pares. Dos bloques contienen 40 ejecuciones. Con 2 s de calentamiento y 12 s de medición, esas 40 ejecuciones programan 560 s, antes de transiciones. `nominalDurationMs` calcula ese tiempo; no promete el instante exacto de finalización.

ABBA sitúa A y B en la misma posición media del bloque: `(0+3)/2 = (1+2)/2`. Es una decisión de diseño de este laboratorio para equilibrar orden. No es una garantía de Android/Khronos, un ensayo aleatorio ni una eliminación del calentamiento acumulado. Los cambios no lineales de temperatura, frecuencia, batería, sistema y caché pueden persistir. El escalado mantiene el orden de cargas solicitado y también necesita interpretar ese contexto.

## Integración

```java
CampaignPlan plan = CampaignPlan.scaleAbba(scene, 2);
for (CampaignPlan.Entry e : plan.entries()) {
    // Crear RunConfig con e.scene/e.load/e.coordinated y los mismos controles.
    // Guardar e.index, e.block, e.position y e.pairIndex con ese resultado.
}

ComparisonAnalysis.Measurement m =
    ComparisonAnalysis.Measurement.fromSnapshot(snapshot);
ComparisonAnalysis.Observation observation = new ComparisonAnalysis.Observation(
    entryIndex, configurationKey, warmupMs, requestedMeasurementMs,
    m, completed, environment);
ComparisonAnalysis.Summary summary =
    ComparisonAnalysis.analyze(plan, observations);
String json = summary.toJson();
String text = summary.spanishSummary();
```

El historial puede reconstruir `Measurement` con `Measurement.Builder`:

- `cadence(renderedCount, intervalCount, elapsedNs)` y `targetHz(hz)`.
- `dimensions(renderWidth, renderHeight, surfaceWidth, surfaceHeight)`.
- `frameTimes(frameMsP95, frameMsP99, onePercentLow)`.
- `stages(cpuMs, qssdMs, virtualGpuMs, geometryMs, submitMs, swapMs, gpuMs)`.
- `coverage(presentationFps, presentationCoverage, gpuCoverage)`.
- `integrity(invalidSamples, failedSwapCount, quantilesComplete)`.

Los campos no disponibles deben reconstruirse como `Double.NaN`, no como cero. El constructor conserva esos valores; el JSON los expresa como `null`. Las tasas de entrega se vuelven a calcular con conteo/tiempo, evitando confiar en un promedio de FPS suministrado por el llamador.

`configurationKey` debe representar todos los controles efectivos: versión de app/backend/renderizador, semilla, resolución solicitada, políticas de entrada y audio, opciones de trabajo CPU/QSSD/C12 y cualquier nuevo parámetro del prototipo. Se excluyen únicamente la variante A/B y los índices de organización de la campaña. El índice de una ejecución o su posición ABBA no debe contaminar la clave. Las campañas comparativas usan entrada automática reproducible; una interacción manual diferente no queda controlada sólo por compartir una semilla.

Además de la clave, el analizador comprueba explícitamente duración solicitada, calentamiento, objetivo, resolución renderizada/superficie e identidad de dispositivo cuando está disponible. Las escenas y cargas proceden de las entradas del plan. La app debe asociar cada observación a la entrada que realmente ejecutó.

`Environment` conserva identidad de dispositivo, mínimo/máximo de frecuencia observada, estado térmico inicial/máximo y ahorro de energía. Deben proceder de una ventana de observación declarada y consistente entre variantes; se recomienda usar la ventana medida. Si el informe utiliza también calentamiento, debe identificarlo en los metadatos de la app. `Environment.unknown()` marca explícitamente el contexto ausente. Un estado térmico 0 no demuestra que todos los relojes sean idénticos.

## Qué calcula y qué conserva

Cada par declara si es utilizable y un motivo: emparejado, ausente, duplicado, interrumpido, configuración distinta, calentamiento/duración distintos, dispositivo distinto, objetivo distinto, resolución distinta o cadencia inválida. Los pares no utilizables siguen en el informe, junto con **todas** las observaciones originales, incluidas las inesperadas y duplicadas. Nunca se elige la repetición más rápida para resolver un duplicado.

Los porcentajes usan `100 × (A/B − 1)`. Para FPS y 1 % lento, un porcentaje positivo significa un valor mayor; para p95/p99, un porcentaje negativo significa menor tiempo. Cada grupo de escena, carga y configuración publica media, mediana, mínimo, máximo y número disponible de esos cambios pareados. Los valores extremos permanecen en todas esas cuentas. Un valor ausente no se convierte en una mejora de cero.

Las tasas agrupadas usan la suma de intervalos dividida por la suma de tiempo de las ejecuciones compatibles. No promedian FPS instantáneos. Tampoco se fabrica un p99 global promediando p99 de ejecuciones: `p99ChangePct` resume cambios entre percentiles de cada par, con ese nombre y alcance.

Las diferencias térmicas, de frecuencia o ahorro de energía generan avisos y permanecen en el resumen descriptivo. No se eliminan las ejecuciones calientes o lentas. También aparecen cobertura parcial de presentación/GPU, errores de muestras, menos de 100 intervalos, percentiles no disponibles y ventanas medidas que difieren materialmente de la duración solicitada. El aviso temporal utiliza una tolerancia declarada de `max(100 ms, 2 × intervalo medio)`; señala contexto, sin borrar el resultado.

No se exporta una prueba de significación, un intervalo de confianza ni una conclusión causal. Los pares de un mismo bloque pueden estar correlacionados. Con pocas repeticiones, media, mediana y rango describen lo observado y no establecen una distribución de rendimiento del dispositivo.

## Hipótesis de coste

`BottleneckAnalysis.inspect(measurement, environment, coordinated)` devuelve `candidate`, `titleEs`, `explanationEs`, evidencia numérica, avisos y `confidence: "heuristic"`. Su limitación se incluye siempre en JSON.

Las reglas distinguen cadencia de entrega próxima al objetivo, posible límite de pantalla/pacing, una etapa de coste relevante, espera de swap y casos sin explicación suficiente. Una etapa candidata debe ocupar al menos la mitad del intervalo medio y del presupuesto solicitado. Una hipótesis sobre GPU física exige además cobertura de temporizador de al menos 80 %. Son umbrales explícitos de este laboratorio, no criterios normativos de Android o Khronos.

Una espera larga de swap no identifica por sí sola una GPU saturada: puede reflejar pacing o cola. Las medias por etapa tampoco reconstruyen una ruta crítica por fotograma y CPU/GPU pueden solaparse. La ejecución C12 se identifica como trabajo sobre CPU anfitriona. Estos datos permiten estudiar el prototipo, pero no prueban aceleración de hardware cuántico ni una ventaja cuántica.

## Investigación primaria aplicada

Fuentes consultadas el 9 de noviembre de 2026. Las siguientes decisiones corresponden a la implementación entregada, con su alcance específico:

1. **Cadencia y presentación.** Android explica que enviar lo más rápido posible puede llenar la cola y aumentar latencia; Choreographer por sí solo tampoco resuelve todos los casos. Por ello se conservan métricas de entrega, presentación, cobertura y contexto de frecuencia por separado. [Android Frame Pacing](https://developer.android.com/games/sdk/frame-pacing).
2. **Frecuencia solicitada.** `Surface.setFrameRate` expresa una preferencia y el sistema puede conservar otra frecuencia. El objetivo no se interpreta como una frecuencia física conseguida. [Android frame rate API](https://developer.android.com/media/optimize/performance/frame-rate).
3. **GPU física.** Khronos especifica consultas asíncronas; los relojes CPU no garantizan que los comandos gráficos hayan terminado, y `glFinish` altera la ejecución al esperar. Un resultado disjoint invalida los tiempos afectados; el contador puede tener cero bits útiles. Se conservan IDs y cobertura y no se inventa un tiempo GPU a partir de CPU. [EXT_disjoint_timer_query](https://registry.khronos.org/OpenGL/extensions/EXT/EXT_disjoint_timer_query.txt).
4. **Calentamiento y caché.** Android distingue los costes repetidos, el calentamiento, las cachés y la variación dinámica de relojes. Los dos segundos de este laboratorio definen una fase excluida; no certifican estabilización térmica ni constituyen una duración universal suficiente. La política se exporta y se exige igual dentro del par. [Android Microbenchmark](https://developer.android.com/topic/performance/benchmarking/microbenchmark-overview).
5. **Distribuciones.** La documentación de Macrobenchmark publica distribuciones p50/p90/p95/p99 y distingue duración CPU y sobrepaso del plazo. Ese ejemplo se refiere a sus métricas de UI; el laboratorio conserva el nombre y alcance de sus propios intervalos de finalización nativa. Los percentiles por ejecución se comparan sin inventar percentiles globales. [Capture Macrobenchmark metrics](https://developer.android.com/topic/performance/benchmarking/macrobenchmark-metrics).
6. **Térmica.** Android recomienda observar la condición térmica y documenta dispositivos cuyo estado puede permanecer en NONE sin reflejar toda la presión real. `getThermalHeadroom` puede ser no disponible y no debe consultarse más de una vez cada diez segundos; su escala no es una temperatura en grados. El analizador presenta diferencias de contexto sin afirmar igualdad térmica demostrada. [Android Thermal API](https://developer.android.com/games/optimize/adpf/thermal).
7. **Artefacto medido.** Android aconseja que la variante de benchmark se acerque a producción y sea no depurable. Se debe conservar la versión/firma/compilación del artefacto utilizado para comparar resultados reproducibles. [Write a Macrobenchmark](https://developer.android.com/topic/performance/benchmarking/macrobenchmark-overview).

## Verificación de esta entrega

`bash tests/run-campaign-analysis.sh` compila únicamente Java del dominio, ejecuta comprobaciones deterministas y valida el JSON con un parser Python independiente. Puede configurarse `FRAME_STATS_JAVAC`/`FRAME_STATS_JAVA` para elegir ejecutables. La evidencia conservada contiene el comando exacto, entorno, resultado y huellas de los archivos.

Las pruebas construyen resultados conocidos para verificar aritmética, emparejamiento, persistencia de extremos/avisos, reconstrucción, campos ausentes y reglas heurísticas. Sus números no son mediciones de un teléfono, de GPU física, de un emulador ni de una máquina cuántica.
