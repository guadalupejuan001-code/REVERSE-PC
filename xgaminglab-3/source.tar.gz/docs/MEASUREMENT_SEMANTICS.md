# Measurement semantics

This document specifies the Java accumulator and report contract implemented by `src/x/lab/gaming/FrameStats.java` and `RunResult.java`. It describes measurements of this application's synthetic scenes. Host tests establish arithmetic and validation behavior; they do not establish any Android device's FPS, GPU speed, display refresh, power use, or thermal behavior.

## Integration and ownership

```java
FrameStats stats = new FrameStats(targetHz);
// After warmup, on the same owner thread for this measured run:
stats.record(reusedNativeMetrics); // double[64], native/lab_api.hpp slots
FrameStats.Snapshot result = stats.snapshot();
String json = result.toJson();
```

`record` retains no caller array and allocates no objects. Constructor allocation creates bounded storage; `reset` reuses it. `snapshot` allocates independent arrays and sorts the stored intervals. It belongs at a reporting cadence, not in every frame. The class is thread confined: call `record`, `reset`, and `snapshot` on one owner thread or provide external synchronization. A returned snapshot is immutable and can be passed to the UI; its array accessors return defensive copies. The app currently builds telemetry snapshots on that owner thread every 500 ms, so their allocation/sort cost can affect subsequent completion intervals; the wall-clock result includes instrumentation overhead.

The caller starts a fresh statistics scope after warmup and cancels or resets it for pauses, configure changes, context recreation, or other changes in test conditions. A decreasing serial or changed context cannot silently become part of an existing run. `record` returns `false` for an invalid primary record and increments the appropriate diagnostics. A well-formed failed swap returns `true`, increments `failedSwapCount`, and contributes no successful completion or presentation identity.

The first accepted native serial defines the measured cohort. Presentation and GPU results can arrive several frames later, so identity filtering is essential: results whose IDs precede that first serial are warmup results and are excluded, even when their timestamps arrive after warmup ends.

## Coordinated callback gate

`VsyncGate(int targetHz)` is an allocation-free scheduling helper, separate from `FrameStats`. The UI owner calls `shouldRender(vsyncNs)` on every display callback before checking whether the renderer is busy. An admitted period is consumed even when the renderer cannot take the work. A long gap skips old periods and admits at most one request; it never queues catch-up frames. Call `reset()` when starting a new case.

Coordinated mode respects the requested cadence up to the callbacks the platform supplies. A 120 Hz request on 90 Hz callbacks admits all 90 callbacks; 60 on 120 admits every second callback. At 60 on 90, the available callbacks quantize output gaps to approximately 11.11 and 22.22 ms with a 60-per-second average. This is a scheduling constraint, not evidence of that physical presentation rate. Free mode has no app-imposed cadence cap; the graphics implementation or operating system can still limit it.

The gate anchors an integer period index to the first valid callback. It uses 1 microsecond of boundary tolerance at ordinary display rates to absorb timestamp rounding, without repeated rounded-period drift. An inclusive one-second sequence contains its initial endpoint plus subsequent intervals: 61 admitted endpoints represent 60 intervals, not 61 FPS. Nonpositive and reversed timestamps reject the affected callback and clear the scheduling phase; repeated timestamps are rejected without moving the phase. The diagnostic getters expose those conditions. A clock discontinuity also requires the caller to cancel/reset its separate measurement scope.

## Completion, presentation, and GPU work

| Field | Meaning |
| --- | --- |
| `attemptedCount` | Accepted, well-formed native records, including failed swaps. |
| `renderedCount` | Accepted records with `SWAP_SUCCEEDED == 1`. This means native frame/swap completion, not GPU completion or physical display presentation. |
| `swapFps` | Number of intervals between successful native completions divided by elapsed time between their first and last `END_NS`. |
| `presentedCount` | Unique real presentation timestamps whose original frame IDs match successful measured submissions. |
| `presentationFps` | Intervals between accepted real presentation timestamps divided by their timestamp duration. Unavailable with fewer than two accepted points. |
| `presentationCoverage` | `presentedCount / renderedCount`. Always inspect this alongside presentation FPS. |
| `gpuMs` | Mean of valid asynchronous GPU durations matched to successful measured frame IDs. |
| `gpuSamples`, `gpuCoverage` | Accepted GPU query count and that count divided by `renderedCount`. |

Native `END_NS` is sampled after swap and timestamp polling. Therefore `swapFps` is the wall-clock cadence of successful native frame completions, including the effects of scheduling and intervening work. `SWAP_NS` is the time inside `eglSwapBuffers` itself; it is a different measurement. For 121 successful endpoints spanning one second there are 120 intervals and the rate is 120 FPS. Instantaneous FPS values are never arithmetically averaged.

`PRESENT_NS` must come from `EGL_DISPLAY_PRESENT_TIME_ANDROID` and be associated with the original native `SERIAL`. An expected/requested presentation time is a scheduling hint and must never be passed as observed presentation evidence. The EGL specification distinguishes those timestamps, defines pending/invalid results, and provides frame IDs for correlation. See [EGL_ANDROID_get_frame_timestamps](https://android.googlesource.com/platform/frameworks/native/+/master/opengl/specs/EGL_ANDROID_get_frame_timestamps.txt).

Presentation samples must be positive, valid integer nanoseconds in the same monotonic clock domain as native `BEGIN_NS`/`END_NS`; belong to a successful measured ID; fall between the first measured begin and the observation's end; and advance the accepted presentation timeline. Repeated IDs, unknown IDs, backward times, and future times are rejected with separate counters. A supported extension with no valid samples still yields unavailable presentation FPS.

Incomplete presentation coverage can result from pending tail frames, unsupported/invalid queries, discarded entries, or frames never physically presented. This accumulator does not infer which missing frames appeared on screen. In particular, an observed rate with partial coverage is not proof of complete display capture. A caller that ends collection without draining pending queries should expect incomplete tail coverage and retain the exported pending/coverage diagnostics.

`GPU_NS` belongs to asynchronous `GPU_SAMPLE_ID`, not automatically the current frame. Missing, pending, or disjoint query results are unavailable. The native timer covers the renderer's shadow, scene, and upscale commands; it excludes swap and the system compositor. Duplicate, unknown, and warmup query IDs are excluded. No GPU duration is estimated from CPU duration or FPS.

## Frame time distribution and budget

`frameMsP50`, `frameMsP95`, `frameMsP99`, `maxFrameMs`, and `onePercentLow` use intervals between successful native completion endpoints. Failed swaps remain visible as gaps between successful endpoints. The initial completion establishes a baseline and has no invented preceding interval.

Quantiles use nearest rank: sort the intervals and select index `ceil(p * n) - 1`. The 1% low value is `1000 / mean(worst ceil(n / 100) intervals in milliseconds)`. It is not the reciprocal of p99. For 99 intervals of 8 ms and one of 40 ms, nearest-rank p99 is 8 ms, the maximum is 40 ms, and the 1% low is 25 FPS.

The requested time budget is `1,000,000,000 / targetHz` nanoseconds. `missedIntervals` counts intervals greater than the ceiling of that budget; the ceiling accommodates only the clock's integer-nanosecond rounding. At 120 Hz, nominal evenly spaced samples alternate between 8,333,333 and 8,333,334 ns. No additional percentage tolerance is applied. `missedBudgetRatio` divides misses by valid completion intervals. This is a completion-cadence budget check, not an Android compositor deadline/jank classification.

Default storage retains 65,536 intervals and matching recent frame identities, enough for 300 seconds at 120 samples per second. Rates, maximum, miss counts, and histogram aggregate the whole run independently of retained ring size. If intervals overflow, `quantilesComplete` becomes false and whole-run quantiles/1% low become unavailable rather than silently changing into rolling-window statistics. `intervalOverflowCount` exposes the number of evicted intervals.

`recentFrameMs()` contains the latest up to 240 intervals in chronological order. `histogramCounts()` covers the whole run. The nine bins use upper bounds of 0.5, 1, 1.5, 2, 3, 4, 6, and 12 times the requested budget, then an open-ended last bin. The one-budget boundary uses the same ceiling as deadline checks. Bounds are inclusive on the upper side; the last bound serializes as `null` to mean open ended.

## Stage durations, state, and counts

`cpuMs`, `qssdMs`, `virtualGpuMs`, `geometryMs`, `submitMs`, `swapMs`, `stateAgeMs`, and `inputToSubmitMs` are arithmetic means of available nonnegative durations in their corresponding native slots. Unavailable `-1` values do not enter the mean as zeros. These scopes are defined by native instrumentation; do not sum them into a GPU/display latency claim. In particular, GPU work may overlap CPU work.

`inputToSubmitMs` is measured only when the renderer observes a new valid input timestamp. It ends at submission, not presentation or touch-to-photon response. If the caller estimates the event timestamp from millisecond Android input timestamps, that conversion limits precision. `inputEvents` counts distinct timestamps observed by rendering, not every system input event.

`SOURCE_REVISION` is the backend's monotonic 120 Hz world tick within its configure domain. `sourceStatesObserved` counts observed increases, not every skipped intermediate tick. `reusedSourceStates` counts submissions that observe the same source revision. Reusing a source state does not imply identical rendered images: input, camera, or other rendering changes may differ. Unknown or regressing source revisions make `sourceStateHz` unavailable; they never create invented updates. Reset the accumulator when the source revision domain changes.

| Native metrics | Java aggregation |
| --- | --- |
| `OBJECTS`, `TRIANGLES`, `DRAW_CALLS` | Latest value and arithmetic per-record mean. |
| `UPLOAD_BYTES`, `WORK_ITEMS`, `PHYSICS_STEPS` | Sum of per-record values. Work items are C12 output lanes read; physics steps are world-clock ticks crossed, not solver iterations. |
| `CACHE_HITS`, `CACHE_MISSES`, `PREPARED_REGIONS`, `HOT_REGION_BUILDS`, `INPUT_EVENTS` | Deltas of cumulative counters after the first reading establishes a baseline. |
| `PRESENT_LOST`, `PRESENT_PROCESSED`, `PRESENT_DISCARDED`, `GPU_DISCARDED` | Native cumulative diagnostic deltas after the first reading. |
| `PRESENT_PENDING` | Latest queue-length gauge. |

Decreasing cumulative counters increment `counterResets` and establish a new baseline without negative increments. Warmup's first-read counter totals are excluded. However, native diagnostic deltas can include delayed processing of warmup frames; only Java `presentedCount` and `gpuSamples` apply measured-frame identity filtering. Do not equate `nativePresentProcessed` with `presentedCount`. Lost and discarded presentation entries are separate native outcomes, not interchangeable or automatically additive measures of physical missed refreshes.

The `STATE_HASH` slot is intentionally not used as exact state proof here: a `double[64]` protocol cannot preserve every 64-bit integer. Source equivalence tests should compare the backend's original integer hash before conversion.

## Report and device context

`Snapshot.toJson()` exports schema `x-gaming-lab-metrics-v1`, explicit scope strings, statistics, diagnostic counts, chart samples, and histogram. Unavailable or nonfinite numbers become JSON `null`. `RunResult` optionally wraps a snapshot with scene, mode, completion flag, and stop reason using schema `x-gaming-lab-run-v1`. Android UI/session code adds the device, display, settings, thermal status, audio status, test configuration, and application/source version.

Record actual display refresh and requested refresh separately. Android documents that `Surface.setFrameRate` expresses intent but does not guarantee the requested refresh; the app must remain correct when the platform retains another mode. See [Android frame rate API](https://developer.android.com/media/optimize/performance/frame-rate). Similarly, Choreographer ticks alone are not evidence of smooth physical presentation or freedom from buffer queue latency. See [Android Frame Pacing](https://developer.android.com/games/sdk/frame-pacing).

A reproducible comparison requires the same scene, load, resolution, seed, duration, input policy, audio setting, and relevant device state. The coordinated/free modes also differ in pacing and, for streaming scenes, advance region preparation. Results therefore measure that combined configuration change, not an isolated causal contribution of every component. Compare thermal/display metadata and repeated runs before attributing a difference to the software change.

## Reproducible host verification

Run `bash tests/run-frame-stats.sh` with Java, javac, and Python 3 available, and `bash tests/run-vsync-gate.sh` for callback cadence tests. The optional `FRAME_STATS_JAVAC` and `FRAME_STATS_JAVA` variables select executables. The runners compile only dependency-free Java, verify native metric-slot agreement, check arithmetic/validation/reset/overflow/identity and cadence rules, measure reused-input allocation where the host JVM supports it, and parse report JSON independently with Python. Recorded command, environment, source fingerprints, and output are in `docs/FRAME_STATS_TEST_EVIDENCE.txt`.

These are deterministic logic tests using constructed timestamps. They are not a phone benchmark, a browser test, an emulator performance result, or evidence that a physical device sustains 120 FPS.
