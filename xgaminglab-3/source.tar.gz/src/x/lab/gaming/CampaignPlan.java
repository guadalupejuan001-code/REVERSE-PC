package x.lab.gaming;

/**
 * Immutable, deterministic campaign order. A is coordinated and B is free.
 * Every scene/load repetition is A-B-B-A. Pair 0 uses positions 0/1 and
 * pair 1 uses positions 3/2, retaining one AB and one BA observation pair.
 * Settings, warmup and duration belong to the caller's RunConfig.
 */
public final class CampaignPlan {
    public final int runCount, pairCount, blocksPerSceneLoad, sceneCount, loadCount;
    private final Entry[] entries;

    public static CampaignPlan scaleAbba(int scene, int blocks) {
        return abba(new int[]{scene},new int[]{0,1,2,3,4},blocks);
    }

    public static CampaignPlan abba(int[] scenes, int[] loads, int blocks) {
        checkSelection(scenes,7,"scenes");checkSelection(loads,4,"loads");
        if(blocks<1||blocks>64)throw new IllegalArgumentException("blocks must be 1..64");
        return new CampaignPlan(scenes.clone(),loads.clone(),blocks);
    }

    private CampaignPlan(int[] scenes,int[] loads,int blocks) {
        blocksPerSceneLoad=blocks;sceneCount=scenes.length;loadCount=loads.length;
        runCount=sceneCount*loadCount*blocks*4;pairCount=runCount/2;
        entries=new Entry[runCount];int index=0,globalBlock=0;
        for(int scene:scenes)for(int load:loads)for(int block=0;block<blocks;block++) {
            for(int position=0;position<4;position++) {
                boolean coordinated=position==0||position==3;
                entries[index]=new Entry(index,scene,load,block,position,
                        globalBlock*2+(position>=2?1:0),coordinated);
                index++;
            }
            globalBlock++;
        }
    }

    private static void checkSelection(int[] values,int maximum,String name) {
        if(values==null||values.length==0)throw new IllegalArgumentException(name+" must be nonempty");
        boolean[] seen=new boolean[maximum+1];
        for(int value:values) {
            if(value<0||value>maximum||seen[value])
                throw new IllegalArgumentException(name+" must contain unique values in 0.."+maximum);
            seen[value]=true;
        }
    }

    public Entry entry(int index) { return entries[index]; }
    public Entry[] entries() { return entries.clone(); }
    public int size() { return runCount; }

    /** Scheduled time excluding transitions, pauses, and report work. */
    public long nominalDurationMs(long warmupMs,long measurementMs) {
        if(warmupMs<0||measurementMs<=0)throw new IllegalArgumentException("invalid run duration");
        return Math.multiplyExact(Math.addExact(warmupMs,measurementMs),(long)runCount);
    }

    public String toJson() {
        StringBuilder b=new StringBuilder();b.append("{\"schema\":\"x-gaming-lab-campaign-v2\"");
        FrameStats.field(b,"order","ABBA");FrameStats.field(b,"modeA","coordinated");
        FrameStats.field(b,"modeB","free");FrameStats.field(b,"runCount",runCount);
        FrameStats.field(b,"pairCount",pairCount);FrameStats.field(b,"blocksPerSceneLoad",blocksPerSceneLoad);
        b.append(",\"entries\":[");
        for(int i=0;i<entries.length;i++){if(i>0)b.append(',');b.append(entries[i].toJson());}
        return b.append("]}").toString();
    }

    public static final class Entry {
        public final int index,scene,load,block,position,pairIndex;
        public final boolean coordinated;
        private Entry(int index,int scene,int load,int block,int position,int pairIndex,boolean coordinated) {
            this.index=index;this.scene=scene;this.load=load;this.block=block;
            this.position=position;this.pairIndex=pairIndex;this.coordinated=coordinated;
        }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"index\":").append(index);
            FrameStats.field(b,"scene",scene);FrameStats.field(b,"load",load);
            FrameStats.field(b,"block",block);FrameStats.field(b,"position",position);
            FrameStats.field(b,"pairIndex",pairIndex);FrameStats.field(b,"coordinated",coordinated);
            return b.append('}').toString();
        }
    }
}
