package x.lab.gaming;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.PowerManager;
import android.view.Display;
import org.json.JSONArray;
import org.json.JSONObject;

final class DeviceInfo {
    static int maxHz(Activity a) {
        Display d=a.getWindowManager().getDefaultDisplay();float highest=d.getRefreshRate();
        Display.Mode active=d.getMode();
        for(Display.Mode m:d.getSupportedModes())if(m.getPhysicalWidth()==active.getPhysicalWidth()&&m.getPhysicalHeight()==active.getPhysicalHeight())highest=Math.max(highest,m.getRefreshRate());
        return Math.max(1,Math.round(highest));
    }
    static int thermal(Context c){return Build.VERSION.SDK_INT>=29?((PowerManager)c.getSystemService(Context.POWER_SERVICE)).getCurrentThermalStatus():-1;}
    static String thermalName(int s){String[] n={"Normal","Leve","Moderada","Alta","Crítica","Emergencia","Apagado"};return s>=0&&s<n.length?n[s]:"No disponible";}
    static JSONObject capture(Activity a) {
        JSONObject j=new JSONObject();
        try {
            Display d=a.getWindowManager().getDefaultDisplay();Display.Mode current=d.getMode();
            j.put("manufacturer",Build.MANUFACTURER);j.put("model",Build.MODEL);j.put("device",Build.DEVICE);
            j.put("availableProcessors",Runtime.getRuntime().availableProcessors());j.put("javaHeapUsedBytes",Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory());j.put("nativeHeapAllocatedBytes",android.os.Debug.getNativeHeapAllocatedSize());
            if(Build.VERSION.SDK_INT>=31){j.put("socManufacturer",Build.SOC_MANUFACTURER);j.put("socModel",Build.SOC_MODEL);}
            j.put("android",Build.VERSION.RELEASE);j.put("sdk",Build.VERSION.SDK_INT);j.put("abis",new JSONArray(Build.SUPPORTED_ABIS));
            j.put("activeRefreshHz",d.getRefreshRate());j.put("displayWidth",current.getPhysicalWidth());j.put("displayHeight",current.getPhysicalHeight());
            JSONArray modes=new JSONArray();for(Display.Mode m:d.getSupportedModes()){JSONObject v=new JSONObject();v.put("width",m.getPhysicalWidth());v.put("height",m.getPhysicalHeight());v.put("refreshHz",m.getRefreshRate());modes.put(v);}j.put("displayModes",modes);
            PowerManager p=(PowerManager)a.getSystemService(Context.POWER_SERVICE);j.put("powerSaveMode",p.isPowerSaveMode());j.put("thermalStatus",thermal(a));
            Intent b=a.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(b!=null){j.put("batteryTemperatureC",b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0)/10.0);j.put("plugged",b.getIntExtra(BatteryManager.EXTRA_PLUGGED,0));}
            ActivityManager.MemoryInfo memory=new ActivityManager.MemoryInfo();((ActivityManager)a.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(memory);j.put("totalRamBytes",memory.totalMem);j.put("availableRamBytes",memory.availMem);
        } catch(Exception e){try{j.put("metadataError",e.toString());}catch(Exception ignored){}}
        return j;
    }
}
