package x.lab.gaming;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

final class FrameChart extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path line=new Path();
    private double[] samples=new double[0];
    private double budget=1000.0/120;
    FrameChart(Context c){super(c);setContentDescription("Gráfica del tiempo de los fotogramas recientes");}
    void update(double[] samples,int target){this.samples=samples;budget=1000.0/Math.max(1,target);invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight();
        double top=budget*3;for(double v:samples)if(Double.isFinite(v))top=Math.max(top,Math.min(v,250));
        paint.setColor(0xFF344459);paint.setStrokeWidth(1);float y=(float)(h-budget/top*h);c.drawLine(0,y,w,y,paint);
        if(samples.length<2)return;
        line.reset();int count=Math.min(180,samples.length),offset=samples.length-count;
        for(int i=0;i<count;i++){float x=i*w/(count-1),v=(float)(h-Math.min(top,Math.max(0,samples[offset+i]))/top*h);if(i==0)line.moveTo(x,v);else line.lineTo(x,v);}
        paint.setColor(0xFFB7F752);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);c.drawPath(line,paint);paint.setStyle(Paint.Style.FILL);
    }
}
