package x.lab.gaming;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.AtomicFile;
import android.view.Gravity;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class MainActivity extends Activity implements FrameLoop.Listener {
    private static final int BG=0xFF080E18,PANEL=0xFF121D2C,LINE=0xFF28384D,TEXT=0xFFF3F6FC,MUTED=0xFF9DAEC5,LIME=0xFFB7F752,PURPLE=0xFFB8A5FF;
    private FrameLayout root;
    private String screen="";
    private FrameLoop loop;
    private ComponentRunner componentRunner;
    private boolean componentRunning;
    private TextView componentStatus,componentEvidence;
    private Spinner graphicsSpinner,componentLoadSpinner;
    private int selectedGraphics;
    private static final int[] TARGETS={0,60,90,120,144,165,240};
    private ReportStore store;
    private SharedPreferences preferences;
    private int selectedScene=1,selectedLoad=1,selectedMode=0,selectedResolution=1,selectedTarget=0;
    private boolean selectedAudio=false,showingLive=false,resumeAfterInterruption=false;
    private Spinner loadSpinner,resolutionSpinner,targetSpinner,modeSpinner;
    private CheckBox audioCheck;
    private TextView fpsValue,fpsLabel,liveTitle,livePhase,liveNumbers,liveDevice,liveHint;
    private FrameChart chart;
    private ProgressBar progress;
    private JSONObject session,displayedReport;
    private JSONArray results;
    private String sessionId,sessionLabel;
    private long sessionStarted;
    private int caseIndex,caseCount,maxThermal;
    private int loopGeneration;
    private final ArrayList<JSONObject> thermalSamples=new ArrayList<>();

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
        preferences=getSharedPreferences("lab",MODE_PRIVATE);
        selectedScene=preferences.getInt("scene",1);selectedLoad=preferences.getInt("load",1);
        selectedMode=preferences.getInt("mode",0);selectedResolution=preferences.getInt("resolution",1);
        selectedGraphics=preferences.getInt("graphics",0);selectedTarget=preferences.getInt("target",0);selectedAudio=preferences.getBoolean("audio",false);
        store=new ReportStore(this);root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(i.left,i.top,i.right,i.bottom);}
            else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });root.requestApplyInsets();showHome();
    }
    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("tnum");if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;}
    private GradientDrawable background(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(14));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void gap(LinearLayout l,int height){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private Button button(String label,boolean primary,Runnable action){Button b=new Button(this);b.setText(label);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(primary?BG:TEXT);b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setBackground(background(primary?LIME:PANEL,primary?0:LINE));b.setMinHeight(dp(44));b.setMinimumHeight(dp(44));b.setPadding(dp(14),dp(8),dp(14),dp(8));b.setOnClickListener(v->action.run());return b;}
    private LinearLayout page(){root.removeAllViews();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout body=column();body.setPadding(dp(22),dp(18),dp(22),dp(22));scroll.addView(body,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new FrameLayout.LayoutParams(-1,-1));return body;}
    private void endLoop(){
        ++loopGeneration;
        if(componentRunning){componentRunning=false;if(componentRunner!=null)componentRunner.stop();componentRunner=null;try{saveSession(false);}catch(Exception ignored){}}
        if(showingLive&&session!=null){try{saveSession(false);}catch(Exception ignored){}}
        FrameLoop old=loop;loop=null;if(old!=null)old.close(false);showingLive=false;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void showHome(){
        endLoop();screen="Escenarios";LinearLayout body=page();
        LinearLayout header=row();TextView mark=text("X",30,BG,true);mark.setGravity(Gravity.CENTER);mark.setBackground(background(LIME,0));header.addView(mark,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout title=column();title.setPadding(dp(14),0,0,0);title.addView(text("Gaming Lab · PC",26,TEXT,true));title.addView(text("Núcleo · CPU · GPU · QSSD   /   Laboratorio 3.0",12,MUTED,false));header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        header.addView(button("Historial",false,this::showHistory),new LinearLayout.LayoutParams(-2,dp(44)));body.addView(header);gap(body,12);navigation(body,"Escenarios");
        gap(body,14);
        LinearLayout info=row();info.setPadding(dp(12),dp(8),dp(12),dp(8));info.setBackground(background(PANEL,0));
        info.addView(text(Build.MODEL+"  ·  "+DeviceInfo.maxHz(this)+" Hz máx. de pantalla",12,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));
        TextView scope=text("Escenas sintéticas propias · sin conexión",12,MUTED,false);info.addView(scope);body.addView(info);gap(body,14);
        body.addView(text("ELIGE UNA SITUACIÓN",11,MUTED,true));gap(body,8);
        for(int r=0;r<2;r++){
            LinearLayout line=row();for(int k=0;k<4;k++){
                final int scene=r*4+k;LinearLayout card=column();card.setPadding(dp(12),dp(10),dp(12),dp(10));card.setBackground(background(scene==selectedScene?0xFF223323:PANEL,scene==selectedScene?LIME:LINE));
                TextView name=text(RunConfig.NAMES[scene],15,scene==selectedScene?LIME:TEXT,true);card.addView(name);gap(card,4);
                TextView detail=text(RunConfig.DETAILS[scene],11,MUTED,false);detail.setMinLines(2);card.addView(detail);
                card.setContentDescription("Escena "+RunConfig.NAMES[scene]);card.setOnClickListener(v->{readSettings();selectedScene=scene;saveSettings();showHome();});
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(k>0)p.leftMargin=dp(8);line.addView(card,p);
            }body.addView(line,new LinearLayout.LayoutParams(-1,dp(94)));gap(body,8);
        }
        LinearLayout settings=row();
        loadSpinner=setting(settings,"Carga",RunConfig.LOADS,selectedLoad);
        resolutionSpinner=setting(settings,"Resolución",new String[]{"50% por eje","75% por eje","100% nativa"},selectedResolution);
        targetSpinner=setting(settings,"Objetivo",new String[]{"Máximo de pantalla","60 FPS","90 FPS","120 FPS","144 FPS","165 FPS","240 FPS"},selectedTarget);
        modeSpinner=setting(settings,"Coordinación",new String[]{"Con la pantalla","Libre"},selectedMode);
        body.addView(settings);gap(body,8);LinearLayout graphicsRow=row();graphicsSpinner=setting(graphicsRow,"Ruta de dibujo · compara con la referencia",RunConfig.GRAPHICS,selectedGraphics);graphicsRow.addView(text("Masiva / extrema: miles de actores y partículas.\nLa carga elegida permanece fija durante cada prueba.",11,MUTED,false),new LinearLayout.LayoutParams(0,-2,1));body.addView(graphicsRow);
        audioCheck=new CheckBox(this);audioCheck.setText("Añadir audio sintético de la escena");audioCheck.setTextColor(MUTED);audioCheck.setTextSize(12);audioCheck.setChecked(selectedAudio);audioCheck.setButtonTintList(ColorStateList.valueOf(LIME));body.addView(audioCheck);
        gap(body,10);LinearLayout actions=row();
        addAction(actions,button("Medir escena · 30 s",true,()->startPlan(0)));
        addAction(actions,button("Batería · 2 min",false,()->startPlan(1)));
        addAction(actions,button("Comparar A/B · 1 min",false,()->startPlan(2)));
        addAction(actions,button("Resistencia · 15 min",false,()->startPlan(3)));
        LinearLayout footer=column();footer.setPadding(dp(16),dp(8),dp(16),dp(8));footer.setBackgroundColor(BG);footer.addView(actions,new LinearLayout.LayoutParams(-1,dp(48)));
        FrameLayout.LayoutParams footerParams=new FrameLayout.LayoutParams(-1,dp(64),Gravity.BOTTOM);root.addView(footer,footerParams);
        View scrolling=root.getChildAt(0);scrolling.setPadding(0,0,0,dp(70));((ScrollView)scrolling).setClipToPadding(false);
        gap(body,12);TextView explanation=text("A/B repite cada escena con la misma carga. Se registran tiempos, FPS, tirones, resolución y temperatura. Los resultados se guardan en este dispositivo.",12,MUTED,false);body.addView(explanation);
        gap(body,8);TextView about=text("Qué mide y cómo funciona",12,PURPLE,true);about.setPadding(0,dp(8),0,dp(8));about.setOnClickListener(v->showHelp());body.addView(about);
    }
    private void addAction(LinearLayout row,Button b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1);if(row.getChildCount()>0)p.leftMargin=dp(8);row.addView(b,p);}
    private Spinner setting(LinearLayout parent,String label,String[] values,int selection){
        LinearLayout group=column();group.addView(text(label,11,MUTED,true));Spinner spinner=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,values);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);spinner.setSelection(Math.max(0,Math.min(values.length-1,selection)));group.addView(spinner,new LinearLayout.LayoutParams(-1,dp(42)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);if(parent.getChildCount()>0)p.leftMargin=dp(10);parent.addView(group,p);return spinner;
    }
    private void readSettings(){if(!"Escenarios".equals(screen)||loadSpinner==null)return;selectedLoad=loadSpinner.getSelectedItemPosition();selectedResolution=resolutionSpinner.getSelectedItemPosition();selectedTarget=targetSpinner.getSelectedItemPosition();selectedMode=modeSpinner.getSelectedItemPosition();if(graphicsSpinner!=null)selectedGraphics=graphicsSpinner.getSelectedItemPosition();if(audioCheck!=null)selectedAudio=audioCheck.isChecked();saveSettings();}
    private void saveSettings(){preferences.edit().putInt("scene",selectedScene).putInt("graphics",selectedGraphics).putInt("load",selectedLoad).putInt("resolution",selectedResolution).putInt("target",selectedTarget).putInt("mode",selectedMode).putBoolean("audio",selectedAudio).apply();}
    private void startPlan(int kind){
        readSettings();int hz=selectedTarget==0?DeviceInfo.maxHz(this):TARGETS[selectedTarget];float resolution=new float[]{.5f,.75f,1f}[selectedResolution];
        ArrayList<RunConfig> plan=new ArrayList<>();CampaignPlan campaign=null;
        sessionLabel=kind==0?"Escena individual":kind==1?"Ocho escenarios":kind==2?"Coordinación ABBA":kind==3?"Resistencia · 15 min":kind==4?"Escalado masivo ABBA":kind==5?"Campaña completa ABBA":"Ablaciones GPU Virtual";
        if(kind==2)campaign=CampaignPlan.abba(new int[]{selectedScene},new int[]{selectedLoad},1);
        if(kind==4)campaign=CampaignPlan.scaleAbba(selectedScene,1);
        if(kind==5)campaign=CampaignPlan.abba(new int[]{0,1,2,3,4,5,6,7},new int[]{0,1,2,3,4},1);
        if(campaign!=null){for(CampaignPlan.Entry e:campaign.entries())plan.add(new RunConfig(e.scene,e.load,hz,e.coordinated,resolution,selectedAudio,false,12000,selectedGraphics,e.index,e.block,e.position,e.pairIndex));}
        else if(kind==1){for(int scene=0;scene<8;scene++)plan.add(new RunConfig(scene,selectedLoad,hz,selectedMode==0,resolution,selectedAudio,false,12000,selectedGraphics,-1,-1,-1,-1));}
        else if(kind==6){for(int route:new int[]{0,1,0,2,0,3,0,4,0,5})plan.add(new RunConfig(selectedScene,selectedLoad,hz,selectedMode==0,resolution,selectedAudio,false,12000,route,-1,-1,-1,-1));}
        else plan.add(new RunConfig(selectedScene,selectedLoad,hz,selectedMode==0,resolution,selectedAudio,kind==0,kind==3?900000:30000,selectedGraphics,-1,-1,-1,-1));
        try{
            beginSession(sessionLabel,"graphics",plan.size());
            if(campaign!=null)session.put("campaign",new JSONObject(campaign.toJson()));
            session.put("measurementNote","Synthetic workloads. Successful swap completion, reported display presentation, and GPU timer durations have distinct scopes. Null means unavailable.");
            session.put("comparisonNote",kind==6?"Ablación controlada: Todo activo se repite antes de cada variante; escena, resolución, semilla, trayectoria, efectos y carga permanecen fijos. La reducción GPU Virtual off conserva el mismo batching/instancing de REgraphics para no fabricar una ventaja por draw calls.":ComparisonAnalysis.LIMITATION);
            session.put("audioNote","Optional synthetic tone. Audio output timing is not measured.");
            store.save(sessionId,session);
        }catch(Exception e){error("No se pudo iniciar el registro",e);return;}
        showLive(plan.toArray(new RunConfig[0]));
    }
    private void beginSession(String label,String type,int planned)throws Exception{
        sessionStarted=System.currentTimeMillis();sessionId="XGamingLab_"+sessionStarted+"_"+(System.nanoTime()%1000000);session=new JSONObject();results=new JSONArray();thermalSamples.clear();maxThermal=-1;
        session.put("schema","x-gaming-lab-session-v3");session.put("type",type);session.put("appVersion",BuildInfo.VERSION);session.put("sourceId",BuildInfo.SOURCE_ID);session.put("label",label);session.put("startedUtc",utc(sessionStarted));session.put("startedEpochMs",sessionStarted);session.put("deviceAtStart",DeviceInfo.capture(this));session.put("results",results);session.put("plannedRuns",planned);session.put("complete",false);
    }
    private void showLive(RunConfig[] plan){
        screen="Escena en prueba";root.removeAllViews();showingLive=true;getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        SurfaceView surface=new SurfaceView(this);root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout overlay=column();overlay.setPadding(dp(15),dp(12),dp(15),dp(12));overlay.setBackground(background(0xE609111D,0x66384E64));
        liveTitle=text("Preparando escena",16,TEXT,true);overlay.addView(liveTitle);livePhase=text("Calentamiento",11,PURPLE,false);overlay.addView(livePhase);
        fpsValue=text("—",52,LIME,true);fpsValue.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));overlay.addView(fpsValue,new LinearLayout.LayoutParams(-1,dp(62)));
        fpsLabel=text("FPS · preparando",11,MUTED,true);overlay.addView(fpsLabel);gap(overlay,8);
        chart=new FrameChart(this);overlay.addView(chart,new LinearLayout.LayoutParams(-1,dp(40)));gap(overlay,9);
        liveNumbers=text("Los resultados aparecen tras\n2 segundos de calentamiento.",12,TEXT,false);liveNumbers.setLineSpacing(dp(3),1);overlay.addView(liveNumbers);
        gap(overlay,10);liveDevice=text("",11,MUTED,false);overlay.addView(liveDevice);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(1000);progress.setProgressTintList(ColorStateList.valueOf(LIME));overlay.addView(progress,new LinearLayout.LayoutParams(-1,dp(8)));
        ScrollView telemetryScroll=new ScrollView(this);telemetryScroll.addView(overlay,new ScrollView.LayoutParams(-1,-2));
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(dp(228),-1,Gravity.LEFT|Gravity.TOP);op.setMargins(dp(12),dp(12),0,dp(12));root.addView(telemetryScroll,op);
        Button stop=button("Finalizar",false,()->{if(loop!=null)loop.stop();});FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(dp(112),dp(44),Gravity.RIGHT|Gravity.TOP);sp.setMargins(0,dp(12),dp(12),0);root.addView(stop,sp);
        liveHint=text(plan[0].interactive?"Desliza para interactuar · entrada registrada":"Recorrido automático · misma semilla",12,TEXT,false);liveHint.setPadding(dp(12),dp(8),dp(12),dp(8));liveHint.setBackground(background(0xD009111D,0));FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2,Gravity.RIGHT|Gravity.BOTTOM);hp.setMargins(dp(250),0,dp(12),dp(12));root.addView(liveHint,hp);
        final int ownerGeneration=++loopGeneration;
        final JSONObject ownerSession=session;final JSONArray ownerResults=results;final String ownerId=sessionId;
        loop=new FrameLoop(this,surface,plan,new FrameLoop.Listener(){
            private boolean ownsUi(){return ownerGeneration==loopGeneration&&ownerSession==session;}
            public void onCase(RunConfig c,int i,int count){if(ownsUi())MainActivity.this.onCase(c,i,count);}
            public void onTelemetry(FrameStats.Snapshot s,RunConfig c,long warm,long remaining,int rw,int rh,int thermal,float hz,boolean available,JSONObject execution){if(ownsUi())MainActivity.this.onTelemetry(s,c,warm,remaining,rw,rh,thermal,hz,available,execution);}
            public void onResult(RunConfig c,FrameStats.Snapshot s,String caps,boolean complete,String reason,long skipped,String audioError,JSONObject execution,JSONObject deviceAtCaseStart){
                try{appendResult(ownerSession,ownerResults,ownerId,c,s,caps,complete,reason,skipped,audioError,execution,deviceAtCaseStart);}
                catch(Exception e){if(ownsUi())Toast.makeText(MainActivity.this,"No se guardó el resultado: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            }
            public void onFinished(boolean interrupted){
                if(ownsUi())MainActivity.this.onFinished(interrupted);
                else {try{ownerSession.put("complete",!interrupted);store.save(ownerId,ownerSession);}catch(Exception ignored){}}
            }
            public void onError(String message){
                if(ownsUi())MainActivity.this.onError(message);
                else {try{ownerSession.put("complete",false);ownerSession.put("error",message);store.save(ownerId,ownerSession);}catch(Exception ignored){}}
            }
        });
    }
    @Override public void onCase(RunConfig config,int index,int total){
        if(!showingLive)return;caseIndex=index;caseCount=total;liveTitle.setText(config.name());livePhase.setText(config.mode()+" · "+(index+1)+" / "+total);fpsValue.setText("—");fpsLabel.setText("FPS · calentamiento");progress.setProgress(0);chart.update(new double[0],config.targetHz);liveHint.setText(config.interactive?"Desliza para interactuar · entrada registrada":"Recorrido automático · misma semilla");
    }
    @Override public void onTelemetry(FrameStats.Snapshot stats,RunConfig config,long warmupLeft,long remaining,int rw,int rh,int thermal,float refresh,boolean presentSupported,JSONObject execution){
        if(!showingLive)return;
        maxThermal=Math.max(maxThermal,thermal);
        try{JSONObject t=new JSONObject();t.put("elapsedMs",System.currentTimeMillis()-sessionStarted);t.put("case",caseIndex);t.put("status",thermal);t.put("displayHz",refresh);thermalSamples.add(t);}catch(Exception ignored){}
        liveDevice.setText(String.format(Locale.ROOT,"%d × %d · pantalla %.0f Hz\nTemperatura: %s",rw,rh,refresh,DeviceInfo.thermalName(thermal)));
        if(stats==null){fpsLabel.setText("CALENTAMIENTO · "+Math.max(1,(warmupLeft+999)/1000)+" s");return;}
        boolean presented=Double.isFinite(stats.presentationFps)&&stats.presentedCount>=10&&stats.presentationCoverage>=.90;
        fpsValue.setText(number(presented?stats.presentationFps:stats.swapFps,1));fpsLabel.setText(presented?"FPS PRESENTADOS":"FPS ENTREGADOS");
        livePhase.setText(config.mode()+" · "+(caseIndex+1)+" / "+caseCount+" · "+((remaining+999)/1000)+" s");
        liveNumbers.setText("p95 / p99  "+number(stats.frameMsP95,1)+" / "+number(stats.frameMsP99,1)+" ms\n"+
            "1% lento      "+number(stats.onePercentLow,1)+" FPS\n"+
            "CPU / GPU    "+number(stats.cpuMs,2)+" / "+number(stats.gpuMs,2)+" ms\n"+
            "Sombras / escena / salida  "+number(stats.shadowGpuMs,2)+" / "+number(stats.sceneGpuMs,2)+" / "+number(stats.screenGpuMs,2)+" ms\n"+
            "QSSD / GPU Virtual  "+number(stats.qssdMs,2)+" / "+number(stats.virtualGpuMs,2)+" ms\n"+
            "PWR objetos / vértices / bytes  "+number(stats.pwrObjectsPct,1)+"% / "+number(stats.pwrVerticesPct,1)+"% / "+number(stats.pwrBytesPct,1)+"%\n"+
            "Objetos         "+stats.objects+" · llamadas "+stats.drawCalls+"\n"+"Núcleo          "+execution.optInt("quantumQubits")+" qubits · "+execution.optLong("quantumGatesSinceConfigure")+" puertas al iniciar\n"+"Dibujo           "+(execution.optLong("instancedDraws")>0?"Instancing":execution.optLong("batchedDraws")>0?"Batches":"Referencia"));
        chart.update(stats.recentFrameMs(),config.targetHz);progress.setProgress((int)(1000*Math.max(0,config.durationMs-remaining)/Math.max(1,config.durationMs)));
    }
    @Override public void onResult(RunConfig config,FrameStats.Snapshot stats,String capabilities,boolean complete,String reason,long skipped,String audioError,JSONObject execution,JSONObject deviceAtCaseStart){
        if(session==null)return;
        try{
            appendResult(session,results,sessionId,config,stats,capabilities,complete,reason,skipped,audioError,execution,deviceAtCaseStart);
        }catch(Exception e){Toast.makeText(this,"No se guardó el resultado: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    private void appendResult(JSONObject owner,JSONArray ownerResults,String ownerId,RunConfig config,FrameStats.Snapshot stats,String capabilities,boolean complete,String reason,long skipped,String audioError,JSONObject execution,JSONObject deviceAtCaseStart)throws Exception {
        JSONObject r=new JSONObject();r.put("configuration",config.json());r.put("complete",complete);r.put("reason",reason);r.put("metrics",new JSONObject(stats.toJson()));
        r.put("execution",execution);r.put("deviceAtCaseStart",deviceAtCaseStart);r.put("hypothesis",ReportAnalysis.hypothesis(owner,r));r.put("capabilities",new JSONObject(capabilities));r.put("deviceAtReport",DeviceInfo.capture(this));r.put("reportCreatedUtc",utc(System.currentTimeMillis()));r.put("skippedVsyncCallbacksIncludingWarmup",skipped);r.put("audioError",audioError);ownerResults.put(r);
        owner.put("complete",false);owner.put("updatedUtc",utc(System.currentTimeMillis()));
        if(owner==session){owner.put("maxThermalStatus",maxThermal);owner.put("thermalSamples",new JSONArray(thermalSamples));}
        ReportAnalysis.update(owner);store.save(ownerId,owner);
    }
    private void saveSession(boolean complete)throws Exception {
        ReportAnalysis.update(session);session.put("complete",complete);session.put("updatedUtc",utc(System.currentTimeMillis()));session.put("maxThermalStatus",maxThermal);session.put("thermalSamples",new JSONArray(thermalSamples));store.save(sessionId,session);
    }
    @Override public void onFinished(boolean interrupted){
        endLoop();try{saveSession(!interrupted);}catch(Exception e){Toast.makeText(this,"No se guardó el cierre del informe",Toast.LENGTH_LONG).show();}showResults(session);
    }
    @Override public void onError(String message){
        endLoop();try{session.put("error",message);saveSession(false);}catch(Exception ignored){}showResults(session);new AlertDialog.Builder(this).setTitle("Medición interrumpida").setMessage(message).setPositiveButton("Entendido",null).show();
    }
    private void showResults(JSONObject report){
        if(report==null){showHome();return;}if("components".equals(report.optString("type"))){showComponentResults(report);return;}displayedReport=report;screen="Resultados";LinearLayout body=page();
        LinearLayout heading=row();LinearLayout title=column();title.addView(text("Resultados",27,TEXT,true));title.addView(text(report.optString("label")+" · "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(report.optLong("startedEpochMs"))),12,MUTED,false));heading.addView(title,new LinearLayout.LayoutParams(0,-2,1));heading.addView(button("Nueva prueba",true,this::showHome),new LinearLayout.LayoutParams(-2,dp(44)));body.addView(heading);gap(body,14);
        JSONObject comparison=report.optJSONObject("comparison");if(comparison!=null){LinearLayout summary=column();summary.setPadding(dp(14),dp(12),dp(14),dp(12));summary.setBackground(background(PANEL,LINE));summary.addView(text("COMPARACIÓN PAREADA · ABBA",11,PURPLE,true));summary.addView(text(comparison.optString("summaryEs"),14,TEXT,false));summary.addView(text("Cada pareja conserva ajustes, contexto térmico y cobertura. Los detalles y advertencias están en el informe.",11,MUTED,false));body.addView(summary);gap(body,12);}
        JSONObject ablation=report.optJSONObject("ablation");if(ablation!=null){LinearLayout summary=column();summary.setPadding(dp(14),dp(12),dp(14),dp(12));summary.setBackground(background(PANEL,LINE));summary.addView(text("ABLACIONES · TODO ACTIVO VS COMPONENTE OFF",11,PURPLE,true));summary.addView(text(ablation.optString("summaryEs"),14,TEXT,false));summary.addView(text("Se comparan pares consecutivos con escena, resolución, semilla, trayectoria, carga, iluminación y efectos iguales.",11,MUTED,false));body.addView(summary);gap(body,12);}
        JSONArray runs=report.optJSONArray("results");int total=runs==null?0:runs.length();
        body.addView(text(report.optBoolean("complete")?"Prueba completada · "+total+" mediciones":"Sesión parcial · "+total+" mediciones guardadas",13,report.optBoolean("complete")?LIME:PURPLE,true));gap(body,8);
        body.addView(text("Entregados = cuadros enviados correctamente. Presentados = marcas de presentación reportadas por el dispositivo. GPU — = temporizador no disponible.",12,MUTED,false));gap(body,14);
        if(total==0)body.addView(text("No se completó la ventana de medición. Puedes volver a intentarlo.",15,TEXT,false));
        for(int i=0;i<total;i++){
            JSONObject result=runs.optJSONObject(i);if(result==null)continue;JSONObject c=result.optJSONObject("configuration"),m=result.optJSONObject("metrics");if(c==null||m==null)continue;
            LinearLayout card=column();card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(background(PANEL,LINE));
            LinearLayout top=row();top.addView(text(c.optString("name")+" · "+c.optString("loadName",String.valueOf(c.optInt("load")))+" · "+(c.optBoolean("coordinated")?"Coordinada":"Libre"),16,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));
            top.addView(text(number(m.optDouble("swapFps"),1)+" FPS entregados",20,LIME,true));card.addView(top);gap(card,5);
            String presented=Double.isFinite(m.optDouble("presentationFps"))?number(m.optDouble("presentationFps"),1)+" FPS · cobertura "+number(m.optDouble("presentationCoverage")*100,0)+"%":"no disponibles";
            card.addView(text("Presentados: "+presented+"   ·   Ventana: "+number(m.optDouble("measuredSeconds"),1)+" s",12,MUTED,false));gap(card,7);
            card.addView(text("p95 "+number(m.optDouble("frameMsP95"),2)+" ms    p99 "+number(m.optDouble("frameMsP99"),2)+" ms    1% lento "+number(m.optDouble("onePercentLow"),1)+" FPS",13,TEXT,false));
            card.addView(text("CPU "+number(m.optDouble("cpuMs"),2)+" ms    QSSD "+number(m.optDouble("qssdMs"),2)+" ms    GPU Virtual "+number(m.optDouble("virtualGpuMs"),2)+" ms    GPU física "+number(m.optDouble("gpuMs"),2)+" ms",12,MUTED,false));
            card.addView(text("GPU física · sombras "+number(m.optDouble("shadowGpuMs"),2)+" · escena "+number(m.optDouble("sceneGpuMs"),2)+" · salida "+number(m.optDouble("screenGpuMs"),2)+" ms",11,MUTED,false));
            card.addView(text("PWR · objetos "+number(m.optDouble("pwrObjectsPct"),1)+"% · vértices "+number(m.optDouble("pwrVerticesPct"),1)+"% · bytes de instancia "+number(m.optDouble("pwrInstanceBytesPct"),1)+"%",12,LIME,true));
            card.addView(text(m.optInt("renderWidth")+" × "+m.optInt("renderHeight")+" · "+m.optInt("objects")+" objetos · "+m.optInt("drawCalls")+" llamadas · objetivo "+c.optInt("targetHz")+" FPS"+(result.optBoolean("complete")?"":" · interrumpida"),11,MUTED,false));
            JSONObject hypothesis=result.optJSONObject("hypothesis");if(hypothesis!=null){gap(card,6);card.addView(text("Pista para investigar: "+hypothesis.optString("titleEs"),12,PURPLE,false));}
            final JSONObject details=result;card.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Detalle de la medición").setMessage(detailText(details)).setPositiveButton("Cerrar",null).show());
            body.addView(card,new LinearLayout.LayoutParams(-1,-2));gap(body,10);
        }
        gap(body,6);exportActions(body,report);
        gap(body,12);body.addView(text("Compara la misma escena, carga y resolución. Revisa temperatura, ahorro de energía y frecuencia de pantalla. Esta app mide sus escenas; no predice automáticamente los FPS de otros juegos.",12,MUTED,false));
    }
    private String detailText(JSONObject r){
        JSONObject m=r.optJSONObject("metrics");if(m==null)return r.toString();
        return "Hipótesis: "+(r.optJSONObject("hypothesis")==null?"No disponible":r.optJSONObject("hypothesis").optString("titleEs"))+"\n\nPreparación geométrica: "+number(m.optDouble("geometryMs"),3)+" ms\nEnvío de dibujo: "+number(m.optDouble("submitMs"),3)+" ms\nEspera de intercambio: "+number(m.optDouble("swapMs"),3)+" ms\nEdad del estado: "+number(m.optDouble("stateAgeMs"),3)+" ms\nEntrada → envío: "+number(m.optDouble("inputToSubmitMs"),3)+" ms\nRegiones preparadas: "+m.optLong("preparedRegions")+"\nConstrucciones al llegar: "+m.optLong("hotRegionBuilds")+"\nCuadros medidos: "+m.optLong("renderedCount")+"\nPresentaciones verificadas: "+m.optLong("presentedCount")+"\n\nEl JSON conserva la configuración, las capacidades, las fases y los diagnósticos completos.";
    }
    private void showHistory(){
        readSettings();endLoop();screen="Historial";LinearLayout body=page();LinearLayout h=row();h.addView(text("Historial",27,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));h.addView(button("Volver",false,this::showHome),new LinearLayout.LayoutParams(-2,dp(44)));body.addView(h);gap(body,16);
        File[] files=store.list();if(files.length==0)body.addView(text("Tus primeras mediciones aparecerán aquí.",16,MUTED,false));
        for(File file:files){try{JSONObject r=store.read(file);JSONArray runs=r.optJSONArray("results");String label=r.optString("label")+" · "+(runs==null?0:runs.length())+" mediciones\n"+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(r.optLong("startedEpochMs")));Button item=button(label,false,()->showResults(r));item.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);body.addView(item,new LinearLayout.LayoutParams(-1,dp(64)));gap(body,8);}catch(Exception ignored){}}
    }
    private void exportReport(JSONObject report){exportReport(report,"json");}
    private AtomicFile pendingExport(){return new AtomicFile(new File(getFilesDir(),"pending-export.data"));}
    private void exportReport(JSONObject report,String format){
        try{
            String content=format.equals("csv")?ReportFormats.csv(report):format.equals("html")?ReportFormats.html(report):report.toString(2);
            AtomicFile pending=pendingExport();FileOutputStream staged=pending.startWrite();
            try{staged.write(content.getBytes(StandardCharsets.UTF_8));pending.finishWrite(staged);}catch(Exception e){pending.failWrite(staged);throw e;}
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(format.equals("csv")?"text/csv":format.equals("html")?"text/html":"application/json");i.putExtra(Intent.EXTRA_TITLE,"XGamingLab_"+report.optLong("startedEpochMs")+"."+format);startActivityForResult(i,71);
        }catch(Exception e){error("No se pudo preparar la exportación",e);}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(request!=71)return;
        if(result!=RESULT_OK){pendingExport().delete();return;}
        if(data==null||data.getData()==null){error("No se pudo exportar",new IllegalStateException("El selector no devolvió un archivo"));return;}
        try(FileInputStream in=pendingExport().openRead();OutputStream out=getContentResolver().openOutputStream(data.getData(),"wt")){
            if(out==null)throw new IllegalStateException("No se abrió el archivo");byte[] buffer=new byte[16384];int count;while((count=in.read(buffer))!=-1)out.write(buffer,0,count);
        }catch(Exception e){error("No se pudo exportar; el informe sigue en el historial",e);return;}
        pendingExport().delete();Toast.makeText(this,"Informe exportado",Toast.LENGTH_LONG).show();
    }
        private void navigation(LinearLayout body,String selected){
        LinearLayout nav=row();String[] names={"Mi PC","Escenarios","Campañas","Historial"};
        Runnable[] actions={this::showPrototype,this::showHome,this::showCampaigns,this::showHistory};
        for(int i=0;i<names.length;i++){final Runnable action=actions[i];Button b=button(names[i],names[i].equals(selected),()->{readSettings();action.run();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1);if(i>0)p.leftMargin=dp(8);nav.addView(b,p);}body.addView(nav);gap(body,14);
    }
    private void pageTitle(LinearLayout body,String title,String subtitle,String selected){
        body.addView(text(title,27,TEXT,true));body.addView(text(subtitle,12,MUTED,false));gap(body,14);navigation(body,selected);
    }
    private void exportActions(LinearLayout body,JSONObject report){
        LinearLayout actions=row();addAction(actions,button("Exportar JSON",true,()->exportReport(report,"json")));addAction(actions,button("Tabla CSV",false,()->exportReport(report,"csv")));addAction(actions,button("Informe HTML",false,()->exportReport(report,"html")));addAction(actions,button("Historial",false,this::showHistory));body.addView(actions);
    }
    private JSONObject lastComponentReport(){
        for(File f:store.list()){try{JSONObject r=store.read(f);if("components".equals(r.optString("type")))return r;}catch(Exception ignored){}}return null;
    }
    private void showPrototype(){
        readSettings();endLoop();screen="Mi PC";LinearLayout body=page();pageTitle(body,"Tu prototipo de PC","Componentes originales · ejecución verificable · resultados locales","Mi PC");
        LinearLayout flow=column();flow.setPadding(dp(14),dp(12),dp(14),dp(12));flow.setBackground(background(PANEL,LINE));flow.addView(text("NÚCLEO + CPU  →  GPU VIRTUAL  →  QSSD  →  REgraphics  →  GPU FÍSICA  →  PANTALLA",16,LIME,true));gap(flow,5);flow.addView(text("El núcleo y los componentes virtuales se ejecutan en el procesador anfitrión. El adaptador GLES2 dibuja en la GPU del dispositivo.",12,MUTED,false));body.addView(flow);gap(body,14);
        JSONObject prior=lastComponentReport();JSONArray previous=prior==null?null:prior.optJSONArray("results");
        LinearLayout controls=row();componentLoadSpinner=setting(controls,"Intensidad del diagnóstico",RunConfig.LOADS,selectedLoad);controls.addView(button("Verificar los 5 bloques",true,()->startComponents(new int[]{0,1,2,3,4},0)),new LinearLayout.LayoutParams(0,dp(48),1));body.addView(controls);gap(body,10);
        String[] descriptions={
            "Programas XI, aritmética, memoria y rollback. Se compara la salida con un resultado esperado.",
            "Puertas originales: Bell, GHZ, interferencia, inversas y oráculos. El informe declara qubits y familia de estados.",
            "Kernels GPU Virtual dependientes, grupos de trabajo, memoria compartida y barreras; salida comprobada palabra a palabra.",
            "Estados, versiones y leases. Checkpoint escrito a archivo, sincronizado, leído y restaurado con comprobación de integridad.",
            "Observable cuántico → reglas XI → GPU Virtual → publicación QSSD → trabajo físico mínimo. Se comprueba el resultado de la cadena."
        };
        for(int kind=0;kind<5;kind++){
            final int k=kind;JSONObject last=null;if(previous!=null)for(int j=0;j<previous.length();j++){JSONObject r=previous.optJSONObject(j);if(r!=null&&r.optInt("kind",-1)==kind)last=r;}
            LinearLayout card=column();card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(background(PANEL,LINE));LinearLayout head=row();head.addView(text(ComponentRunner.NAMES[kind],18,TEXT,true),new LinearLayout.LayoutParams(0,-2,1));
            int testedLoad=last==null?-1:last.optInt("load",-1);String testedLabel=testedLoad>=0&&testedLoad<RunConfig.LOADS.length?RunConfig.LOADS[testedLoad]:"carga sin registrar";
            String status=last==null?"Sin prueba registrada":!BuildInfo.SOURCE_ID.equals(prior.optString("sourceId"))?"Informe de otra versión · "+testedLabel:"Última: "+testedLabel+(last.optBoolean("passed")&&last.optBoolean("complete")?" · aprobada":" · parcial / revisar");
            head.addView(text(status,11,last!=null&&last.optBoolean("passed")&&last.optBoolean("complete")&&BuildInfo.SOURCE_ID.equals(prior.optString("sourceId"))?LIME:MUTED,true));card.addView(head);gap(card,5);card.addView(text(descriptions[kind],12,MUTED,false));gap(card,9);LinearLayout buttons=row();addAction(buttons,button("Verificar",false,()->startComponents(new int[]{k},0)));addAction(buttons,button("Estrés · 15 s",false,()->startComponents(new int[]{k},15000)));card.addView(buttons);body.addView(card);gap(body,10);
        }
        gap(body,4);body.addView(button("Ver origen y alcance de los componentes",false,()->{
            try{new AlertDialog.Builder(this).setTitle("Arquitectura y procedencia").setMessage(new JSONObject(NativeBridge.probeCapabilities()).toString(2)).setPositiveButton("Cerrar",null).show();}catch(Throwable e){new AlertDialog.Builder(this).setTitle("No se obtuvo el origen").setMessage(e.toString()).setPositiveButton("Cerrar",null).show();}
        }));
        body.addView(text("En las escenas se ejecuta un circuito de dos qubits al configurar el caso. Las pruebas de este panel ejercitan capacidades adicionales. Un resultado aprobado comprueba los casos registrados, no todas las capacidades posibles de un PC.",12,MUTED,false));
    }
    private void startComponents(int[] kinds,long stressMs){
        int load=componentLoadSpinner==null?selectedLoad:componentLoadSpinner.getSelectedItemPosition();selectedLoad=load;saveSettings();endLoop();
        try{beginSession(stressMs>0?"Estrés de componentes":"Verificación del prototipo","components",kinds.length);session.put("componentCapabilities",new JSONObject(NativeBridge.probeCapabilities()));store.save(sessionId,session);}catch(Throwable e){new AlertDialog.Builder(this).setTitle("No se pudo iniciar").setMessage(e.toString()).setPositiveButton("Cerrar",null).show();return;}
        componentRunning=true;screen="Componentes en prueba";getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        final int ownerGeneration=++loopGeneration;final JSONObject owner=session;final JSONArray ownerResults=results;final String ownerId=sessionId;
        LinearLayout body=page();body.addView(text("Probando tu prototipo",28,TEXT,true));gap(body,8);componentStatus=text("Preparando componentes originales…",17,LIME,true);body.addView(componentStatus);gap(body,12);ProgressBar busy=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);busy.setIndeterminate(true);busy.setIndeterminateTintList(ColorStateList.valueOf(LIME));body.addView(busy,new LinearLayout.LayoutParams(-1,dp(8)));gap(body,20);
        componentEvidence=text("Cada lote calcula, comprueba y registra su salida.\n\nPuedes detener la prueba; el lote en curso terminará antes de guardar su resultado.",14,MUTED,false);componentEvidence.setLineSpacing(dp(4),1);body.addView(componentEvidence);gap(body,18);body.addView(button("Detener y guardar",false,()->{if(componentRunner!=null){componentRunner.stop();componentStatus.setText("Terminando el lote actual…");}}));
        componentRunner=new ComponentRunner(this,kinds,load,stressMs,new ComponentRunner.Listener(){
            private boolean owns(){return ownerGeneration==loopGeneration&&owner==session&&componentRunning;}
            public void onStart(int kind,int index,int count){if(owns())componentStatus.setText(ComponentRunner.NAMES[kind]+" · "+(index+1)+" / "+count+" · "+RunConfig.LOADS[load]);}
            public void onResult(JSONObject result){try{ownerResults.put(result);owner.put("updatedUtc",utc(System.currentTimeMillis()));owner.put("deviceAtReport",DeviceInfo.capture(MainActivity.this));store.save(ownerId,owner);}catch(Exception e){try{owner.put("saveError",e.toString());}catch(Exception ignored){}}
                if(owns())componentEvidence.append("\n\n"+result.optString("name")+" · "+(result.optBoolean("passed")?"Aprobado":"Revisar")+"\n"+result.optLong("checks")+" comprobaciones · "+number(result.optDouble("elapsedNs")/1e6,1)+" ms");}
            public void onFinish(boolean interrupted,String failure){boolean update=owns();try{owner.put("complete",!interrupted);owner.put("updatedUtc",utc(System.currentTimeMillis()));if(failure!=null)owner.put("error",failure);store.save(ownerId,owner);}catch(Exception ignored){}
                if(update){componentRunning=false;componentRunner=null;getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);showComponentResults(owner);}}
        });componentRunner.start();
    }
    private void showComponentResults(JSONObject report){
        displayedReport=report;screen="Resultados";LinearLayout body=page();pageTitle(body,"Resultado del prototipo",report.optString("label")+" · "+(report.optBoolean("complete")?"Finalizado":"Parcial"),"Mi PC");
        if(report.has("error")){body.addView(text(report.optString("error"),14,PURPLE,false));gap(body,10);}
        JSONArray runs=report.optJSONArray("results");if(runs==null||runs.length()==0)body.addView(text("Aún no hay un lote completo. El historial conservará los resultados que termine el trabajador.",14,MUTED,false));
        if(runs!=null)for(int i=0;i<runs.length();i++){
            JSONObject r=runs.optJSONObject(i);if(r==null)continue;LinearLayout card=column();card.setPadding(dp(16),dp(12),dp(16),dp(12));card.setBackground(background(PANEL,LINE));card.addView(text(r.optString("name"),19,TEXT,true));gap(card,5);card.addView(text((r.optBoolean("passed")?"COMPROBACIONES APROBADAS":"REQUIERE REVISIÓN")+(r.optBoolean("complete")?"":" · parcial"),12,r.optBoolean("passed")?LIME:PURPLE,true));
            card.addView(text(r.optLong("checks")+" comprobaciones · "+r.optLong("failures")+" fallos · "+r.optLong("batches")+" lotes",14,TEXT,false));card.addView(text("Tiempo total "+number(r.optDouble("elapsedNs")/1e6,2)+" ms · error máximo "+String.valueOf(r.optDouble("maxError")),12,MUTED,false));
            JSONObject batch=r.optJSONObject("lastBatch");if(batch!=null){card.addView(text("Checksum: "+batch.optString("checksum"),11,MUTED,false));JSONArray subtests=batch.optJSONArray("subtests");if(subtests!=null)for(int n=0;n<subtests.length();n++){JSONObject sub=subtests.optJSONObject(n);if(sub!=null)card.addView(text((sub.optBoolean("passed")?"✓ ":"! ")+sub.optString("name")+" · "+sub.optLong("checks")+" comprobaciones",12,MUTED,false));}}
            final JSONObject detail=r;gap(card,7);card.addView(button("Detalles, tamaños y evidencia",false,()->{try{new AlertDialog.Builder(this).setTitle("Ejecución comprobada").setMessage(detail.toString(2)).setPositiveButton("Cerrar",null).show();}catch(Exception ignored){}}));body.addView(card);gap(body,10);
        }
        exportActions(body,report);gap(body,12);body.addView(text("Los tiempos incluyen la ejecución y sus comprobaciones. CPU virtual, GPU Virtual y observadores cuánticos usan el procesador anfitrión; estas pruebas no atribuyen velocidad a hardware cuántico físico.",12,MUTED,false));
    }
    private void showCampaigns(){
        readSettings();endLoop();screen="Campañas";LinearLayout body=page();pageTitle(body,"Campañas de rendimiento","Repite, aumenta la carga y conserva los resultados comparables","Campañas");
        body.addView(text("Ajustes actuales: "+RunConfig.NAMES[selectedScene]+" · "+RunConfig.LOADS[selectedLoad]+" · "+RunConfig.GRAPHICS[selectedGraphics],14,LIME,true));gap(body,12);
        campaignCard(body,"Exploración de géneros","8 escenas · carga elegida · unos 2 minutos",1);
        campaignCard(body,"Comparación ABBA","Escena y carga elegidas · 4 ejecuciones · unos 56 segundos",2);
        campaignCard(body,"Escalado masivo","Escena elegida · 5 cargas · ABBA · 20 ejecuciones · unos 4 min 40 s",4);
        campaignCard(body,"Campaña completa","8 escenas × 5 cargas × ABBA · 160 ejecuciones · unos 37 min 20 s",5);
        campaignCard(body,"Ablaciones GPU Virtual","Todo activo / reducción GPU Virtual off / QSSD off / reutilización off / compacta off / visibilidad off",6);
        campaignCard(body,"Resistencia","Escena y carga elegidas · 15 minutos medidos",3);
        body.addView(text("La resolución y carga permanecen fijas dentro de cada caso. Los cambios de temperatura y pantalla se registran. Un estado térmico crítico interrumpe la prueba y conserva el informe parcial. ABBA equilibra el orden; no elimina por sí solo todos los factores externos.",12,MUTED,false));
    }
    private void campaignCard(LinearLayout body,String title,String description,int kind){
        LinearLayout card=row();card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackground(background(PANEL,LINE));LinearLayout copy=column();copy.addView(text(title,18,TEXT,true));copy.addView(text(description,12,MUTED,false));card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));card.addView(button("Iniciar",false,()->startPlan(kind)),new LinearLayout.LayoutParams(dp(100),dp(44)));body.addView(card);gap(body,10);
    }

    private void showHelp(){new AlertDialog.Builder(this).setTitle("Una medición que se puede comparar").setMessage(
        "• Batería: ocho escenas, dos segundos de calentamiento y doce segundos medidos por escena.\n\n"+
        "• ABBA: dos mediciones coordinadas y dos libres por escena/carga. Los informes conservan cambios térmicos, frecuencia y parejas incompletas. En mundo abierto también cambia la preparación anticipada de regiones.\n\n"+
        "• FPS entregados cuentan intercambios de imagen aceptados. FPS presentados requieren marcas del dispositivo; su cobertura aparece en el informe.\n\n"+
        "• p95/p99 son tiempos de fotograma: más bajos indican menos picos. 1% lento es el inverso del tiempo medio del 1% de intervalos más lentos.\n\n"+
        "• Núcleo original: su observable alimenta XI, GPU Virtual y QSSD. Mi PC registra la cantidad real de qubits y las operaciones ejecutadas; no se reduce silenciosamente la prueba solicitada. Mi PC contiene pruebas ampliadas de interferencia, cómputo, kernels y checkpoint real. Los componentes virtuales corren en CPU anfitriona; GLES2 ejecuta el dibujo en la GPU del dispositivo.\n\n"+
        "• El audio es un tono sintético opcional. No se mide su latencia de salida. La app no captura ni mide juegos ajenos.\n\n"+
        "• Pausar o salir interrumpe y conserva la sesión parcial; los segundos de pausa no se cuentan como fotogramas.")
        .setPositiveButton("Entendido",null).show();}
    private void error(String title,Exception e){new AlertDialog.Builder(this).setTitle(title).setMessage(String.valueOf(e.getMessage())).setPositiveButton("Cerrar",null).show();}
    private static String number(double v,int decimals){return Double.isFinite(v)?String.format(Locale.ROOT,"%."+decimals+"f",v):"—";}
    private static String utc(long milliseconds){SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",Locale.ROOT);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date(milliseconds));}
    @Override protected void onPause(){
        if(componentRunning){resumeAfterInterruption=true;endLoop();}
        if(showingLive){resumeAfterInterruption=true;++loopGeneration;try{saveSession(false);}catch(Exception ignored){}FrameLoop old=loop;loop=null;showingLive=false;if(old!=null)old.close(true);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
        super.onPause();
    }
    @Override protected void onResume(){super.onResume();if(root!=null&&resumeAfterInterruption){resumeAfterInterruption=false;if(session!=null)showResults(session);else showHome();}}
    @Override protected void onDestroy(){endLoop();super.onDestroy();}
    @Override public void onBackPressed(){if(componentRunning&&componentRunner!=null)componentRunner.stop();else if(showingLive&&loop!=null)loop.stop();else showHome();}
}
