package x.lab.gaming;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Descriptive paired analysis of a declared ABBA campaign. No outlier removal,
 * significance test, causal claim, or pooling of per-run percentiles.
 * All original observations and planned pairs remain in the exported result.
 */
public final class ComparisonAnalysis {
    private ComparisonAnalysis() {}
    public static final String LIMITATION = "Resumen descriptivo: ABBA equilibra el orden, pero no demuestra causalidad ni elimina cambios térmicos, del sistema o de frecuencia. A cambia coordinación y preparación espacial respecto de B.";

    /** Reconstruct with primitive JSON values, or use fromSnapshot for live results. */
    public static final class Measurement {
        public final long renderedCount,intervalCount,elapsedNs,invalidSamples,failedSwapCount;
        public final int targetHz,renderWidth,renderHeight,surfaceWidth,surfaceHeight;
        public final double frameMsP95,frameMsP99,onePercentLow;
        public final double cpuMs,qssdMs,virtualGpuMs,geometryMs,submitMs,swapMs,gpuMs;
        public final double presentationFps,presentationCoverage,gpuCoverage;
        public final boolean quantilesComplete;

        private Measurement(Builder b) {
            renderedCount=b.renderedCount;intervalCount=b.intervalCount;elapsedNs=b.elapsedNs;
            invalidSamples=b.invalidSamples;failedSwapCount=b.failedSwapCount;
            targetHz=b.targetHz;renderWidth=b.renderWidth;renderHeight=b.renderHeight;
            surfaceWidth=b.surfaceWidth;surfaceHeight=b.surfaceHeight;
            frameMsP95=b.frameMsP95;frameMsP99=b.frameMsP99;onePercentLow=b.onePercentLow;
            cpuMs=b.cpuMs;qssdMs=b.qssdMs;virtualGpuMs=b.virtualGpuMs;geometryMs=b.geometryMs;
            submitMs=b.submitMs;swapMs=b.swapMs;gpuMs=b.gpuMs;
            presentationFps=b.presentationFps;presentationCoverage=b.presentationCoverage;
            gpuCoverage=b.gpuCoverage;quantilesComplete=b.quantilesComplete;
        }
        public static Measurement fromSnapshot(FrameStats.Snapshot s) {
            if(s==null)throw new IllegalArgumentException("snapshot is null");
            return new Builder().cadence(s.renderedCount,s.intervalCount,s.elapsedNs)
                    .targetHz(s.targetHz).dimensions(s.renderWidth,s.renderHeight,s.surfaceWidth,s.surfaceHeight)
                    .frameTimes(s.frameMsP95,s.frameMsP99,s.onePercentLow)
                    .stages(s.cpuMs,s.qssdMs,s.virtualGpuMs,s.geometryMs,s.submitMs,s.swapMs,s.gpuMs)
                    .coverage(s.presentationFps,s.presentationCoverage,s.gpuCoverage)
                    .integrity(s.invalidSamples,s.failedSwapCount,s.quantilesComplete).build();
        }
        /** Counts/time, never a supplied or averaged instantaneous FPS value. */
        public double swapFps() { return validCadence(this)?intervalCount*(1e9/elapsedNs):Double.NaN; }
        public double meanFrameMs() { return validCadence(this)?elapsedNs/(double)intervalCount/1e6:Double.NaN; }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"renderedCount\":").append(renderedCount);
            FrameStats.field(b,"intervalCount",intervalCount);FrameStats.field(b,"elapsedNs",elapsedNs);
            FrameStats.field(b,"swapFps",swapFps());FrameStats.field(b,"targetHz",targetHz);
            FrameStats.field(b,"renderWidth",renderWidth);FrameStats.field(b,"renderHeight",renderHeight);
            FrameStats.field(b,"surfaceWidth",surfaceWidth);FrameStats.field(b,"surfaceHeight",surfaceHeight);
            FrameStats.field(b,"frameMsP95",frameMsP95);FrameStats.field(b,"frameMsP99",frameMsP99);
            FrameStats.field(b,"onePercentLow",onePercentLow);FrameStats.field(b,"cpuMs",cpuMs);
            FrameStats.field(b,"qssdMs",qssdMs);FrameStats.field(b,"virtualGpuMs",virtualGpuMs);
            FrameStats.field(b,"geometryMs",geometryMs);FrameStats.field(b,"submitMs",submitMs);
            FrameStats.field(b,"swapMs",swapMs);FrameStats.field(b,"gpuMs",gpuMs);
            FrameStats.field(b,"presentationFps",presentationFps);FrameStats.field(b,"presentationCoverage",presentationCoverage);
            FrameStats.field(b,"gpuCoverage",gpuCoverage);FrameStats.field(b,"invalidSamples",invalidSamples);
            FrameStats.field(b,"failedSwapCount",failedSwapCount);FrameStats.field(b,"quantilesComplete",quantilesComplete);
            return b.append('}').toString();
        }

        public static final class Builder {
            private long renderedCount,intervalCount,elapsedNs,invalidSamples,failedSwapCount;
            private int targetHz,renderWidth,renderHeight,surfaceWidth,surfaceHeight;
            private double frameMsP95=Double.NaN,frameMsP99=Double.NaN,onePercentLow=Double.NaN;
            private double cpuMs=Double.NaN,qssdMs=Double.NaN,virtualGpuMs=Double.NaN;
            private double geometryMs=Double.NaN,submitMs=Double.NaN,swapMs=Double.NaN,gpuMs=Double.NaN;
            private double presentationFps=Double.NaN,presentationCoverage=Double.NaN,gpuCoverage=Double.NaN;
            private boolean quantilesComplete=true;
            public Builder cadence(long rendered,long intervals,long elapsed) {
                renderedCount=rendered;intervalCount=intervals;elapsedNs=elapsed;return this;
            }
            public Builder targetHz(int hz) { targetHz=hz;return this; }
            public Builder dimensions(int rw,int rh,int sw,int sh) {
                renderWidth=rw;renderHeight=rh;surfaceWidth=sw;surfaceHeight=sh;return this;
            }
            public Builder frameTimes(double p95,double p99,double low) {
                frameMsP95=p95;frameMsP99=p99;onePercentLow=low;return this;
            }
            public Builder stages(double cpu,double qssd,double virtualGpu,double geometry,double submit,double swap,double gpu) {
                cpuMs=cpu;qssdMs=qssd;virtualGpuMs=virtualGpu;geometryMs=geometry;
                submitMs=submit;swapMs=swap;gpuMs=gpu;return this;
            }
            public Builder coverage(double presentFps,double presentCoverage,double gpu) {
                presentationFps=presentFps;presentationCoverage=presentCoverage;gpuCoverage=gpu;return this;
            }
            public Builder integrity(long invalid,long failed,boolean completeQuantiles) {
                invalidSamples=invalid;failedSwapCount=failed;quantilesComplete=completeQuantiles;return this;
            }
            public Measurement build() { return new Measurement(this); }
        }
    }

    /** Observed context, not proof that clocks or thermal conditions were identical. */
    public static final class Environment {
        public final String deviceKey;
        public final double minDisplayHz,maxDisplayHz;
        public final int thermalStart,thermalMax;
        public final boolean powerSave,powerSaveKnown;
        public Environment(String deviceKey,double minDisplayHz,double maxDisplayHz,
                           int thermalStart,int thermalMax,boolean powerSave) {
            this(deviceKey,minDisplayHz,maxDisplayHz,thermalStart,thermalMax,powerSave,true);
        }
        public Environment(String deviceKey,double minDisplayHz,double maxDisplayHz,
                           int thermalStart,int thermalMax,boolean powerSave,boolean powerSaveKnown) {
            this.deviceKey=deviceKey==null?"":deviceKey;this.minDisplayHz=minDisplayHz;
            this.maxDisplayHz=maxDisplayHz;this.thermalStart=thermalStart;this.thermalMax=thermalMax;
            this.powerSave=powerSave;this.powerSaveKnown=powerSaveKnown;
        }
        public static Environment unknown() { return new Environment("",Double.NaN,Double.NaN,-1,-1,false,false); }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"deviceKey\":");FrameStats.quote(b,deviceKey);
            FrameStats.field(b,"minDisplayHz",minDisplayHz);FrameStats.field(b,"maxDisplayHz",maxDisplayHz);
            FrameStats.field(b,"thermalStart",thermalStart);FrameStats.field(b,"thermalMax",thermalMax);
            if(powerSaveKnown)FrameStats.field(b,"powerSave",powerSave);else b.append(",\"powerSave\":null");
            FrameStats.field(b,"powerSaveKnown",powerSaveKnown);
            return b.append('}').toString();
        }
    }

    public static final class Observation {
        public final int entryIndex;
        public final String configurationKey;
        public final long warmupMs,requestedMeasurementMs;
        public final Measurement metrics;
        public final boolean completed;
        public final Environment environment;
        /**
         * configurationKey must encode seed, audio/input policy, requested resolution,
         * renderer/build/workload versions and every control except A/B mode.
         * Scene/load come from the plan; target and actual dimensions are also checked.
         */
        public Observation(int entryIndex,String configurationKey,long warmupMs,long requestedMeasurementMs,
                           Measurement metrics,boolean completed,Environment environment) {
            this.entryIndex=entryIndex;this.configurationKey=configurationKey==null?"":configurationKey;
            this.warmupMs=warmupMs;this.requestedMeasurementMs=requestedMeasurementMs;
            this.metrics=metrics;this.completed=completed;
            this.environment=environment==null?Environment.unknown():environment;
        }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"entryIndex\":").append(entryIndex);
            FrameStats.field(b,"configurationKey",configurationKey);FrameStats.field(b,"warmupMs",warmupMs);
            FrameStats.field(b,"requestedMeasurementMs",requestedMeasurementMs);FrameStats.field(b,"completed",completed);
            b.append(",\"environment\":").append(environment.toJson());
            b.append(",\"metrics\":").append(metrics==null?"null":metrics.toJson());
            return b.append('}').toString();
        }
    }

    public static Summary analyze(CampaignPlan plan,Observation[] input) {
        if(plan==null)throw new IllegalArgumentException("plan is null");
        Observation[] all=input==null?new Observation[0]:input.clone();
        Observation[] indexed=new Observation[plan.runCount];int[] counts=new int[plan.runCount];
        int unexpected=0,missing=0,duplicates=0;
        for(Observation o:all) {
            if(o==null||o.entryIndex<0||o.entryIndex>=plan.runCount){unexpected++;continue;}
            if(counts[o.entryIndex]++==0)indexed[o.entryIndex]=o;
        }
        for(int count:counts){if(count==0)missing++;if(count>1)duplicates+=count-1;}
        CampaignPlan.Entry[] ae=new CampaignPlan.Entry[plan.pairCount],be=new CampaignPlan.Entry[plan.pairCount];
        for(CampaignPlan.Entry e:plan.entries())if(e.coordinated)ae[e.pairIndex]=e;else be[e.pairIndex]=e;
        PairResult[] pairs=new PairResult[plan.pairCount];Map<String,List<PairResult>> grouped=new LinkedHashMap<>();
        int usable=0,warned=0;
        for(int i=0;i<pairs.length;i++) {
            Observation a=indexed[ae[i].index],b=indexed[be[i].index];
            String reason=pairReason(a,b,counts[ae[i].index],counts[be[i].index]);
            pairs[i]=new PairResult(ae[i],be[i],a,b,reason);
            if(pairs[i].usable) {
                usable++;if(pairs[i].warnings.length>0)warned++;
                String key=groupKey(pairs[i]);
                List<PairResult> list=grouped.get(key);
                if(list==null){list=new ArrayList<>();grouped.put(key,list);}list.add(pairs[i]);
            }
        }
        GroupSummary[] groups=new GroupSummary[grouped.size()];int i=0;
        for(List<PairResult> group:grouped.values())groups[i++]=new GroupSummary(group);
        return new Summary(plan,all,pairs,groups,usable,warned,unexpected,missing,duplicates);
    }

    private static String pairReason(Observation a,Observation b,int ac,int bc) {
        if(ac==0||bc==0)return "missing_run";
        if(ac!=1||bc!=1)return "duplicate_run";
        if(!a.completed||!b.completed)return "incomplete_run";
        if(a.configurationKey.isEmpty()||!a.configurationKey.equals(b.configurationKey))return "configuration_mismatch";
        if(a.warmupMs<0||a.requestedMeasurementMs<=0||a.warmupMs!=b.warmupMs
                ||a.requestedMeasurementMs!=b.requestedMeasurementMs)return "duration_or_warmup_mismatch";
        if(!a.environment.deviceKey.isEmpty()&&!b.environment.deviceKey.isEmpty()
                &&!a.environment.deviceKey.equals(b.environment.deviceKey))return "device_mismatch";
        Measurement x=a.metrics,y=b.metrics;
        if(!validCadence(x)||!validCadence(y))return "insufficient_or_invalid_cadence";
        if(x.targetHz<1||x.targetHz!=y.targetHz)return "target_mismatch";
        if(x.renderWidth<=0||x.renderHeight<=0||x.surfaceWidth<=0||x.surfaceHeight<=0
                ||x.renderWidth!=y.renderWidth||x.renderHeight!=y.renderHeight
                ||x.surfaceWidth!=y.surfaceWidth||x.surfaceHeight!=y.surfaceHeight)return "resolution_mismatch";
        return "paired";
    }
    static boolean validCadence(Measurement m) {
        return m!=null&&m.renderedCount>=2&&m.intervalCount==m.renderedCount-1&&m.elapsedNs>0;
    }
    static boolean positive(double n){return Double.isFinite(n)&&n>0;}
    static boolean nonnegative(double n){return Double.isFinite(n)&&n>=0;}
    private static boolean validCoverage(double n){return nonnegative(n)&&n<=1;}
    private static boolean validPresentation(Measurement m) {
        return positive(m.presentationFps)&&validCoverage(m.presentationCoverage)&&m.presentationCoverage>0;
    }
    private static double change(double a,double b) {
        return nonnegative(a)&&positive(b)?100.0*(a/b-1.0):Double.NaN;
    }
    private static boolean displayKnown(Environment e) {
        return positive(e.minDisplayHz)&&positive(e.maxDisplayHz)&&e.maxDisplayHz>=e.minDisplayHz;
    }
    private static boolean thermalKnown(Environment e) {
        return e.thermalStart>=0&&e.thermalStart<=6&&e.thermalMax>=e.thermalStart&&e.thermalMax<=6;
    }
    private static String[] warnings(Observation a,Observation b) {
        List<String> w=new ArrayList<>();Environment x=a.environment,y=b.environment;
        if(x.deviceKey.isEmpty()||y.deviceKey.isEmpty())w.add("device_identity_unavailable");
        if(!displayKnown(x)||!displayKnown(y))w.add("display_context_unavailable");
        else {
            if(x.maxDisplayHz-x.minDisplayHz>.5||y.maxDisplayHz-y.minDisplayHz>.5)w.add("display_changed_within_run");
            if(Math.abs(x.minDisplayHz-y.minDisplayHz)>.5||Math.abs(x.maxDisplayHz-y.maxDisplayHz)>.5)
                w.add("display_differs_between_runs");
        }
        if(!thermalKnown(x)||!thermalKnown(y))w.add("thermal_context_unavailable");
        else {
            if(x.thermalStart!=y.thermalStart||x.thermalMax!=y.thermalMax)w.add("thermal_context_differs");
            if(x.thermalMax>=3||y.thermalMax>=3)w.add("severe_thermal_status_reported");
        }
        if(!x.powerSaveKnown||!y.powerSaveKnown)w.add("power_save_context_unavailable");
        else {
            if(x.powerSave!=y.powerSave)w.add("power_save_differs");
            if(x.powerSave||y.powerSave)w.add("power_save_active");
        }
        Measurement p=a.metrics,q=b.metrics;
        if(p.invalidSamples>0||q.invalidSamples>0||p.failedSwapCount>0||q.failedSwapCount>0)w.add("native_sample_failures_present");
        if(p.invalidSamples<0||q.invalidSamples<0||p.failedSwapCount<0||q.failedSwapCount<0)w.add("invalid_integrity_counters");
        if(!p.quantilesComplete||!q.quantilesComplete)w.add("whole_run_quantiles_unavailable");
        if(p.intervalCount<100||q.intervalCount<100)w.add("fewer_than_100_intervals");
        double pa=p.elapsedNs/1e6,qa=q.elapsedNs/1e6;
        if(Math.abs(pa-a.requestedMeasurementMs)>Math.max(100,2*p.meanFrameMs())
                ||Math.abs(qa-b.requestedMeasurementMs)>Math.max(100,2*q.meanFrameMs()))w.add("measured_window_differs_from_requested");
        if(!validPresentation(p)||!validPresentation(q)
                ||p.presentationCoverage<.9||q.presentationCoverage<.9)w.add("presentation_unavailable_or_partial");
        if(!nonnegative(p.gpuMs)||!nonnegative(q.gpuMs)||!validCoverage(p.gpuCoverage)
                ||!validCoverage(q.gpuCoverage)||p.gpuCoverage<.8||q.gpuCoverage<.8)w.add("gpu_timer_unavailable_or_partial");
        return w.toArray(new String[0]);
    }

    public static final class PairResult {
        public final int pairIndex,scene,load,aEntryIndex,bEntryIndex,block;
        public final boolean usable;
        public final String reason,configurationKey;
        public final double aSwapFps,bSwapFps,swapFpsChangePct,p95ChangePct,p99ChangePct;
        public final double onePercentLowChangePct,presentationFpsChangePct;
        private final Observation a,b;
        private final String[] warnings;
        private PairResult(CampaignPlan.Entry ae,CampaignPlan.Entry be,Observation a,Observation b,String reason) {
            pairIndex=ae.pairIndex;scene=ae.scene;load=ae.load;block=ae.block;
            aEntryIndex=ae.index;bEntryIndex=be.index;this.a=a;this.b=b;this.reason=reason;usable=reason.equals("paired");
            configurationKey=a!=null?a.configurationKey:b!=null?b.configurationKey:"";
            warnings=usable?ComparisonAnalysis.warnings(a,b):new String[0];
            aSwapFps=a==null||a.metrics==null?Double.NaN:a.metrics.swapFps();
            bSwapFps=b==null||b.metrics==null?Double.NaN:b.metrics.swapFps();
            swapFpsChangePct=usable?change(aSwapFps,bSwapFps):Double.NaN;
            boolean quantiles=usable&&a.metrics.quantilesComplete&&b.metrics.quantilesComplete;
            p95ChangePct=quantiles?change(a.metrics.frameMsP95,b.metrics.frameMsP95):Double.NaN;
            p99ChangePct=quantiles?change(a.metrics.frameMsP99,b.metrics.frameMsP99):Double.NaN;
            onePercentLowChangePct=quantiles?change(a.metrics.onePercentLow,b.metrics.onePercentLow):Double.NaN;
            // Available observations remain visible even at low coverage. The warning must accompany interpretation.
            presentationFpsChangePct=usable&&validPresentation(a.metrics)&&validPresentation(b.metrics)
                    ?change(a.metrics.presentationFps,b.metrics.presentationFps):Double.NaN;
        }
        public String[] warnings() { return warnings.clone(); }
        public String toJson() {
            StringBuilder s=new StringBuilder("{\"pairIndex\":").append(pairIndex);
            FrameStats.field(s,"scene",scene);FrameStats.field(s,"load",load);FrameStats.field(s,"block",block);
            FrameStats.field(s,"aEntryIndex",aEntryIndex);FrameStats.field(s,"bEntryIndex",bEntryIndex);
            FrameStats.field(s,"usable",usable);FrameStats.field(s,"reason",reason);
            FrameStats.field(s,"configurationKey",configurationKey);
            FrameStats.field(s,"aSwapFps",aSwapFps);FrameStats.field(s,"bSwapFps",bSwapFps);
            FrameStats.field(s,"swapFpsChangePct",swapFpsChangePct);FrameStats.field(s,"p95ChangePct",p95ChangePct);
            FrameStats.field(s,"p99ChangePct",p99ChangePct);FrameStats.field(s,"onePercentLowChangePct",onePercentLowChangePct);
            FrameStats.field(s,"presentationFpsChangePct",presentationFpsChangePct);strings(s,"warnings",warnings);
            return s.append('}').toString();
        }
    }

    /** Statistics of pair-level changes, NOT a pooled frame-time percentile. */
    public static final class Changes {
        public final int count;
        public final double mean,median,min,max;
        private Changes(double[] source) {
            double[] finite=new double[source.length];int n=0;
            for(double value:source)if(Double.isFinite(value))finite[n++]=value;
            count=n;
            if(n==0){mean=median=min=max=Double.NaN;return;}
            Arrays.sort(finite,0,n);double average=0;
            for(int i=0;i<n;i++)average+=(finite[i]-average)/(i+1);
            mean=average;median=n%2==1?finite[n/2]:finite[n/2-1]/2+finite[n/2]/2;
            min=finite[0];max=finite[n-1];
        }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"count\":").append(count);
            FrameStats.field(b,"mean",mean);FrameStats.field(b,"median",median);
            FrameStats.field(b,"min",min);FrameStats.field(b,"max",max);
            return b.append('}').toString();
        }
    }

    public static final class GroupSummary {
        public final int scene,load,pairCount,warnedPairs,targetHz,renderWidth,renderHeight,surfaceWidth,surfaceHeight;
        public final long warmupMs,requestedMeasurementMs;
        public final String configurationKey,deviceKey;
        public final double pooledSwapFpsA,pooledSwapFpsB;
        public final Changes swapFpsChangePct,p95ChangePct,p99ChangePct,onePercentLowChangePct,presentationFpsChangePct;
        private GroupSummary(List<PairResult> pairs) {
            PairResult first=pairs.get(0);Observation a=first.a;Measurement m=a.metrics;
            scene=first.scene;load=first.load;configurationKey=a.configurationKey;deviceKey=a.environment.deviceKey;
            warmupMs=a.warmupMs;requestedMeasurementMs=a.requestedMeasurementMs;
            targetHz=m.targetHz;renderWidth=m.renderWidth;renderHeight=m.renderHeight;
            surfaceWidth=m.surfaceWidth;surfaceHeight=m.surfaceHeight;pairCount=pairs.size();
            double[] fps=new double[pairCount],p95=new double[pairCount],p99=new double[pairCount];
            double[] low=new double[pairCount],present=new double[pairCount];
            double ia=0,ib=0,ea=0,eb=0;int warnings=0;
            for(int i=0;i<pairCount;i++) {
                PairResult p=pairs.get(i);fps[i]=p.swapFpsChangePct;p95[i]=p.p95ChangePct;p99[i]=p.p99ChangePct;
                low[i]=p.onePercentLowChangePct;present[i]=p.presentationFpsChangePct;
                ia+=p.a.metrics.intervalCount;ib+=p.b.metrics.intervalCount;
                ea+=p.a.metrics.elapsedNs;eb+=p.b.metrics.elapsedNs;if(p.warnings.length>0)warnings++;
            }
            warnedPairs=warnings;pooledSwapFpsA=ia*1e9/ea;pooledSwapFpsB=ib*1e9/eb;
            swapFpsChangePct=new Changes(fps);p95ChangePct=new Changes(p95);p99ChangePct=new Changes(p99);
            onePercentLowChangePct=new Changes(low);presentationFpsChangePct=new Changes(present);
        }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"scene\":").append(scene);
            FrameStats.field(b,"load",load);FrameStats.field(b,"configurationKey",configurationKey);
            FrameStats.field(b,"deviceKey",deviceKey);FrameStats.field(b,"pairCount",pairCount);
            FrameStats.field(b,"warnedPairs",warnedPairs);FrameStats.field(b,"warmupMs",warmupMs);
            FrameStats.field(b,"requestedMeasurementMs",requestedMeasurementMs);FrameStats.field(b,"targetHz",targetHz);
            FrameStats.field(b,"renderWidth",renderWidth);FrameStats.field(b,"renderHeight",renderHeight);
            FrameStats.field(b,"surfaceWidth",surfaceWidth);FrameStats.field(b,"surfaceHeight",surfaceHeight);
            FrameStats.field(b,"pooledSwapFpsA",pooledSwapFpsA);FrameStats.field(b,"pooledSwapFpsB",pooledSwapFpsB);
            b.append(",\"swapFpsChangePct\":").append(swapFpsChangePct.toJson());
            b.append(",\"p95ChangePct\":").append(p95ChangePct.toJson());
            b.append(",\"p99ChangePct\":").append(p99ChangePct.toJson());
            b.append(",\"onePercentLowChangePct\":").append(onePercentLowChangePct.toJson());
            b.append(",\"presentationFpsChangePct\":").append(presentationFpsChangePct.toJson());
            return b.append('}').toString();
        }
    }

    private static String groupKey(PairResult p) {
        Observation a=p.a;Measurement m=a.metrics;
        StringBuilder b=new StringBuilder().append(p.scene).append(',').append(p.load).append(',');
        FrameStats.quote(b,a.configurationKey);b.append(',');FrameStats.quote(b,a.environment.deviceKey);
        return b.append(',').append(a.warmupMs).append(',').append(a.requestedMeasurementMs)
                .append(',').append(m.targetHz).append(',').append(m.renderWidth).append(',').append(m.renderHeight)
                .append(',').append(m.surfaceWidth).append(',').append(m.surfaceHeight).toString();
    }

    public static final class Summary {
        public final int plannedRuns,plannedPairs,observationCount,usablePairs,unusablePairs,warnedPairs;
        public final int unexpectedObservations,missingRuns,duplicateObservations;
        private final CampaignPlan plan;
        private final Observation[] observations;
        private final PairResult[] pairs;
        private final GroupSummary[] groups;
        private Summary(CampaignPlan plan,Observation[] observations,PairResult[] pairs,GroupSummary[] groups,
                        int usable,int warned,int unexpected,int missing,int duplicates) {
            this.plan=plan;this.observations=observations;this.pairs=pairs;this.groups=groups;
            plannedRuns=plan.runCount;plannedPairs=plan.pairCount;observationCount=observations.length;
            usablePairs=usable;unusablePairs=plannedPairs-usable;warnedPairs=warned;
            unexpectedObservations=unexpected;missingRuns=missing;duplicateObservations=duplicates;
        }
        public Observation[] observations(){return observations.clone();}
        public PairResult[] pairs(){return pairs.clone();}
        public GroupSummary[] groups(){return groups.clone();}
        public String spanishSummary() {
            StringBuilder b=new StringBuilder().append(usablePairs).append('/').append(plannedPairs)
                    .append(" pares completos y compatibles; ").append(observationCount).append('/')
                    .append(plannedRuns).append(" resultados recibidos. ").append(warnedPairs)
                    .append(" pares conservan avisos de contexto o cobertura.\n");
            for(GroupSummary g:groups)b.append("Escena ").append(g.scene).append(" · carga ").append(g.load)
                    .append(": cambio mediano de FPS entregados A/B ")
                    .append(String.format(Locale.ROOT,"%+.1f%%",g.swapFpsChangePct.median))
                    .append(" (").append(g.pairCount).append(" pares).\n");
            return b.append("Se conservan los valores extremos. ").append(LIMITATION).toString();
        }
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"schema\":\"x-gaming-lab-comparison-v2\"");
            FrameStats.field(b,"modeA","coordinated");FrameStats.field(b,"modeB","free");
            FrameStats.field(b,"changeDefinition","100*(A/B-1); higher FPS/1% low is better, lower p95/p99 is better");
            FrameStats.field(b,"outlierPolicy","none; all complete configuration-matched pairs retained, including environmental warnings");
            FrameStats.field(b,"limitation",LIMITATION);FrameStats.field(b,"summaryEs",spanishSummary());
            FrameStats.field(b,"plannedRuns",plannedRuns);FrameStats.field(b,"plannedPairs",plannedPairs);
            FrameStats.field(b,"observationCount",observationCount);FrameStats.field(b,"usablePairs",usablePairs);
            FrameStats.field(b,"unusablePairs",unusablePairs);FrameStats.field(b,"warnedPairs",warnedPairs);
            FrameStats.field(b,"unexpectedObservations",unexpectedObservations);FrameStats.field(b,"missingRuns",missingRuns);
            FrameStats.field(b,"duplicateObservations",duplicateObservations);b.append(",\"plan\":").append(plan.toJson());
            b.append(",\"observations\":[");
            for(int i=0;i<observations.length;i++){if(i>0)b.append(',');b.append(observations[i]==null?"null":observations[i].toJson());}
            b.append("],\"pairs\":[");for(int i=0;i<pairs.length;i++){if(i>0)b.append(',');b.append(pairs[i].toJson());}
            b.append("],\"groups\":[");for(int i=0;i<groups.length;i++){if(i>0)b.append(',');b.append(groups[i].toJson());}
            return b.append("]}").toString();
        }
    }

    static void strings(StringBuilder b,String name,String[] values) {
        b.append(',');FrameStats.quote(b,name);b.append(":[");
        for(int i=0;i<values.length;i++){if(i>0)b.append(',');FrameStats.quote(b,values[i]);}b.append(']');
    }
}
