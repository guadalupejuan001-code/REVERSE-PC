package x.lab.gaming;

import java.util.Arrays;

/**
 * One measured run, using the native lab_api.hpp double[80] protocol.
 * Thread-confined. record() allocates nothing and never retains the caller array.
 * Snapshot creation/sorting belongs at a reporting cadence, not every frame.
 *
 * "Rendered" here means a valid native frame with successful swap, not proof of
 * GPU completion or physical scanout. Only matched PRESENT_NS samples prove
 * presentation. GPU durations are separate asynchronous matched timer queries.
 */
public final class FrameStats {
    public static final int DEFAULT_CAPACITY = 65_536;
    public static final int METRIC_COUNT = 80;
    private static final int CHART_POINTS = 240;
    private static final double NS_PER_SECOND = 1_000_000_000.0;
    private static final double NS_PER_MS = 1_000_000.0;
    private static final double MAX_EXACT_ID = 9_007_199_254_740_991.0;

    /** Exact slot mapping to native/lab_api.hpp. No per-frame Sample object. */
    public static final class Metric {
        private Metric() {}
        public static final int SERIAL=0, SOURCE_REVISION=1, BEGIN_NS=2, CPU_NS=3,
            QSSD_NS=4, VIRTUAL_GPU_NS=5, GEOMETRY_NS=6, DRAW_SUBMIT_NS=7,
            SWAP_NS=8, END_NS=9, GPU_NS=10, PRESENT_NS=11, PRESENT_ID=12,
            PRESENT_PENDING=13, PRESENT_LOST=14, OBJECTS=15, TRIANGLES=16,
            DRAW_CALLS=17, WORK_ITEMS=18, PHYSICS_STEPS=19, STATE_AGE_NS=20,
            INPUT_TO_SUBMIT_NS=21, RENDER_WIDTH=22, RENDER_HEIGHT=23,
            SURFACE_WIDTH=24, SURFACE_HEIGHT=25, CACHE_HITS=26, CACHE_MISSES=27,
            UPLOAD_BYTES=28, PRESENT_SUPPORTED=29, GPU_TIMER_SUPPORTED=30,
            CONTEXT_GENERATION=31, STATE_HASH=32, INPUT_EVENTS=33,
            PREPARED_REGIONS=34, HOT_REGION_BUILDS=35, BUDGET_NS=36,
            SWAP_SUCCEEDED=37, PRESENT_PROCESSED=38, PRESENT_DISCARDED=39,
            GPU_SAMPLE_ID=40, GPU_DISCARDED=41, AUDIO_HZ=42, AUDIO_GAIN=43,
            CAMERA_INSTANCES=44, SHADOW_INSTANCES=45, INSTANCED_DRAWS=46, BATCHED_DRAWS=47,
            REFERENCE_DRAWS=48, GRAPHICS_PATH=49, QUANTUM_GATES=50, QUANTUM_CIRCUITS=51,
            QUANTUM_QUBITS=52, QUANTUM_SIGNAL=53, SHADOW_GPU_NS=54, SCENE_GPU_NS=55, SCREEN_GPU_NS=56,
            PWR_BASELINE_OBJECTS=57, PWR_PLANNED_OBJECTS=58, PWR_BASELINE_VERTICES=59, PWR_PLANNED_VERTICES=60,
            PWR_BASELINE_FRAGMENTS=61, PWR_PLANNED_FRAGMENTS=62, PWR_BASELINE_BYTES=63, PWR_PLANNED_BYTES=64,
            REUSED_OBJECTS=65, CHANGED_OBJECTS=66, SHADOW_PASS_AVOIDED=67, SCENE_PASS_AVOIDED=68;
    }

    private static final int[] STAGES = {Metric.CPU_NS, Metric.QSSD_NS,
        Metric.VIRTUAL_GPU_NS, Metric.GEOMETRY_NS, Metric.DRAW_SUBMIT_NS,
        Metric.SWAP_NS, Metric.STATE_AGE_NS, Metric.INPUT_TO_SUBMIT_NS};
    private static final int[] CUMULATIVE = {Metric.CACHE_HITS, Metric.CACHE_MISSES,
        Metric.PREPARED_REGIONS, Metric.HOT_REGION_BUILDS, Metric.INPUT_EVENTS,
        Metric.PRESENT_LOST, Metric.PRESENT_PROCESSED, Metric.PRESENT_DISCARDED,
        Metric.GPU_DISCARDED};
    private static final int[] COUNTS = {Metric.OBJECTS, Metric.TRIANGLES,
        Metric.DRAW_CALLS, Metric.UPLOAD_BYTES, Metric.WORK_ITEMS, Metric.PHYSICS_STEPS};
    private static final int[] PWR_SLOTS = {Metric.PWR_BASELINE_OBJECTS, Metric.PWR_PLANNED_OBJECTS,
        Metric.PWR_BASELINE_VERTICES, Metric.PWR_PLANNED_VERTICES,
        Metric.PWR_BASELINE_FRAGMENTS, Metric.PWR_PLANNED_FRAGMENTS,
        Metric.PWR_BASELINE_BYTES, Metric.PWR_PLANNED_BYTES};

    private final int targetHz;
    private final double budgetNs;
    private final long budgetCeilNs;
    private final long[] intervals;
    private final long[] measuredSerials;
    private final byte[] measuredFlags; // bit 1: presented, bit 2: GPU duration delivered
    private final double[] stageSums = new double[STAGES.length];
    private final long[] stageSamples = new long[STAGES.length];
    private final long[] cumulativeLast = new long[CUMULATIVE.length];
    private final long[] cumulativeDeltas = new long[CUMULATIVE.length];
    private final boolean[] cumulativeSeen = new boolean[CUMULATIVE.length];
    private final long[] countLast = new long[COUNTS.length];
    private final long[] countTotals = new long[COUNTS.length];
    private final long[] countSamples = new long[COUNTS.length];
    private final long[] histogram = new long[9];
    private final double[] histogramUpperNs;
    private int intervalWrite, retainedIntervals;
    private long firstSerial, lastSerial, firstBeginNs, lastAcceptedEndNs;
    private long firstSwapEndNs, lastSwapEndNs, firstPresentNs, lastPresentNs;
    private long contextGeneration = -1;
    private long attemptedCount, renderedCount, intervalCount, presentedCount, gpuSamples;
    private long missedIntervals, maximumIntervalNs, intervalOverflowCount;
    private long invalidSamples, duplicateSamples, outOfOrderSamples, invalidTimestampSamples;
    private long failedSwapCount, contextChanges, serialGaps, invalidMetricValues;
    private long invalidPresentationSamples, duplicatePresentationSamples, warmupPresentationSamples;
    private long unmatchedPresentationSamples, outOfOrderPresentationSamples;
    private long invalidGpuSamples, duplicateGpuSamples, warmupGpuSamples, unmatchedGpuSamples;
    private long counterResets, sourceStatesObserved, reusedSourceStates, sourceRegressions;
    private long sourceUpdatesAfterBaseline, unknownSourceStates, highestSourceRevision = -1;
    private long presentPending;
    private double gpuNsSum,shadowGpuNsSum,sceneGpuNsSum,screenGpuNsSum;
    private final long[] pwrTotals=new long[8];
    private long reusedObjectsTotal,changedObjectsTotal,shadowPassAvoidedTotal,scenePassAvoidedTotal;
    private int renderWidth, renderHeight, surfaceWidth, surfaceHeight;
    private boolean presentationSupported, gpuTimerSupported;

    public FrameStats(int targetHz) { this(targetHz, DEFAULT_CAPACITY); }

    /** Custom capacity supports bounded-memory consumers and deterministic overflow checks. */
    public FrameStats(int targetHz, int capacity) {
        if (targetHz < 1 || targetHz > 1_000_000_000)
            throw new IllegalArgumentException("targetHz must be positive and at most 1000000000");
        if (capacity < 2) throw new IllegalArgumentException("capacity must be at least two");
        this.targetHz = targetHz;
        this.budgetNs = NS_PER_SECOND / targetHz;
        // Native clocks store integer nanoseconds: allow only their rounding quantum.
        this.budgetCeilNs = (long) Math.ceil(budgetNs);
        this.intervals = new long[capacity];
        this.measuredSerials = new long[capacity];
        this.measuredFlags = new byte[capacity];
        this.histogramUpperNs = new double[] {budgetNs*.5, budgetCeilNs,
            budgetNs*1.5, budgetNs*2, budgetNs*3, budgetNs*4, budgetNs*6,
            budgetNs*12, Double.POSITIVE_INFINITY};
    }

    /**
     * Records one native result. Returns false for malformed/nonmonotonic input
     * or a changed context. A well-formed failed swap returns true but is counted
     * as failed, never as a rendered or presented frame. Root must reset/cancel
     * on pause, configure, context recreation or a change of measurement scope.
     */
    public boolean record(double[] m) {
        if (m == null || m.length < METRIC_COUNT || !id(m[Metric.SERIAL], false)
                || !id(m[Metric.CONTEXT_GENERATION], true)) {
            invalidSamples++; return false;
        }
        final long serial = (long) m[Metric.SERIAL];
        final long generation = (long) m[Metric.CONTEXT_GENERATION];
        if (firstSerial != 0 && generation != contextGeneration) {
            contextChanges++; invalidSamples++; return false;
        }
        if (firstSerial != 0 && serial <= lastSerial) {
            if (serial == lastSerial) duplicateSamples++; else outOfOrderSamples++;
            invalidSamples++; return false;
        }
        if (!timestamp(m[Metric.BEGIN_NS]) || !timestamp(m[Metric.END_NS])
                || m[Metric.END_NS] < m[Metric.BEGIN_NS]
                || (firstSerial != 0 && m[Metric.END_NS] <= lastAcceptedEndNs)) {
            invalidTimestampSamples++; invalidSamples++; return false;
        }
        final long begin = (long) m[Metric.BEGIN_NS], end = (long) m[Metric.END_NS];
        if (firstSerial == 0) {
            firstSerial = serial; firstBeginNs = begin; contextGeneration = generation;
        } else {
            serialGaps += serial - lastSerial - 1L;
        }
        lastSerial = serial; lastAcceptedEndNs = end; attemptedCount++;
        presentationSupported |= m[Metric.PRESENT_SUPPORTED] == 1.0;
        gpuTimerSupported |= m[Metric.GPU_TIMER_SUPPORTED] == 1.0;

        for (int i=0; i<STAGES.length; i++) {
            final double ns=m[STAGES[i]];
            if (duration(ns)) { stageSums[i]+=ns; stageSamples[i]++; }
            else if (ns != -1.0) invalidMetricValues++;
        }
        for (int i=0; i<CUMULATIVE.length; i++) addCumulative(i,m[CUMULATIVE[i]]);
        for (int i=0; i<COUNTS.length; i++) {
            final double value=m[COUNTS[i]];
            if (!id(value,true)) { invalidMetricValues++; continue; }
            final long count=(long)value;
            if (countTotals[i]>Long.MAX_VALUE-count) { invalidMetricValues++; continue; }
            countLast[i]=count; countTotals[i]+=count; countSamples[i]++;
        }
        for(int i=0;i<PWR_SLOTS.length;i++){double v=m[PWR_SLOTS[i]];if(id(v,true)){long x=(long)v;if(pwrTotals[i]<=Long.MAX_VALUE-x)pwrTotals[i]+=x;else invalidMetricValues++;}else invalidMetricValues++;}
        if(id(m[Metric.REUSED_OBJECTS],true))reusedObjectsTotal+=(long)m[Metric.REUSED_OBJECTS];else invalidMetricValues++;
        if(id(m[Metric.CHANGED_OBJECTS],true))changedObjectsTotal+=(long)m[Metric.CHANGED_OBJECTS];else invalidMetricValues++;
        if(id(m[Metric.SHADOW_PASS_AVOIDED],true))shadowPassAvoidedTotal+=(long)m[Metric.SHADOW_PASS_AVOIDED];else invalidMetricValues++;
        if(id(m[Metric.SCENE_PASS_AVOIDED],true))scenePassAvoidedTotal+=(long)m[Metric.SCENE_PASS_AVOIDED];else invalidMetricValues++;
        if (id(m[Metric.PRESENT_PENDING],true)) presentPending=(long)m[Metric.PRESENT_PENDING];
        else invalidMetricValues++;
        renderWidth=dimension(m[Metric.RENDER_WIDTH]); renderHeight=dimension(m[Metric.RENDER_HEIGHT]);
        surfaceWidth=dimension(m[Metric.SURFACE_WIDTH]); surfaceHeight=dimension(m[Metric.SURFACE_HEIGHT]);

        if (m[Metric.SWAP_SUCCEEDED] == 1.0) {
            if (renderedCount == 0) firstSwapEndNs=end;
            else addInterval(end-lastSwapEndNs);
            lastSwapEndNs=end; renderedCount++;
            final int slot=slot(serial);
            measuredSerials[slot]=serial; measuredFlags[slot]=0;
            observeSource(m[Metric.SOURCE_REVISION]);
        } else {
            failedSwapCount++;
            if (m[Metric.SWAP_SUCCEEDED] != 0.0) invalidMetricValues++;
        }
        observePresentation(m, end);
        observeGpu(m);
        return true;
    }

    private void addInterval(long ns) {
        intervals[intervalWrite]=ns;
        if (++intervalWrite == intervals.length) intervalWrite=0;
        if (retainedIntervals<intervals.length) retainedIntervals++;
        else intervalOverflowCount++;
        intervalCount++;
        if (ns>budgetCeilNs) missedIntervals++;
        if (ns>maximumIntervalNs) maximumIntervalNs=ns;
        for (int i=0; i<histogram.length; i++) {
            if (ns<=histogramUpperNs[i]) { histogram[i]++; break; }
        }
    }

    private void addCumulative(int index,double value) {
        if (!id(value,true)) { invalidMetricValues++; return; }
        final long count=(long)value;
        if (!cumulativeSeen[index]) cumulativeSeen[index]=true;
        else if (count<cumulativeLast[index]) counterResets++;
        else {
            final long delta=count-cumulativeLast[index];
            if (cumulativeDeltas[index]>Long.MAX_VALUE-delta) invalidMetricValues++;
            else cumulativeDeltas[index]+=delta;
        }
        cumulativeLast[index]=count;
    }

    private void observeSource(double revision) {
        if (!id(revision,true)) { unknownSourceStates++; return; }
        final long value=(long)revision;
        if (value>highestSourceRevision) {
            highestSourceRevision=value; sourceStatesObserved++;
            if (renderedCount>1) sourceUpdatesAfterBaseline++;
        } else if (value==highestSourceRevision) reusedSourceStates++;
        else sourceRegressions++;
    }

    private void observePresentation(double[] m,long observationEndNs) {
        final double value=m[Metric.PRESENT_NS];
        if (value == -1.0 || value == 0.0) return; // unavailable/pending, not a zero-duration result
        if (m[Metric.PRESENT_SUPPORTED] != 1.0 || !timestamp(value)
                || !id(m[Metric.PRESENT_ID],false)) { invalidPresentationSamples++; return; }
        final long serial=(long)m[Metric.PRESENT_ID], ns=(long)value;
        if (serial<firstSerial) { warmupPresentationSamples++; return; }
        if (serial>lastSerial || measuredSerials[slot(serial)]!=serial) {
            unmatchedPresentationSamples++; return;
        }
        final int slot=slot(serial);
        if ((measuredFlags[slot]&1)!=0) { duplicatePresentationSamples++; return; }
        if (ns<firstBeginNs || ns>observationEndNs) { invalidPresentationSamples++; return; }
        if (presentedCount>0 && ns<=lastPresentNs) { outOfOrderPresentationSamples++; return; }
        measuredFlags[slot]|=1;
        if (presentedCount==0) firstPresentNs=ns;
        lastPresentNs=ns; presentedCount++;
    }

    private void observeGpu(double[] m) {
        final double ns=m[Metric.GPU_NS];
        if (ns == -1.0) return; // unavailable, pending or disjoint: never fake zero GPU time
        if (m[Metric.GPU_TIMER_SUPPORTED] != 1.0 || !duration(ns)
                || !id(m[Metric.GPU_SAMPLE_ID],false)) { invalidGpuSamples++; return; }
        final long serial=(long)m[Metric.GPU_SAMPLE_ID];
        if (serial<firstSerial) { warmupGpuSamples++; return; }
        if (serial>lastSerial || measuredSerials[slot(serial)]!=serial) {
            unmatchedGpuSamples++; return;
        }
        final int slot=slot(serial);
        if ((measuredFlags[slot]&2)!=0) { duplicateGpuSamples++; return; }
        measuredFlags[slot]|=2; gpuNsSum+=ns;
        if(duration(m[Metric.SHADOW_GPU_NS]))shadowGpuNsSum+=m[Metric.SHADOW_GPU_NS];else invalidGpuSamples++;
        if(duration(m[Metric.SCENE_GPU_NS]))sceneGpuNsSum+=m[Metric.SCENE_GPU_NS];else invalidGpuSamples++;
        if(duration(m[Metric.SCREEN_GPU_NS]))screenGpuNsSum+=m[Metric.SCREEN_GPU_NS];else invalidGpuSamples++;
        gpuSamples++;
    }

    private int slot(long serial) { return (int)(serial%measuredSerials.length); }
    private static boolean id(double value,boolean zero) {
        return Double.isFinite(value) && value >= (zero?0.0:1.0)
                && value<=MAX_EXACT_ID && value==Math.rint(value);
    }
    private static boolean timestamp(double value) {
        return value>0.0 && value<0x1.0p63 && Double.isFinite(value) && value==Math.rint(value);
    }
    private static boolean duration(double value) {
        return value>=0.0 && value<0x1.0p63 && Double.isFinite(value) && value==Math.rint(value);
    }
    private int dimension(double value) {
        if (id(value,true)&&value<=Integer.MAX_VALUE) return (int)value;
        invalidMetricValues++; return 0;
    }

    /** Discards warmup/prior-run evidence; the next valid native serial starts a new scope. */
    public void reset() {
        intervalWrite=retainedIntervals=0;
        firstSerial=lastSerial=firstBeginNs=lastAcceptedEndNs=0;
        firstSwapEndNs=lastSwapEndNs=firstPresentNs=lastPresentNs=0;
        contextGeneration=-1;
        attemptedCount=renderedCount=intervalCount=presentedCount=gpuSamples=0;
        missedIntervals=maximumIntervalNs=intervalOverflowCount=0;
        invalidSamples=duplicateSamples=outOfOrderSamples=invalidTimestampSamples=0;
        failedSwapCount=contextChanges=serialGaps=invalidMetricValues=0;
        invalidPresentationSamples=duplicatePresentationSamples=warmupPresentationSamples=0;
        unmatchedPresentationSamples=outOfOrderPresentationSamples=0;
        invalidGpuSamples=duplicateGpuSamples=warmupGpuSamples=unmatchedGpuSamples=0;
        counterResets=sourceStatesObserved=reusedSourceStates=sourceRegressions=0;
        sourceUpdatesAfterBaseline=unknownSourceStates=presentPending=0;
        highestSourceRevision=-1;gpuNsSum=shadowGpuNsSum=sceneGpuNsSum=screenGpuNsSum=0.0;
        Arrays.fill(pwrTotals,0L);reusedObjectsTotal=changedObjectsTotal=shadowPassAvoidedTotal=scenePassAvoidedTotal=0;
        renderWidth=renderHeight=surfaceWidth=surfaceHeight=0;
        presentationSupported=gpuTimerSupported=false;
        Arrays.fill(measuredSerials,0L);Arrays.fill(measuredFlags,(byte)0);
        Arrays.fill(stageSums,0.0);Arrays.fill(stageSamples,0L);
        Arrays.fill(cumulativeLast,0L);Arrays.fill(cumulativeDeltas,0L);
        Arrays.fill(cumulativeSeen,false);Arrays.fill(countLast,0L);
        Arrays.fill(countTotals,0L);Arrays.fill(countSamples,0L);Arrays.fill(histogram,0L);
    }

    public Snapshot snapshot() { return new Snapshot(this); }

    public static final class Snapshot {
        public final int targetHz, capacity, quantileSamples;
        public final boolean quantilesComplete, presentationSupported, gpuTimerSupported;
        public final long attemptedCount, renderedCount, intervalCount, presentedCount, gpuSamples;
        public final double swapFps, presentationFps, presentationCoverage, gpuCoverage, measuredSeconds;
        public final double frameMsP50, frameMsP95, frameMsP99, maxFrameMs, onePercentLow;
        public final double missedBudgetRatio, budgetMs, cpuMs, qssdMs, virtualGpuMs, geometryMs;
        public final double submitMs, swapMs, gpuMs, shadowGpuMs, sceneGpuMs, screenGpuMs, stateAgeMs, inputToSubmitMs, sourceStateHz;
        public final long pwrBaselineObjects,pwrPlannedObjects,pwrBaselineVertices,pwrPlannedVertices,pwrBaselineFragments,pwrPlannedFragments,pwrBaselineBytes,pwrPlannedBytes;
        public final long reusedObjects,changedObjects,shadowPassAvoided,scenePassAvoided;
        public final double pwrObjectsPct,pwrVerticesPct,pwrFragmentsPct,pwrBytesPct;
        public final long missedIntervals, firstSerial, lastSerial, elapsedNs;
        public final long sourceStatesObserved, reusedSourceStates, sourceRegressions, unknownSourceStates;
        public final long objects, triangles, drawCalls, uploadBytes, workItems, physicsSteps;
        public final double objectsMean, trianglesMean, drawCallsMean;
        public final long cacheHits, cacheMisses, preparedRegions, hotRegionBuilds, inputEvents;
        public final long nativePresentLost, nativePresentProcessed, nativePresentDiscarded, gpuDiscarded;
        public final long presentPending, invalidSamples, duplicateSamples, outOfOrderSamples;
        public final long invalidTimestampSamples, invalidMetricValues, failedSwapCount, contextChanges;
        public final long serialGaps, counterResets, intervalOverflowCount;
        public final long invalidPresentationSamples, duplicatePresentationSamples, warmupPresentationSamples;
        public final long unmatchedPresentationSamples, outOfOrderPresentationSamples;
        public final long invalidGpuSamples, duplicateGpuSamples, warmupGpuSamples, unmatchedGpuSamples;
        public final int renderWidth, renderHeight, surfaceWidth, surfaceHeight;
        private final double[] recentFramesMs, histogramBoundsMs;
        private final long[] histogramValues;

        private Snapshot(FrameStats s) {
            targetHz=s.targetHz;capacity=s.intervals.length;quantileSamples=s.retainedIntervals;
            quantilesComplete=s.intervalOverflowCount==0;
            presentationSupported=s.presentationSupported;gpuTimerSupported=s.gpuTimerSupported;
            attemptedCount=s.attemptedCount;renderedCount=s.renderedCount;intervalCount=s.intervalCount;
            presentedCount=s.presentedCount;gpuSamples=s.gpuSamples;
            elapsedNs=renderedCount>1?s.lastSwapEndNs-s.firstSwapEndNs:0L;
            measuredSeconds=elapsedNs/NS_PER_SECOND;
            swapFps=rate(intervalCount,elapsedNs);
            presentationFps=presentedCount<2?Double.NaN:
                    rate(presentedCount-1,s.lastPresentNs-s.firstPresentNs);
            presentationCoverage=ratio(presentedCount,renderedCount);
            gpuCoverage=ratio(gpuSamples,renderedCount);
            budgetMs=s.budgetNs/NS_PER_MS;
            final long[] sorted=Arrays.copyOf(s.intervals,s.retainedIntervals);
            Arrays.sort(sorted);
            frameMsP50=quantilesComplete?percentile(sorted,50):Double.NaN;
            frameMsP95=quantilesComplete?percentile(sorted,95):Double.NaN;
            frameMsP99=quantilesComplete?percentile(sorted,99):Double.NaN;
            maxFrameMs=intervalCount==0?Double.NaN:s.maximumIntervalNs/NS_PER_MS;
            if (!quantilesComplete || sorted.length==0) onePercentLow=Double.NaN;
            else {
                final int worst=(sorted.length+99)/100;
                double sum=0.0;for(int i=sorted.length-worst;i<sorted.length;i++)sum+=sorted[i];
                onePercentLow=NS_PER_SECOND/(sum/worst);
            }
            missedIntervals=s.missedIntervals;missedBudgetRatio=ratio(missedIntervals,intervalCount);
            cpuMs=stageMean(s,0);qssdMs=stageMean(s,1);virtualGpuMs=stageMean(s,2);
            geometryMs=stageMean(s,3);submitMs=stageMean(s,4);swapMs=stageMean(s,5);
            stateAgeMs=stageMean(s,6);inputToSubmitMs=stageMean(s,7);
            gpuMs=gpuSamples==0?Double.NaN:s.gpuNsSum/gpuSamples/NS_PER_MS;
            shadowGpuMs=gpuSamples==0?Double.NaN:s.shadowGpuNsSum/gpuSamples/NS_PER_MS;sceneGpuMs=gpuSamples==0?Double.NaN:s.sceneGpuNsSum/gpuSamples/NS_PER_MS;screenGpuMs=gpuSamples==0?Double.NaN:s.screenGpuNsSum/gpuSamples/NS_PER_MS;
            pwrBaselineObjects=s.pwrTotals[0];pwrPlannedObjects=s.pwrTotals[1];pwrBaselineVertices=s.pwrTotals[2];pwrPlannedVertices=s.pwrTotals[3];pwrBaselineFragments=s.pwrTotals[4];pwrPlannedFragments=s.pwrTotals[5];pwrBaselineBytes=s.pwrTotals[6];pwrPlannedBytes=s.pwrTotals[7];
            reusedObjects=s.reusedObjectsTotal;changedObjects=s.changedObjectsTotal;shadowPassAvoided=s.shadowPassAvoidedTotal;scenePassAvoided=s.scenePassAvoidedTotal;
            pwrObjectsPct=pwr(pwrBaselineObjects,pwrPlannedObjects);pwrVerticesPct=pwr(pwrBaselineVertices,pwrPlannedVertices);pwrFragmentsPct=pwr(pwrBaselineFragments,pwrPlannedFragments);pwrBytesPct=pwr(pwrBaselineBytes,pwrPlannedBytes);
            firstSerial=s.firstSerial;lastSerial=s.lastSerial;
            sourceStatesObserved=s.sourceStatesObserved;reusedSourceStates=s.reusedSourceStates;
            sourceRegressions=s.sourceRegressions;unknownSourceStates=s.unknownSourceStates;
            sourceStateHz=sourceRegressions!=0||unknownSourceStates!=0?Double.NaN:
                    rate(s.sourceUpdatesAfterBaseline,elapsedNs);
            objects=s.countLast[0];triangles=s.countLast[1];drawCalls=s.countLast[2];
            objectsMean=countMean(s,0);trianglesMean=countMean(s,1);drawCallsMean=countMean(s,2);
            uploadBytes=s.countTotals[3];workItems=s.countTotals[4];physicsSteps=s.countTotals[5];
            cacheHits=s.cumulativeDeltas[0];cacheMisses=s.cumulativeDeltas[1];
            preparedRegions=s.cumulativeDeltas[2];hotRegionBuilds=s.cumulativeDeltas[3];
            inputEvents=s.cumulativeDeltas[4];nativePresentLost=s.cumulativeDeltas[5];
            nativePresentProcessed=s.cumulativeDeltas[6];nativePresentDiscarded=s.cumulativeDeltas[7];
            gpuDiscarded=s.cumulativeDeltas[8];presentPending=s.presentPending;
            invalidSamples=s.invalidSamples;duplicateSamples=s.duplicateSamples;
            outOfOrderSamples=s.outOfOrderSamples;invalidTimestampSamples=s.invalidTimestampSamples;
            invalidMetricValues=s.invalidMetricValues;failedSwapCount=s.failedSwapCount;
            contextChanges=s.contextChanges;serialGaps=s.serialGaps;counterResets=s.counterResets;
            intervalOverflowCount=s.intervalOverflowCount;
            invalidPresentationSamples=s.invalidPresentationSamples;
            duplicatePresentationSamples=s.duplicatePresentationSamples;
            warmupPresentationSamples=s.warmupPresentationSamples;
            unmatchedPresentationSamples=s.unmatchedPresentationSamples;
            outOfOrderPresentationSamples=s.outOfOrderPresentationSamples;
            invalidGpuSamples=s.invalidGpuSamples;duplicateGpuSamples=s.duplicateGpuSamples;
            warmupGpuSamples=s.warmupGpuSamples;unmatchedGpuSamples=s.unmatchedGpuSamples;
            renderWidth=s.renderWidth;renderHeight=s.renderHeight;
            surfaceWidth=s.surfaceWidth;surfaceHeight=s.surfaceHeight;
            final int recent=Math.min(CHART_POINTS,s.retainedIntervals);
            recentFramesMs=new double[recent];
            int start=(s.intervalWrite-recent+s.intervals.length)%s.intervals.length;
            for(int i=0;i<recent;i++)recentFramesMs[i]=s.intervals[(start+i)%s.intervals.length]/NS_PER_MS;
            histogramValues=s.histogram.clone();histogramBoundsMs=new double[s.histogramUpperNs.length];
            for(int i=0;i<histogramBoundsMs.length;i++)histogramBoundsMs[i]=s.histogramUpperNs[i]/NS_PER_MS;
        }

        private static double percentile(long[] sorted,int percentile) {
            if(sorted.length==0)return Double.NaN;
            int rank=(int)(((long)sorted.length*percentile+99)/100);
            return sorted[rank-1]/NS_PER_MS;
        }
        private static double stageMean(FrameStats s,int index) {
            return s.stageSamples[index]==0?Double.NaN:s.stageSums[index]/s.stageSamples[index]/NS_PER_MS;
        }
        private static double countMean(FrameStats s,int index) {
            return s.countSamples[index]==0?Double.NaN:(double)s.countTotals[index]/s.countSamples[index];
        }
        private static double rate(long intervals,long ns) {
            return ns<=0?Double.NaN:intervals*(NS_PER_SECOND/ns);
        }
        private static double ratio(long numerator,long denominator) {
            return denominator==0?Double.NaN:(double)numerator/denominator;
        }
        private static double pwr(long baseline,long planned){return baseline==0?Double.NaN:100.0*(baseline-planned)/baseline;}
        public double[] recentFrameMs() { return recentFramesMs.clone(); }
        public long[] histogramCounts() { return histogramValues.clone(); }
        /** Last bin has +Infinity upper bound, rendered as null in JSON (open-ended). */
        public double[] histogramUpperMs() { return histogramBoundsMs.clone(); }

        /** Standards-compliant JSON: unavailable/nonfinite quantities are null. */
        public String toJson() {
            StringBuilder b=new StringBuilder(7_000);
            b.append("{\"schema\":\"x-gaming-lab-metrics-v1\"");
            field(b,"completionRateScope","successful-native-frame-end-wall-intervals");
            field(b,"presentationRateScope","observed-unique-physical-presentation-timestamps");
            field(b,"gpuTimeScope","matched-asynchronous-scene-timer-excludes-swap-compositor");
            field(b,"targetHz",targetHz);field(b,"budgetMs",budgetMs);
            field(b,"attemptedCount",attemptedCount);field(b,"renderedCount",renderedCount);
            field(b,"intervalCount",intervalCount);field(b,"presentedCount",presentedCount);
            field(b,"gpuSamples",gpuSamples);field(b,"swapFps",swapFps);
            field(b,"presentationFps",presentationFps);field(b,"presentationCoverage",presentationCoverage);
            field(b,"gpuCoverage",gpuCoverage);field(b,"measuredSeconds",measuredSeconds);
            field(b,"frameMsP50",frameMsP50);field(b,"frameMsP95",frameMsP95);
            field(b,"frameMsP99",frameMsP99);field(b,"maxFrameMs",maxFrameMs);
            field(b,"onePercentLow",onePercentLow);field(b,"missedIntervals",missedIntervals);
            field(b,"missedBudgetRatio",missedBudgetRatio);
            field(b,"cpuMs",cpuMs);field(b,"qssdMs",qssdMs);field(b,"virtualGpuMs",virtualGpuMs);
            field(b,"geometryMs",geometryMs);field(b,"submitMs",submitMs);field(b,"swapMs",swapMs);
            field(b,"gpuMs",gpuMs);field(b,"shadowGpuMs",shadowGpuMs);field(b,"sceneGpuMs",sceneGpuMs);field(b,"screenGpuMs",screenGpuMs);field(b,"stateAgeMs",stateAgeMs);field(b,"inputToSubmitMs",inputToSubmitMs);
            field(b,"sourceStatesObserved",sourceStatesObserved);field(b,"reusedSourceStates",reusedSourceStates);
            field(b,"sourceStateHz",sourceStateHz);field(b,"sourceRegressions",sourceRegressions);
            field(b,"unknownSourceStates",unknownSourceStates);
            field(b,"objects",objects);field(b,"triangles",triangles);field(b,"drawCalls",drawCalls);
            field(b,"objectsMean",objectsMean);field(b,"trianglesMean",trianglesMean);field(b,"drawCallsMean",drawCallsMean);
            field(b,"uploadBytes",uploadBytes);field(b,"workItems",workItems);field(b,"physicsSteps",physicsSteps);
            field(b,"pwrBaselineObjects",pwrBaselineObjects);field(b,"pwrPlannedObjects",pwrPlannedObjects);field(b,"pwrObjectsPct",pwrObjectsPct);
            field(b,"pwrBaselineVertices",pwrBaselineVertices);field(b,"pwrPlannedVertices",pwrPlannedVertices);field(b,"pwrVerticesPct",pwrVerticesPct);
            field(b,"pwrBaselineFragmentsEstimate",pwrBaselineFragments);field(b,"pwrPlannedFragmentsEstimate",pwrPlannedFragments);field(b,"pwrFragmentsEstimatePct",pwrFragmentsPct);
            field(b,"pwrBaselineInstanceBytes",pwrBaselineBytes);field(b,"pwrPlannedInstanceBytes",pwrPlannedBytes);field(b,"pwrInstanceBytesPct",pwrBytesPct);
            field(b,"reusedObjects",reusedObjects);field(b,"changedObjects",changedObjects);field(b,"shadowPassesAvoided",shadowPassAvoided);field(b,"scenePassesAvoided",scenePassAvoided);
            field(b,"cacheHits",cacheHits);field(b,"cacheMisses",cacheMisses);
            field(b,"preparedRegions",preparedRegions);field(b,"hotRegionBuilds",hotRegionBuilds);
            field(b,"inputEvents",inputEvents);field(b,"presentPending",presentPending);
            field(b,"nativePresentLost",nativePresentLost);field(b,"nativePresentProcessed",nativePresentProcessed);
            field(b,"nativePresentDiscarded",nativePresentDiscarded);field(b,"gpuDiscarded",gpuDiscarded);
            field(b,"invalidSamples",invalidSamples);field(b,"duplicateSamples",duplicateSamples);
            field(b,"outOfOrderSamples",outOfOrderSamples);field(b,"invalidTimestampSamples",invalidTimestampSamples);
            field(b,"invalidMetricValues",invalidMetricValues);field(b,"failedSwapCount",failedSwapCount);
            field(b,"contextChanges",contextChanges);field(b,"serialGaps",serialGaps);field(b,"counterResets",counterResets);
            field(b,"invalidPresentationSamples",invalidPresentationSamples);
            field(b,"duplicatePresentationSamples",duplicatePresentationSamples);
            field(b,"warmupPresentationSamples",warmupPresentationSamples);
            field(b,"unmatchedPresentationSamples",unmatchedPresentationSamples);
            field(b,"outOfOrderPresentationSamples",outOfOrderPresentationSamples);
            field(b,"invalidGpuSamples",invalidGpuSamples);field(b,"duplicateGpuSamples",duplicateGpuSamples);
            field(b,"warmupGpuSamples",warmupGpuSamples);field(b,"unmatchedGpuSamples",unmatchedGpuSamples);
            field(b,"renderWidth",renderWidth);field(b,"renderHeight",renderHeight);
            field(b,"surfaceWidth",surfaceWidth);field(b,"surfaceHeight",surfaceHeight);
            field(b,"firstSerial",firstSerial);field(b,"lastSerial",lastSerial);field(b,"elapsedNs",elapsedNs);
            field(b,"capacity",capacity);field(b,"quantileSamples",quantileSamples);
            field(b,"quantilesComplete",quantilesComplete);field(b,"intervalOverflowCount",intervalOverflowCount);
            field(b,"presentationSupported",presentationSupported);field(b,"gpuTimerSupported",gpuTimerSupported);
            array(b,"recentFrameMs",recentFramesMs);array(b,"histogramUpperMs",histogramBoundsMs);
            b.append(",\"histogramCounts\":[");
            for(int i=0;i<histogramValues.length;i++){if(i>0)b.append(',');b.append(histogramValues[i]);}
            return b.append("]}").toString();
        }
    }

    static void field(StringBuilder b,String name,String value) {
        b.append(',');quote(b,name);b.append(':');quote(b,value);
    }
    static void field(StringBuilder b,String name,long value) {
        b.append(',');quote(b,name);b.append(':').append(value);
    }
    static void field(StringBuilder b,String name,double value) {
        b.append(',');quote(b,name);b.append(':');number(b,value);
    }
    static void field(StringBuilder b,String name,boolean value) {
        b.append(',');quote(b,name);b.append(':').append(value);
    }
    private static void array(StringBuilder b,String name,double[] values) {
        b.append(',');quote(b,name);b.append(": [");
        for(int i=0;i<values.length;i++){if(i>0)b.append(',');number(b,values[i]);}b.append(']');
    }
    private static void number(StringBuilder b,double value) {
        if(Double.isFinite(value))b.append(value);else b.append("null");
    }
    static void quote(StringBuilder b,String value) {
        if(value==null){b.append("null");return;}
        b.append('"');
        final String hex="0123456789abcdef";
        for(int i=0;i<value.length();i++){
            char c=value.charAt(i);
            if(c=='"'||c=='\\')b.append('\\').append(c);
            else if(c=='\n')b.append("\\n");else if(c=='\r')b.append("\\r");
            else if(c=='\t')b.append("\\t");else if(c<0x20)
                b.append("\\u00").append(hex.charAt(c>>>4)).append(hex.charAt(c&15));
            else b.append(c);
        }
        b.append('"');
    }
}
