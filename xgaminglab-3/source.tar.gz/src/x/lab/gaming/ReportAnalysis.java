package x.lab.gaming;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;

/** Bridges saved reports to the independently tested comparison engine. */
final class ReportAnalysis {
    static ComparisonAnalysis.Measurement measurement(JSONObject m){
        return new ComparisonAnalysis.Measurement.Builder()
            .cadence(m.optLong("renderedCount"),m.optLong("intervalCount"),m.optLong("elapsedNs"))
            .targetHz(m.optInt("targetHz"))
            .dimensions(m.optInt("renderWidth"),m.optInt("renderHeight"),m.optInt("surfaceWidth"),m.optInt("surfaceHeight"))
            .frameTimes(m.optDouble("frameMsP95"),m.optDouble("frameMsP99"),m.optDouble("onePercentLow"))
            .stages(m.optDouble("cpuMs"),m.optDouble("qssdMs"),m.optDouble("virtualGpuMs"),m.optDouble("geometryMs"),m.optDouble("submitMs"),m.optDouble("swapMs"),m.optDouble("gpuMs"))
            .coverage(m.optDouble("presentationFps"),m.optDouble("presentationCoverage"),m.optDouble("gpuCoverage"))
            .integrity(m.optLong("invalidSamples"),m.optLong("failedSwapCount"),m.optBoolean("quantilesComplete")).build();
    }
    static ComparisonAnalysis.Environment environment(JSONObject report,JSONObject result){
        JSONObject device=result.optJSONObject("deviceAtCaseStart");if(device==null)device=report.optJSONObject("deviceAtStart");if(device==null)return ComparisonAnalysis.Environment.unknown();
        JSONObject x=result.optJSONObject("execution");if(x==null)x=new JSONObject();
        String key=device.optString("manufacturer")+"|"+device.optString("model")+"|"+device.optString("device")+"|"+device.optString("sdk");
        return new ComparisonAnalysis.Environment(key,x.optDouble("minDisplayHz",device.optDouble("activeRefreshHz")),x.optDouble("maxDisplayHz",device.optDouble("activeRefreshHz")),
            device.optInt("thermalStatus",-1),x.optInt("maxThermalStatus",-1),device.optBoolean("powerSaveMode"),device.has("powerSaveMode"));
    }
    static JSONObject hypothesis(JSONObject report,JSONObject result)throws Exception{
        JSONObject m=result.optJSONObject("metrics"),c=result.optJSONObject("configuration");
        if(m==null||c==null)return new JSONObject();
        return new JSONObject(BottleneckAnalysis.inspect(measurement(m),environment(report,result),c.optBoolean("coordinated")).toJson());
    }
    static void update(JSONObject report){
        try {
            JSONObject planned=report.optJSONObject("campaign");if(planned==null)return;
            JSONArray entries=planned.getJSONArray("entries");LinkedHashSet<Integer> scenes=new LinkedHashSet<>(),loads=new LinkedHashSet<>();
            for(int i=0;i<entries.length();i++){JSONObject e=entries.getJSONObject(i);scenes.add(e.getInt("scene"));loads.add(e.getInt("load"));}
            CampaignPlan plan=CampaignPlan.abba(array(scenes),array(loads),planned.getInt("blocksPerSceneLoad"));
            JSONArray rows=report.optJSONArray("results");ArrayList<ComparisonAnalysis.Observation> all=new ArrayList<>();
            if(rows!=null)for(int i=0;i<rows.length();i++){
                JSONObject r=rows.optJSONObject(i);if(r==null)continue;JSONObject c=r.optJSONObject("configuration"),m=r.optJSONObject("metrics");if(c==null||m==null)continue;
                String key=report.optString("sourceId")+"|scene="+c.optInt("scene")+"|load="+c.optInt("load")+"|hz="+c.optInt("targetHz")+"|resolution="+c.optDouble("resolutionScale")+"|audio="+c.optBoolean("audio")+"|input="+c.optBoolean("interactive")+"|seed="+c.optLong("seed")+"|graphics="+c.optInt("graphicsPath");
                all.add(new ComparisonAnalysis.Observation(c.optInt("campaignIndex",-1),key,c.optLong("warmupMs"),c.optLong("requestedMeasurementMs"),measurement(m),r.optBoolean("complete"),environment(report,r)));
            }
            report.put("comparison",new JSONObject(ComparisonAnalysis.analyze(plan,all.toArray(new ComparisonAnalysis.Observation[0])).toJson()));
        }catch(Exception e){try{report.put("comparisonError",String.valueOf(e.getMessage()));}catch(Exception ignored){}}
    }
    private static int[] array(LinkedHashSet<Integer> set){int[] a=new int[set.size()];int i=0;for(int x:set)a[i++]=x;return a;}
}
