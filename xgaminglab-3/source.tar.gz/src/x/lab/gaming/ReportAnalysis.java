package x.lab.gaming;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashSet;

/** Bridges saved reports to the independently tested comparison engine. */
final class ReportAnalysis {
    static ComparisonAnalysis.Measurement measurement(JSONObject m){
        return new ComparisonAnalysis.Measurement.Builder()
            .cadence(m.optLong("renderedCount"),m.optLong("intervalCount"),m.optLong("elapsedNs"))
            .targetHz(m.optInt("targetHz"))
            .dimensions(m.optInt("renderWidth"),m.optInt("renderHeight"),m.optInt("surfaceWidth"),m.optInt("surfaceHeight"))
            .frameTimes(m.optDouble("frameMsP95"),m.optDouble("frameMsP99"),m.optDouble("onePercentLow"))
            .stages(m.optDouble("cpuMs"),m.optDouble("qssdMs"),m.optDouble("virtualGpuMs"),m.optDouble("geometryMs"),m.optDouble("submitMs"),m.optDouble("swapMs"),m.optDouble("gpuMs"))
            .coverage(m.optDouble("presentationFps"),m.optDouble("presentationCoverage"),m.optDouble("gpuCoverage"))
            .integrity(m.optLong("invalidSamples"),m.optLong("failedSwapCount"),m.optBoolean("quantilesComplete")).build();
    }
    static ComparisonAnalysis.Environment environment(JSONObject report,JSONObject result){
        JSONObject device=result.optJSONObject("deviceAtCaseStart");if(device==null)device=report.optJSONObject("deviceAtStart");if(device==null)return ComparisonAnalysis.Environment.unknown();
        JSONObject x=result.optJSONObject("execution");if(x==null)x=new JSONObject();
        String key=device.optString("manufacturer")+"|"+device.optString("model")+"|"+device.optString("device")+"|"+device.optString("sdk");
        return new ComparisonAnalysis.Environment(key,x.optDouble("minDisplayHz",device.optDouble("activeRefreshHz")),x.optDouble("maxDisplayHz",device.optDouble("activeRefreshHz")),
            device.optInt("thermalStatus",-1),x.optInt("maxThermalStatus",-1),device.optBoolean("powerSaveMode"),device.has("powerSaveMode"));
    }
    static JSONObject hypothesis(JSONObject report,JSONObject result)throws Exception{
        JSONObject m=result.optJSONObject("metrics"),c=result.optJSONObject("configuration");
        if(m==null||c==null)return new JSONObject();
        return new JSONObject(BottleneckAnalysis.inspect(measurement(m),environment(report,result),c.optBoolean("coordinated")).toJson());
    }
    static void update(JSONObject report){
        try {
            JSONObject planned=report.optJSONObject("campaign");
            if(planned==null){if("Ablaciones GPU Virtual".equals(report.optString("label")))updateAblation(report);return;}
            JSONArray entries=planned.getJSONArray("entries");LinkedHashSet<Integer> scenes=new LinkedHashSet<>(),loads=new LinkedHashSet<>();
            for(int i=0;i<entries.length();i++){JSONObject e=entries.getJSONObject(i);scenes.add(e.getInt("scene"));loads.add(e.getInt("load"));}
            CampaignPlan plan=CampaignPlan.abba(array(scenes),array(loads),planned.getInt("blocksPerSceneLoad"));
            JSONArray rows=report.optJSONArray("results");ArrayList<ComparisonAnalysis.Observation> all=new ArrayList<>();
            if(rows!=null)for(int i=0;i<rows.length();i++){
                JSONObject r=rows.optJSONObject(i);if(r==null)continue;JSONObject c=r.optJSONObject("configuration"),m=r.optJSONObject("metrics");if(c==null||m==null)continue;
                String key=report.optString("sourceId")+"|scene="+c.optInt("scene")+"|load="+c.optInt("load")+"|hz="+c.optInt("targetHz")+"|resolution="+c.optDouble("resolutionScale")+"|audio="+c.optBoolean("audio")+"|input="+c.optBoolean("interactive")+"|seed="+c.optLong("seed")+"|graphics="+c.optInt("graphicsPath");
                all.add(new ComparisonAnalysis.Observation(c.optInt("campaignIndex",-1),key,c.optLong("warmupMs"),c.optLong("requestedMeasurementMs"),measurement(m),r.optBoolean("complete"),environment(report,r)));
            }
            report.put("comparison",new JSONObject(ComparisonAnalysis.analyze(plan,all.toArray(new ComparisonAnalysis.Observation[0])).toJson()));
        }catch(Exception e){try{report.put("comparisonError",String.valueOf(e.getMessage()));}catch(Exception ignored){}}
    }
    private static void updateAblation(JSONObject report)throws Exception{
        JSONArray rows=report.optJSONArray("results"),pairs=new JSONArray();int usable=0;
        if(rows==null){report.put("ablation",new JSONObject().put("schema","x-gaming-lab-ablation-v1").put("usablePairs",0).put("pairs",pairs).put("summaryEs","Sin ejecuciones pareables."));return;}
        for(int i=0;i+1<rows.length();i+=2){
            JSONObject active=rows.optJSONObject(i),variant=rows.optJSONObject(i+1);if(active==null||variant==null)continue;
            JSONObject ac=active.optJSONObject("configuration"),vc=variant.optJSONObject("configuration"),am=active.optJSONObject("metrics"),vm=variant.optJSONObject("metrics");
            JSONObject p=new JSONObject();p.put("pairIndex",i/2);p.put("activeGraphicsPath",ac==null?-1:ac.optInt("graphicsPath",-1));p.put("variantGraphicsPath",vc==null?-1:vc.optInt("graphicsPath",-1));p.put("variantName",vc==null?"":vc.optString("graphicsPathName"));
            boolean same=ac!=null&&vc!=null&&sameConditions(ac,vc)&&ac.optInt("graphicsPath",-1)==0&&vc.optInt("graphicsPath",-1)>=1&&vc.optInt("graphicsPath",-1)<=5;
            boolean complete=active.optBoolean("complete")&&variant.optBoolean("complete")&&am!=null&&vm!=null;
            p.put("sameConditions",same);p.put("usable",same&&complete);
            if(same&&complete){usable++;p.put("active",ablationMetrics(am));p.put("variant",ablationMetrics(vm));p.put("effect",ablationEffect(am,vm));}
            else p.put("reason",same?"incomplete_run":"configuration_mismatch");
            pairs.put(p);
        }
        JSONObject out=new JSONObject();out.put("schema","x-gaming-lab-ablation-v1");out.put("usablePairs",usable);out.put("pairs",pairs);out.put("summaryEs",usable+" de "+pairs.length()+" pares comparables completados.");report.put("ablation",out);
    }
    private static boolean sameConditions(JSONObject a,JSONObject b){
        return a.optInt("scene")==b.optInt("scene")&&a.optInt("load")==b.optInt("load")&&a.optInt("targetHz")==b.optInt("targetHz")
            &&Math.abs(a.optDouble("resolutionScale")-b.optDouble("resolutionScale"))<1e-12&&a.optBoolean("audio")==b.optBoolean("audio")
            &&a.optBoolean("interactive")==b.optBoolean("interactive")&&a.optLong("seed")==b.optLong("seed")&&a.optBoolean("coordinated")==b.optBoolean("coordinated");
    }
    private static JSONObject ablationMetrics(JSONObject m)throws Exception{
        JSONObject o=new JSONObject();String[] keys={"presentationFps","swapFps","frameMsP50","frameMsP95","frameMsP99","onePercentLow","cpuMs","qssdMs","virtualGpuMs","geometryMs","submitMs","swapMs","gpuMs","shadowGpuMs","sceneGpuMs","screenGpuMs","uploadBytes","pwrObjectsPct","pwrVerticesPct","pwrFragmentsEstimatePct","pwrInstanceBytesPct","reusedObjects","changedObjects","shadowPassesAvoided","scenePassesAvoided"};
        for(String k:keys)if(m.has(k)&&!m.isNull(k))o.put(k,m.get(k));else o.put(k,JSONObject.NULL);return o;
    }
    private static JSONObject ablationEffect(JSONObject active,JSONObject off)throws Exception{
        JSONObject o=new JSONObject();
        o.put("presentedFpsActiveVsOffPct",ratioGain(active.optDouble("presentationFps",Double.NaN),off.optDouble("presentationFps",Double.NaN)));
        o.put("frameP95ReductionPct",timeReduction(active.optDouble("frameMsP95",Double.NaN),off.optDouble("frameMsP95",Double.NaN)));
        o.put("physicalGpuReductionPct",timeReduction(active.optDouble("gpuMs",Double.NaN),off.optDouble("gpuMs",Double.NaN)));
        o.put("shadowGpuReductionPct",timeReduction(active.optDouble("shadowGpuMs",Double.NaN),off.optDouble("shadowGpuMs",Double.NaN)));
        o.put("sceneGpuReductionPct",timeReduction(active.optDouble("sceneGpuMs",Double.NaN),off.optDouble("sceneGpuMs",Double.NaN)));
        return o;
    }
    private static Object ratioGain(double active,double off){return Double.isFinite(active)&&Double.isFinite(off)&&off>0?100.0*(active/off-1.0):JSONObject.NULL;}
    private static Object timeReduction(double active,double off){return Double.isFinite(active)&&Double.isFinite(off)&&off>0?100.0*(off-active)/off:JSONObject.NULL;}
    private static int[] array(LinkedHashSet<Integer> set){int[] a=new int[set.size()];int i=0;for(int x:set)a[i++]=x;return a;}
}
