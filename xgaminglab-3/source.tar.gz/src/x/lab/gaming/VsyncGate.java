package x.lab.gaming;

/**
 * Thread-confined target-cadence gate for display callbacks. This schedules work;
 * it does not measure completed or presented frames. Call on EVERY callback,
 * before testing whether the render worker is busy. An admitted period is then
 * consumed even if that worker cannot accept the request; no catch-up is queued.
 *
 * The first valid callback is an immediate baseline. Further admissions follow
 * integer period indices anchored to it, avoiding rounded-period drift. A target
 * above callback frequency admits every callback. A non-divisor target is
 * quantized to available callbacks (60 on 90 Hz alternates 11.11/22.22 ms gaps).
 */
public final class VsyncGate {
    private static final long NS_PER_SECOND = 1_000_000_000L;
    private final int targetHz;
    private final long toleranceNs;
    private long anchorNs, lastTimestampNs, lastPeriod;
    private long invalidTimestamps, duplicateTimestamps, reversedTimestamps;

    public VsyncGate(int targetHz) {
        if (targetHz < 1 || targetHz > NS_PER_SECOND)
            throw new IllegalArgumentException("targetHz must be positive and at most 1000000000");
        this.targetHz = targetHz;
        // 1 us at normal display rates; never a material fraction of a tiny period.
        toleranceNs = Math.min(1_000L, (NS_PER_SECOND / targetHz) / 4L);
    }

    /**
     * Returns whether this display callback consumes a target period. Allocates
     * nothing. Nonpositive and reversed timestamps reject this callback and
     * reset the scheduling phase; a duplicate rejects without shifting phase.
     * The next valid timestamp after a phase reset establishes a new baseline.
     * Such a clock discontinuity must also cancel/reset any measured run; this
     * scheduling helper cannot repair a separate statistics timebase.
     */
    public boolean shouldRender(long vsyncNs) {
        if (vsyncNs <= 0) {
            invalidTimestamps++;clearPhase();return false;
        }
        if (lastTimestampNs != 0 && vsyncNs <= lastTimestampNs) {
            if (vsyncNs == lastTimestampNs) duplicateTimestamps++;
            else { reversedTimestamps++;clearPhase(); }
            return false;
        }
        lastTimestampNs = vsyncNs;
        if (anchorNs == 0) {
            anchorNs = vsyncNs;lastPeriod = 0;return true;
        }
        long elapsed = vsyncNs - anchorNs;
        elapsed = elapsed > Long.MAX_VALUE - toleranceNs ? Long.MAX_VALUE : elapsed + toleranceNs;
        // floor(elapsed * Hz / 1e9), split so the product cannot overflow long.
        long period = (elapsed / NS_PER_SECOND) * targetHz
                + ((elapsed % NS_PER_SECOND) * targetHz) / NS_PER_SECOND;
        if (period <= lastPeriod) return false;
        lastPeriod = period;
        return true;
    }

    /** Starts a new case, including fresh diagnostics. */
    public void reset() {
        clearPhase();invalidTimestamps=duplicateTimestamps=reversedTimestamps=0;
    }

    private void clearPhase() { anchorNs=lastTimestampNs=lastPeriod=0; }
    public long invalidTimestampCount() { return invalidTimestamps; }
    public long duplicateTimestampCount() { return duplicateTimestamps; }
    public long reversedTimestampCount() { return reversedTimestamps; }
}
