package x.lab.gaming;

import android.view.Surface;
import java.nio.ByteBuffer;

final class NativeBridge {
    static { System.loadLibrary("xgaminglab"); }
    private NativeBridge() {}
    static native long create(Surface surface);
    static native void resize(long handle, int width, int height);
    static native void configure(long handle, int scene, int load, boolean coordinated, float resolution, int targetHz, int graphicsPath);
    static native void frame(long handle, long frameTimeNs, long expectedPresentNs,
                             long inputNs, float inputX, float inputY, boolean pressed, ByteBuffer metrics);
    static native String capabilities(long handle);
    static native void close(long handle);
    static native String probe(int kind, int load, long seed, String directory);
    static native String probeCapabilities();
}
