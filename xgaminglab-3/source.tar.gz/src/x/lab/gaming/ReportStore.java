package x.lab.gaming;

import android.content.Context;
import org.json.JSONObject;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

final class ReportStore {
    private final File directory;
    ReportStore(Context c){directory=new File(c.getFilesDir(),"results");if(!directory.exists()&&!directory.mkdirs())throw new IllegalStateException("No se creó el historial");}
    File save(String id,JSONObject report) throws Exception {
        if(!id.matches("[a-zA-Z0-9_-]+"))throw new IllegalArgumentException("Invalid report id");
        File file=new File(directory,id+".json"),temporary=new File(directory,id+".tmp");
        try(FileOutputStream out=new FileOutputStream(temporary)){out.write(report.toString(2).getBytes(StandardCharsets.UTF_8));out.getFD().sync();}
        if(!temporary.renameTo(file))throw new IllegalStateException("No se guardó el resultado");return file;
    }
    File[] list(){File[] files=directory.listFiles((d,n)->n.endsWith(".json"));if(files==null)return new File[0];Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));return files;}
    JSONObject read(File file)throws Exception {
        try(FileInputStream in=new FileInputStream(file);ByteArrayOutputStream out=new ByteArrayOutputStream()){
            byte[] buffer=new byte[8192];int count;while((count=in.read(buffer))!=-1){out.write(buffer,0,count);if(out.size()>12*1024*1024)throw new IllegalStateException("Informe demasiado grande");}
            return new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
        }
    }
}
