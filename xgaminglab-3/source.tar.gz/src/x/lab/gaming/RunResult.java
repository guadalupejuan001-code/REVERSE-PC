package x.lab.gaming;

/** Immutable optional pure-Java wrapper; Android UI may add device/thermal metadata separately. */
public final class RunResult {
    public final String scene, mode, stopReason;
    public final boolean completed;
    public final FrameStats.Snapshot metrics;

    public RunResult(String scene,String mode,boolean completed,String stopReason,
                     FrameStats.Snapshot metrics) {
        if(scene==null||mode==null||metrics==null)throw new IllegalArgumentException("Run identity and metrics required");
        this.scene=scene;this.mode=mode;this.completed=completed;
        this.stopReason=stopReason;this.metrics=metrics;
    }

    public String toJson() {
        StringBuilder b=new StringBuilder(8_000);
        b.append("{\"schema\":\"x-gaming-lab-run-v1\"");
        FrameStats.field(b,"scene",scene);FrameStats.field(b,"mode",mode);
        FrameStats.field(b,"completed",completed);FrameStats.field(b,"stopReason",stopReason);
        return b.append(",\"metrics\":").append(metrics.toJson()).append('}').toString();
    }
}
