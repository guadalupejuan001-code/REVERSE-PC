package x.lab.gaming;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import org.json.JSONObject;

/** One bounded native batch at a time; cancellation is observed between batches. */
final class ComponentRunner {
    static final String[] NAMES={"CPU · XI / Ether","Núcleo cuántico","GPU Virtual","QSSD · estados y disco","Cadena completa"};
    interface Listener {
        void onStart(int kind,int index,int count);
        void onResult(JSONObject result);
        void onFinish(boolean interrupted,String error);
    }
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Listener listener;
    private final File directory;
    private final int[] kinds;
    private final int load;
    private final long stressMs;
    private volatile boolean cancelled;
    ComponentRunner(Context context,int[] kinds,int load,long stressMs,Listener listener) {
        this.listener=listener;this.kinds=kinds.clone();this.load=load;this.stressMs=stressMs;
        directory=new File(new File(context.getFilesDir(),"prototype-checkpoints"),"run-"+System.nanoTime());
    }
    void start() {
        new Thread(()->{
            String error=null;
            try {
                if(!directory.exists()&&!directory.mkdirs())throw new IllegalStateException("No se creó el directorio de pruebas");
                for(int i=0;i<kinds.length&&!cancelled;i++){
                    final int kind=kinds[i],index=i;
                    main.post(()->listener.onStart(kind,index,kinds.length));
                    long begin=System.nanoTime(),batches=0,checks=0,failures=0,work=0,nativeNs=0;
                    double worstError=0;JSONObject last=null;
                    do {
                        if(cancelled)break;
                        // Alternate the input seed; a stale output cannot satisfy all batch oracles.
                        last=new JSONObject(NativeBridge.probe(kind,load,37+batches,directory.getAbsolutePath()));
                        batches++;checks+=last.optLong("checks");failures+=last.optLong("failures");
                        if(!last.optBoolean("passed"))failures=Math.max(1,failures);
                        work+=last.optLong("workItems");nativeNs+=last.optLong("elapsedNs");
                        worstError=Math.max(worstError,last.optDouble("maxError",0));
                    }while(!cancelled&&failures==0&&stressMs>0&&(System.nanoTime()-begin)/1_000_000L<stressMs);
                    if(last!=null){
                        JSONObject result=new JSONObject();result.put("kind",kind);result.put("name",NAMES[kind]);result.put("load",load);
                        result.put("passed",failures==0);result.put("complete",!cancelled);
                        result.put("batches",batches);result.put("checks",checks);result.put("failures",failures);
                        result.put("workItems",work);result.put("workUnit",last.optString("unit","see lastBatch"));
                        result.put("elapsedNs",System.nanoTime()-begin);result.put("nativeElapsedNs",nativeNs);result.put("maxError",worstError);
                        result.put("lastBatch",last);result.put("requestedStressMs",stressMs);
                        result.put("scope","All batch totals are retained; detailed evidence is the last batch. Includes native setup and correctness checks; not a hardware clock rate.");
                        final JSONObject ready=result;main.post(()->listener.onResult(ready));
                    }
                }
            }catch(Throwable e){error=e.getClass().getSimpleName()+": "+e.getMessage();}
            final String message=error;main.post(()->listener.onFinish(cancelled||message!=null,message));
        },"XLab-Components").start();
    }
    void stop(){cancelled=true;}
}
