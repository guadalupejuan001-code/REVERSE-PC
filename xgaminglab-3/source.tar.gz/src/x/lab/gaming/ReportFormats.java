package x.lab.gaming;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Locale;

/** Offline exports contain the same recorded values; no inferred physical FPS. */
final class ReportFormats {
    static String csv(JSONObject report){
        StringBuilder b=new StringBuilder();
        if("components".equals(report.optString("type"))){
            b.append("component,load,passed,complete,batches,checks,failures,work_items,work_unit,elapsed_ms,max_error\r\n");
            JSONArray a=report.optJSONArray("results");if(a!=null)for(int i=0;i<a.length();i++){
                JSONObject r=a.optJSONObject(i);if(r==null)continue;
                row(b,r.optString("name"),r.optInt("load"),r.optBoolean("passed"),r.optBoolean("complete"),r.optLong("batches"),r.optLong("checks"),r.optLong("failures"),r.optLong("workItems"),r.optString("workUnit"),r.optDouble("elapsedNs")/1e6,r.optDouble("maxError"));
            }
        }else{
            b.append("scene,load,coordinated,graphics_path,target_hz,width,height,complete,delivered_fps,presented_fps,presentation_coverage,p95_ms,p99_ms,one_percent_low_fps,cpu_ms,qssd_ms,gpu_virtual_ms,geometry_ms,submit_ms,swap_ms,gpu_ms,shadow_gpu_ms,scene_gpu_ms,screen_gpu_ms,gpu_coverage,pwr_objects_pct,pwr_vertices_pct,pwr_fragments_estimate_pct,pwr_instance_bytes_pct,reused_objects,changed_objects,shadow_passes_avoided,scene_passes_avoided,objects,draw_calls,intervals,elapsed_ns\r\n");
            JSONArray a=report.optJSONArray("results");if(a!=null)for(int i=0;i<a.length();i++){
                JSONObject r=a.optJSONObject(i);if(r==null)continue;JSONObject c=r.optJSONObject("configuration"),m=r.optJSONObject("metrics");if(c==null||m==null)continue;
                row(b,c.optString("name"),c.optInt("load"),c.optBoolean("coordinated"),c.optInt("graphicsPath"),c.optInt("targetHz"),m.optInt("renderWidth"),m.optInt("renderHeight"),r.optBoolean("complete"),m.optDouble("swapFps"),m.optDouble("presentationFps"),m.optDouble("presentationCoverage"),m.optDouble("frameMsP95"),m.optDouble("frameMsP99"),m.optDouble("onePercentLow"),m.optDouble("cpuMs"),m.optDouble("qssdMs"),m.optDouble("virtualGpuMs"),m.optDouble("geometryMs"),m.optDouble("submitMs"),m.optDouble("swapMs"),m.optDouble("gpuMs"),m.optDouble("shadowGpuMs"),m.optDouble("sceneGpuMs"),m.optDouble("screenGpuMs"),m.optDouble("gpuCoverage"),m.optDouble("pwrObjectsPct"),m.optDouble("pwrVerticesPct"),m.optDouble("pwrFragmentsEstimatePct"),m.optDouble("pwrInstanceBytesPct"),m.optLong("reusedObjects"),m.optLong("changedObjects"),m.optLong("shadowPassesAvoided"),m.optLong("scenePassesAvoided"),m.optLong("objects"),m.optLong("drawCalls"),m.optLong("intervalCount"),m.optLong("elapsedNs"));
            }
        }
        return b.toString();
    }
    private static void row(StringBuilder b,Object...values){
        for(int i=0;i<values.length;i++){if(i>0)b.append(',');Object v=values[i];if(v instanceof Double&&!Double.isFinite((Double)v))continue;
            String s=String.valueOf(v);if(v instanceof String){if(s.startsWith("=")||s.startsWith("+")||s.startsWith("-")||s.startsWith("@"))s="'"+s;b.append('"').append(s.replace("\"","\"\"")).append('"');}else b.append(s);}
        b.append("\r\n");
    }
    static String html(JSONObject report){
        StringBuilder b=new StringBuilder("<!doctype html><html lang=\"es\"><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>X Gaming Lab · Informe</title><style>body{margin:0;background:#080e18;color:#f3f6fc;font:16px system-ui;line-height:1.5}main{max-width:1100px;margin:auto;padding:28px}h1{color:#b7f752}small,p{color:#9daec5}section{padding:20px;margin:18px 0;background:#121d2c;border:1px solid #28384d;border-radius:16px}table{width:100%;border-collapse:collapse;font-size:14px}th,td{padding:10px;text-align:left;border-bottom:1px solid #28384d}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}a{color:#b8a5ff}.scroll{overflow:auto}</style><main><h1>X Gaming Lab · PC</h1>");
        b.append("<h2>").append(esc(report.optString("label"))).append("</h2><p>").append(esc(report.optString("startedUtc"))).append(" · ").append(report.optBoolean("complete")?"Completado":"Parcial").append("</p>");
        JSONObject device=report.optJSONObject("deviceAtStart");if(device!=null)b.append("<p>").append(esc(device.optString("manufacturer")+" "+device.optString("model"))).append(" · Android ").append(esc(device.optString("android"))).append("</p>");
        b.append("<p>Versión ").append(esc(report.optString("appVersion"))).append(" · Fuente ").append(esc(report.optString("sourceId"))).append("</p>");
        JSONArray a=report.optJSONArray("results");
        if("components".equals(report.optString("type"))){
            if(a!=null)for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);if(r==null)continue;b.append("<section><h2>").append(esc(r.optString("name"))).append(" · ").append(r.optBoolean("passed")?"Comprobaciones aprobadas":"Revisar").append("</h2><p>").append(r.optLong("checks")).append(" comprobaciones · ").append(r.optLong("batches")).append(" lotes · ").append(fmt(r.optDouble("elapsedNs")/1e6)).append(" ms</p><details><summary>Evidencia completa</summary><pre>").append(esc(pretty(r))).append("</pre></details></section>");}
        }else{
            b.append("<p>FPS entregados y presentados tienen alcances distintos. Los datos ausentes se muestran como —. Son escenas propias del laboratorio.</p><section class=\"scroll\"><table><tr><th>Escena</th><th>Carga / modo</th><th>Ruta gráfica</th><th>FPS entregados</th><th>FPS presentados</th><th>p95 / p99 ms</th><th>1% lento</th><th>GPU física ms</th><th>PWR obj/vtx/bytes</th><th>Objetos</th></tr>");
            if(a!=null)for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);if(r==null)continue;JSONObject c=r.optJSONObject("configuration"),m=r.optJSONObject("metrics");if(c==null||m==null)continue;
                b.append("<tr><td>").append(esc(c.optString("name"))).append("</td><td>").append(esc(c.optString("loadName"))).append(" / ").append(c.optBoolean("coordinated")?"Coordinada":"Libre").append("</td><td>").append(esc(c.optString("graphicsPathName"))).append("</td><td>").append(fmt(m.optDouble("swapFps"))).append("</td><td>").append(fmt(m.optDouble("presentationFps"))).append("</td><td>").append(fmt(m.optDouble("frameMsP95"))).append(" / ").append(fmt(m.optDouble("frameMsP99"))).append("</td><td>").append(fmt(m.optDouble("onePercentLow"))).append("</td><td>").append(fmt(m.optDouble("gpuMs"))).append("</td><td>").append(fmt(m.optDouble("pwrObjectsPct"))).append(" / ").append(fmt(m.optDouble("pwrVerticesPct"))).append(" / ").append(fmt(m.optDouble("pwrInstanceBytesPct"))).append("</td><td>").append(m.optLong("objects")).append("</td></tr>");
            }
            b.append("</table></section>");
            if(report.has("comparison"))b.append("<section><h2>Comparación pareada</h2><pre>").append(esc(pretty(report.optJSONObject("comparison")))).append("</pre></section>");
            if(report.has("ablation"))b.append("<section><h2>Ablaciones GPU Virtual</h2><pre>").append(esc(pretty(report.optJSONObject("ablation")))).append("</pre></section>");
        }
        b.append("<details><summary>Informe completo · JSON</summary><pre>").append(esc(pretty(report))).append("</pre></details></main></html>");return b.toString();
    }
    private static String pretty(JSONObject j){try{return j.toString(2);}catch(Exception e){return String.valueOf(j);}}
    private static String fmt(double d){return Double.isFinite(d)?String.format(Locale.ROOT,"%.2f",d):"—";}
    private static String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
}
