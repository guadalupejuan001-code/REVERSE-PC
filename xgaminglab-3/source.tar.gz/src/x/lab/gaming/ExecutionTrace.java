package x.lab.gaming;

import org.json.JSONObject;

/** Evidence separate from time-window statistics; quantum counters start at configure. */
final class ExecutionTrace {
    long frames,instancedDraws,batchedDraws,referenceDraws;
    long quantumGates,quantumCircuits;
    int cameraInstances,shadowInstances,quantumQubits,graphicsPath;
    double quantumSignal;
    void record(double[] m) {
        frames++;cameraInstances=(int)m[44];shadowInstances=(int)m[45];
        instancedDraws+=(long)m[46];batchedDraws+=(long)m[47];referenceDraws+=(long)m[48];
        graphicsPath=(int)m[49];quantumGates=(long)m[50];quantumCircuits=(long)m[51];
        quantumQubits=(int)m[52];quantumSignal=m[53];
    }
    JSONObject json() {
        JSONObject j=new JSONObject();
        try {
            j.put("measuredFrames",frames);j.put("cameraInstancesLatest",cameraInstances);
            j.put("shadowInstancesLatest",shadowInstances);
            j.put("instancedDraws",instancedDraws);j.put("batchedDraws",batchedDraws);j.put("referenceDraws",referenceDraws);
            j.put("requestedGraphicsPath",graphicsPath);j.put("quantumGatesSinceConfigure",quantumGates);
            j.put("quantumCircuitsSinceConfigure",quantumCircuits);j.put("quantumQubits",quantumQubits);
            j.put("quantumSignal",Double.isFinite(quantumSignal)?quantumSignal:JSONObject.NULL);
            j.put("scope","Draw counters cover measured frames. Quantum counters include the circuit executed during configuration, outside frame warmup/measurement.");
        } catch(Exception ignored) {}
        return j;
    }
}
