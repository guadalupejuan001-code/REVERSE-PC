package x.lab.gaming;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Optional synthetic scene tone. Audio output latency is deliberately not inferred from this clock. */
final class SceneAudio implements AutoCloseable {
    private volatile boolean running;
    private volatile float frequency=220,gain=0;
    private Thread worker;
    private volatile String error="";
    void set(float hz,float volume){frequency=Math.max(30,Math.min(2000,hz));gain=Math.max(0,Math.min(.1f,volume));}
    String error(){return error;}
    void start(){if(running)return;running=true;worker=new Thread(this::loop,"XLab-Audio");worker.start();}
    private void loop(){
        AudioTrack track=null;
        try {
            final int rate=48000;int minimum=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
            if(minimum<=0)throw new IllegalStateException("Audio buffer unavailable");
            track=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(Math.max(minimum,3840)).setTransferMode(AudioTrack.MODE_STREAM).build();
            short[] samples=new short[480];double phase=0,currentFrequency=220,currentGain=0;track.play();
            while(running){
                double nextFrequency=frequency,nextGain=gain;
                for(int i=0;i<samples.length;i++){currentFrequency+=(nextFrequency-currentFrequency)*.002;currentGain+=(nextGain-currentGain)*.002;phase+=2*Math.PI*currentFrequency/rate;if(phase>Math.PI*2)phase-=Math.PI*2;samples[i]=(short)(Math.sin(phase)*currentGain*32767);}
                int written=0;while(running&&written<samples.length){int n=track.write(samples,written,samples.length-written,AudioTrack.WRITE_BLOCKING);if(n<0)throw new IllegalStateException("Audio write "+n);written+=n;}
            }
        }catch(Throwable e){error=e.toString();}finally{if(track!=null){try{track.stop();}catch(Exception ignored){}track.release();}}
    }
    public void close(){running=false;if(worker!=null){try{worker.join(500);}catch(InterruptedException e){Thread.currentThread().interrupt();}worker=null;}}
}
