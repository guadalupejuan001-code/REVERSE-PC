package x.lab.gaming;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Choreographer;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/** One EGL owner, one pending render request, one common monotonic timebase. */
final class FrameLoop implements SurfaceHolder.Callback {
    interface Listener {
        void onCase(RunConfig config,int index,int total);
        void onTelemetry(FrameStats.Snapshot stats,RunConfig config,long warmupLeftMs,long remainingMs,
                         int renderWidth,int renderHeight,int thermal,float refreshHz,boolean presentationSupported,JSONObject execution);
        void onResult(RunConfig config,FrameStats.Snapshot stats,String capabilities,boolean complete,
                      String reason,long skippedVsync,String audioError,JSONObject execution,JSONObject deviceAtCaseStart);
        void onFinished(boolean interrupted);
        void onError(String message);
    }
    private static final long WARMUP_NS=2_000_000_000L;
    private final Activity activity;
    private final SurfaceView surfaceView;
    private final RunConfig[] plan;
    private final Listener listener;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final HandlerThread thread=new HandlerThread("XLab-Render");
    private final Handler worker;
    private final AtomicBoolean pending=new AtomicBoolean();
    private final ByteBuffer metricsBuffer=ByteBuffer.allocateDirect(FrameStats.METRIC_COUNT*8).order(ByteOrder.nativeOrder());
    private final double[] values=new double[64];
    private final SceneAudio audio=new SceneAudio();
    private final Choreographer choreographer=Choreographer.getInstance();
    private final Choreographer.FrameCallback legacyCallback=this::onVsync;
    private Object modernCallback;
    private VsyncGate vsyncGate;
    private volatile boolean running,closing,stopRequested;
    private volatile RunConfig current;
    private volatile InputEvent input=InputEvent.NONE;
    private volatile long requestedFrameNs,requestedPresentNs,skippedVsync;
    private long handle,caseStartNs,lastUiNs,liveSnapshotNs;
    private int index=-1,width,height;
    private boolean measuring,caseReported,finished;
    private FrameStats stats;
    private ExecutionTrace trace;
    private JSONObject caseDevice;
    private int maxThermal=-1;
    private float minRefresh=Float.POSITIVE_INFINITY,maxRefresh=0;
    private String capabilities="{}";
    private final Runnable renderTask=this::render;

    FrameLoop(Activity activity,SurfaceView view,RunConfig[] plan,Listener listener) {
        this.activity=activity;this.surfaceView=view;this.plan=plan.clone();this.listener=listener;
        thread.start();worker=new Handler(thread.getLooper());
        if(Build.VERSION.SDK_INT>=33)modernCallback=Api33.callback(this);
        view.getHolder().addCallback(this);
        view.setOnTouchListener((v,event)->{
            RunConfig c=current;if(c==null||!c.interactive)return true;
            int action=event.getActionMasked();boolean pressed=action!=MotionEvent.ACTION_UP&&action!=MotionEvent.ACTION_CANCEL;
            long delivery=System.nanoTime();long age=Math.max(0,SystemClock.uptimeMillis()-event.getEventTime());
            long timestamp=delivery-Math.min(age,60_000L)*1_000_000L;
            float x=2*event.getX()/Math.max(1,v.getWidth())-1;
            float y=1-2*event.getY()/Math.max(1,v.getHeight());
            input=new InputEvent(timestamp,x,y,pressed);return true;
        });
    }
    static final class InputEvent {
        static final InputEvent NONE=new InputEvent(0,0,0,false);
        final long timeNs;final float x,y;final boolean pressed;
        InputEvent(long t,float x,float y,boolean p){timeNs=t;this.x=x;this.y=y;pressed=p;}
    }
    @Override public void surfaceCreated(SurfaceHolder holder){
        if(closing)return;Surface surface=holder.getSurface();
        worker.post(()->{
            if(closing)return;
            try{
                handle=NativeBridge.create(surface);if(handle==0)throw new IllegalStateException("No se creó la superficie de dibujo");
                running=true;startNextCase();
            }catch(Throwable e){fail(e);}
        });
    }
    @Override public void surfaceChanged(SurfaceHolder holder,int format,int w,int h){
        final boolean changed=width!=0&&(width!=w||height!=h);width=w;height=h;
        worker.post(()->{
            if(handle==0||closing)return;
            try{
                if(changed){finishSession(true,"surface_changed");return;}
                NativeBridge.resize(handle,w,h);
            }catch(Throwable e){fail(e);}
        });
    }
    @Override public void surfaceDestroyed(SurfaceHolder holder){close(true,true);}
    void stop(){stopRequested=true;worker.post(()->{if(running)finishSession(true,"stopped_by_user");});}
    boolean isRunning(){return running&&!closing;}

    private void startNextCase(){
        if(!running||closing)return;
        if(stopRequested){finishSession(true,"stopped_by_user");return;}
        if(++index>=plan.length){finishSession(false,"completed");return;}
        current=plan[index];input=InputEvent.NONE;skippedVsync=0;caseReported=false;measuring=false;
        stats=new FrameStats(current.targetHz,(int)Math.min(1_000_000L,Math.max(FrameStats.DEFAULT_CAPACITY,current.durationMs/1000L*Math.max(current.targetHz,240)*2L+1024)));trace=new ExecutionTrace();maxThermal=-1;minRefresh=Float.POSITIVE_INFINITY;maxRefresh=0;caseDevice=DeviceInfo.capture(activity);
        NativeBridge.configure(handle,current.scene,current.load,current.coordinated,current.resolution,current.targetHz,current.graphicsPath);
        capabilities=NativeBridge.capabilities(handle);
        caseStartNs=System.nanoTime();lastUiNs=0;liveSnapshotNs=0;
        if(current.audio)audio.start();else audio.set(220,0);
        final int number=index;final RunConfig selected=current;
        ui.post(()->{
            if(closing)return;
            requestDisplayRate(selected.targetHz);
            listener.onCase(selected,number,plan.length);
            removeClock();vsyncGate=new VsyncGate(selected.targetHz);
            if(selected.coordinated)postClock();else requestFrame(System.nanoTime(),0);
        });
    }
    private void requestDisplayRate(int hz){
        if(Build.VERSION.SDK_INT>=30){try{Surface s=surfaceView.getHolder().getSurface();if(s.isValid())s.setFrameRate(hz,Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);}catch(RuntimeException ignored){}}
    }
    private void onVsync(long timeNs){
        if(!running||closing||current==null||!current.coordinated)return;
        if(vsyncGate==null||vsyncGate.shouldRender(timeNs))requestFrame(timeNs,0);
        choreographer.postFrameCallback(legacyCallback);
    }
    private void modernVsync(long timeNs,long expectedNs){
        if(!running||closing||current==null||!current.coordinated)return;
        if(vsyncGate==null||vsyncGate.shouldRender(timeNs))requestFrame(timeNs,expectedNs);
        Api33.post(choreographer,modernCallback);
    }
    private void postClock(){
        if(!running||closing)return;
        if(Build.VERSION.SDK_INT>=33)Api33.post(choreographer,modernCallback);else choreographer.postFrameCallback(legacyCallback);
    }
    private void removeClock(){
        choreographer.removeFrameCallback(legacyCallback);
        if(Build.VERSION.SDK_INT>=33&&modernCallback!=null)Api33.remove(choreographer,modernCallback);
    }
    private void requestFrame(long frameNs,long expectedNs){
        if(!running||closing)return;
        if(!pending.compareAndSet(false,true)){skippedVsync++;return;}
        requestedFrameNs=frameNs;requestedPresentNs=expectedNs;worker.post(renderTask);
    }
    private void render(){
        try {
            if(!running||closing||handle==0)return;
            if(stopRequested){finishSession(true,"stopped_by_user");return;}
            InputEvent e=input;
            NativeBridge.frame(handle,requestedFrameNs,requestedPresentNs,e.timeNs,e.x,e.y,e.pressed,metricsBuffer);
            if(closing||!running)return;
            if(stopRequested){finishSession(true,"stopped_by_user");return;}
            for(int i=0;i<FrameStats.METRIC_COUNT;i++)values[i]=metricsBuffer.getDouble(i*8);
            if(values[37]!=1)throw new IllegalStateException("La pantalla rechazó el fotograma; se detuvo esta medición");
            long now=System.nanoTime(),elapsed=now-caseStartNs;
            if(current.audio)audio.set((float)values[42],(float)values[43]);
            if(values[2]>=caseStartNs+WARMUP_NS){
                if(!measuring){measuring=true;stats.reset();}
                if(stats.record(values))trace.record(values);
            }
            if(now-lastUiNs>=500_000_000L){
                lastUiNs=now;
                long snapshotStart=System.nanoTime();
                final FrameStats.Snapshot snapshot=measuring?stats.snapshot():null;
                if(measuring)liveSnapshotNs+=System.nanoTime()-snapshotStart;
                final RunConfig selected=current;
                final long warming=Math.max(0,(WARMUP_NS-elapsed)/1_000_000L);
                final long remaining=Math.max(0,current.durationMs-Math.max(0,elapsed-WARMUP_NS)/1_000_000L);
                final int rw=(int)values[22],rh=(int)values[23];final boolean present=values[29]>0;
                final int thermal=DeviceInfo.thermal(activity);final float refresh=activity.getWindowManager().getDefaultDisplay().getRefreshRate();
                maxThermal=Math.max(maxThermal,thermal);minRefresh=Math.min(minRefresh,refresh);maxRefresh=Math.max(maxRefresh,refresh);
                final JSONObject execution=trace.json();
                ui.post(()->{if(!closing)listener.onTelemetry(snapshot,selected,warming,remaining,rw,rh,thermal,refresh,present,execution);});
                if(thermal>=4){finishSession(true,"thermal_critical");return;}
            }
            if(elapsed>=WARMUP_NS+current.durationMs*1_000_000L){reportCurrent(true,"completed");startNextCase();}
        }catch(Throwable e){fail(e);}finally{
            pending.set(false);
            if(running&&!closing&&current!=null&&!current.coordinated)requestFrame(System.nanoTime(),0);
        }
    }
    private void reportCurrent(boolean complete,String reason){
        if(caseReported||current==null||stats==null)return;
        caseReported=true;
        if(handle!=0){try{capabilities=NativeBridge.capabilities(handle);}catch(Throwable ignored){}}
        final RunConfig selected=current;final FrameStats.Snapshot snapshot=stats.snapshot();
        final String caps=capabilities,audioError=audio.error();final long skipped=skippedVsync;
        final JSONObject execution=trace==null?new JSONObject():trace.json(),device=caseDevice;
        try{execution.put("liveSnapshotCpuNs",liveSnapshotNs);execution.put("instrumentationScope","FPS include measurement/reporting work. liveSnapshotCpuNs measures live percentile snapshot CPU work, not total profiler overhead.");execution.put("environmentSamplingScope","Case including warmup, sampled at the UI reporting cadence; not proof of thermally steady hardware");execution.put("maxThermalStatus",maxThermal);execution.put("minDisplayHz",Float.isFinite(minRefresh)?minRefresh:JSONObject.NULL);execution.put("maxDisplayHz",maxRefresh);}catch(Exception ignored){}
        ui.post(()->listener.onResult(selected,snapshot,caps,complete,reason,skipped,audioError,execution,device));
    }
    private void finishSession(boolean interrupted,String reason){
        if(finished)return;finished=true;running=false;
        reportCurrent(!interrupted,reason);
        ui.post(()->{removeClock();listener.onFinished(interrupted);});
    }
    private void fail(Throwable error){
        running=false;reportCurrent(false,"runtime_error");
        final String message=error.getClass().getSimpleName()+": "+String.valueOf(error.getMessage());
        ui.post(()->{removeClock();listener.onError(message);});
    }
    void close(boolean interrupted){
        close(interrupted,false);
    }
    private void close(boolean interrupted,boolean notifySurfaceCompletion){
        if(closing)return;closing=true;running=false;removeClock();requestDisplayRate(0);
        worker.removeCallbacks(renderTask);
        CountDownLatch done=new CountDownLatch(1);
        worker.post(()->{
            boolean notify=notifySurfaceCompletion&&!finished;
            try{
                if(!finished){finished=true;reportCurrent(false,interrupted?"activity_or_surface_paused":"closed");}
                if(handle!=0){NativeBridge.close(handle);handle=0;}
                audio.close();
            }catch(Throwable ignored){}finally{
                if(notify)ui.post(()->listener.onFinished(true));
                done.countDown();thread.quitSafely();
            }
        });
        try{done.await(1500,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
    }
    @android.annotation.TargetApi(33)
    private static final class Api33 {
        static Object callback(FrameLoop owner){return (Choreographer.VsyncCallback)data->owner.modernVsync(data.getFrameTimeNanos(),data.getPreferredFrameTimeline().getExpectedPresentationTimeNanos());}
        static void post(Choreographer c,Object callback){c.postVsyncCallback((Choreographer.VsyncCallback)callback);}
        static void remove(Choreographer c,Object callback){c.removeVsyncCallback((Choreographer.VsyncCallback)callback);}
    }
}
