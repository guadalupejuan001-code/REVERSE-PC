package x.lab.gaming;

import org.json.JSONException;
import org.json.JSONObject;

final class RunConfig {
    static final String[] LOADS={"Baja","Media","Alta","Masiva","Extrema"};
    static final String[] GRAPHICS={"GPU Virtual + QSSD · todo activo","Reducción GPU Virtual desactivada · baseline","QSSD gráfico desactivado","Reutilización desactivada","Representación compacta desactivada","Visibilidad anticipada desactivada","Referencia por objeto · diagnóstico"};
    static final String[] NAMES = {"Calibración", "MOBA", "Mundo abierto", "Lucha", "Shooter", "Carreras", "Efectos", "Fuera de cámara"};
    static final String[] DETAILS = {
        "Escena ligera para conocer el ritmo base del dispositivo.",
        "Unidades, carriles, proyectiles y combates simultáneos.",
        "Recorrido por sectores, vegetación y preparación de zonas.",
        "Dos combatientes, contacto, movimientos y efectos rápidos.",
        "Objetivos, proyectiles y cambios continuos de cámara.",
        "Velocidad, tráfico y aparición de nuevos tramos.",
        "Partículas, transparencias, iluminación y sombras.",
        "Un molino conserva su tiempo antes de entrar en la vista."
    };
    final int scene,load,targetHz,graphicsPath,campaignIndex,block,position,pairIndex;
    final boolean coordinated,audio,interactive;
    final float resolution;
    final long durationMs;
    RunConfig(int scene,int load,int targetHz,boolean coordinated,float resolution,boolean audio,boolean interactive,long durationMs) {
        this(scene,load,targetHz,coordinated,resolution,audio,interactive,durationMs,0,-1,-1,-1,-1);
    }
    RunConfig(int scene,int load,int targetHz,boolean coordinated,float resolution,boolean audio,boolean interactive,long durationMs,int graphicsPath,int campaignIndex,int block,int position,int pairIndex) {
        this.scene=scene;this.load=load;this.targetHz=targetHz;this.coordinated=coordinated;
        this.resolution=resolution;this.audio=audio;this.interactive=interactive;this.durationMs=durationMs;
        this.graphicsPath=graphicsPath;this.campaignIndex=campaignIndex;this.block=block;this.position=position;this.pairIndex=pairIndex;
    }
    String name(){return NAMES[scene];}
    String mode(){return coordinated?"Coordinada":"Libre";}
    JSONObject json() throws JSONException {
        JSONObject j=new JSONObject();j.put("scene",scene);j.put("name",name());j.put("load",load);
        j.put("coordinated",coordinated);j.put("targetHz",targetHz);j.put("resolutionScale",resolution);
        j.put("audio",audio);j.put("interactive",interactive);j.put("requestedMeasurementMs",durationMs);
        j.put("warmupMs",2000);j.put("seed",37);j.put("graphicsPath",graphicsPath);j.put("graphicsPathName",GRAPHICS[graphicsPath]);j.put("loadName",LOADS[load]);j.put("campaignIndex",campaignIndex);j.put("block",block);j.put("position",position);j.put("pairIndex",pairIndex);return j;
    }
}
