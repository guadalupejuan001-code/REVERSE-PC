package x.lab.gaming;

import java.util.ArrayList;
import java.util.List;

/** Bounded explanation rules over observed means; never a causal diagnosis. */
public final class BottleneckAnalysis {
    private BottleneckAnalysis() {}
    public static final String LIMITATION = "Hipótesis heurística basada en medias y cobertura. CPU y GPU pueden solaparse; la espera de swap mezcla pacing, cola y trabajo pendiente. Una traza o una variación controlada debe confirmar la causa. GPU Virtual se ejecuta en software sobre el procesador anfitrión; estos datos no acreditan ventaja cuántica.";

    public static Result inspect(ComparisonAnalysis.Measurement m,ComparisonAnalysis.Environment environment,
                                 boolean coordinated) {
        ComparisonAnalysis.Environment env=environment==null?ComparisonAnalysis.Environment.unknown():environment;
        List<String> warnings=new ArrayList<>();
        if(env.thermalMax>=3)warnings.add("severe_thermal_status_reported");
        if(env.thermalStart<0||env.thermalMax<0)warnings.add("thermal_context_unavailable");
        if(env.powerSaveKnown&&env.powerSave)warnings.add("power_save_active");
        if(!ComparisonAnalysis.validCadence(m)||m.targetHz<1)
            return result("insufficient_data","Datos insuficientes","Faltan intervalos válidos de una ventana medida.",
                    Double.NaN,Double.NaN,Double.NaN,Double.NaN,warnings);
        double frame=m.meanFrameMs(),budget=1000.0/m.targetHz,fps=m.swapFps();
        boolean gpuKnown=ComparisonAnalysis.nonnegative(m.gpuMs)&&Double.isFinite(m.gpuCoverage)&&m.gpuCoverage>=.8&&m.gpuCoverage<=1;
        if(!gpuKnown)warnings.add("gpu_timer_unavailable_or_below_80_percent_coverage");
        if(!m.quantilesComplete)warnings.add("whole_run_quantiles_unavailable");
        if(m.invalidSamples>0||m.failedSwapCount>0)warnings.add("native_sample_failures_present");
        boolean displayKnown=ComparisonAnalysis.positive(env.minDisplayHz)&&ComparisonAnalysis.positive(env.maxDisplayHz)
                &&env.maxDisplayHz>=env.minDisplayHz;
        if(!displayKnown)warnings.add("display_context_unavailable");
        else if(env.maxDisplayHz-env.minDisplayHz>.5)warnings.add("display_changed_within_run");

        if(m.quantilesComplete&&ComparisonAnalysis.nonnegative(m.frameMsP99)
                &&fps>=.95*m.targetHz&&m.frameMsP99<=1.10*budget) {
            return result("target_completion_cadence_observed","Cadencia de entrega cercana al objetivo",
                    "La tasa de finalización y el p99 están próximos al presupuesto solicitado. Esto no prueba que todos los fotogramas se hayan presentado ni establece margen de GPU.",
                    frame,budget,Double.NaN,m.gpuCoverage,warnings);
        }
        if(displayKnown&&env.maxDisplayHz<m.targetHz-.5&&Math.abs(fps-env.maxDisplayHz)<=.05*env.maxDisplayHz) {
            return result("display_or_pacing_candidate","Revisar el límite de pantalla y pacing",
                    "La frecuencia observada de pantalla es menor que el objetivo y la entrega está próxima a ella. La sincronización puede limitar el ritmo; no se atribuye automáticamente el coste a CPU o GPU.",
                    frame,budget,Double.NaN,m.gpuCoverage,warnings);
        }
        double[] values={m.cpuMs,m.qssdMs,m.virtualGpuMs,m.geometryMs,m.submitMs,gpuKnown?m.gpuMs:Double.NaN};
        String[] ids={"cpu_logic_candidate","qssd_candidate","virtual_gpu_cpu_candidate","geometry_candidate","driver_submission_candidate","physical_gpu_candidate"};
        String[] names={"CPU/XI","Publicación QSSD","GPU Virtual","Preparación geométrica","Envío al controlador","GPU física"};
        int largest=-1;
        for(int i=0;i<values.length;i++)if(ComparisonAnalysis.nonnegative(values[i])
                &&(largest<0||values[i]>values[largest]))largest=i;
        if(largest>=0&&values[largest]>=.5*frame&&values[largest]>=.5*budget
                &&(!ComparisonAnalysis.nonnegative(m.swapMs)||values[largest]>=m.swapMs)) {
            return result(ids[largest],"Coste relevante: "+names[largest],
                    "La media de esta etapa alcanza al menos la mitad del intervalo medio de entrega y del presupuesto. Es una candidata para investigar; las medias no demuestran una dependencia crítica por fotograma.",
                    frame,budget,values[largest],m.gpuCoverage,warnings);
        }
        if(ComparisonAnalysis.nonnegative(m.swapMs)&&m.swapMs>=.5*frame) {
            return result("swap_wait_candidate","Revisar espera de intercambio",
                    "La llamada de intercambio ocupa al menos la mitad del intervalo medio. Puede reflejar sincronización con pantalla, cola llena o GPU pendiente; no distingue entre esas causas.",
                    frame,budget,m.swapMs,m.gpuCoverage,warnings);
        }
        double cap=displayKnown?(coordinated?Math.min(m.targetHz,env.maxDisplayHz):env.maxDisplayHz):m.targetHz;
        if(ComparisonAnalysis.positive(cap)&&Math.abs(fps-cap)<=.05*cap) {
            return result("pacing_candidate","Revisar pacing y variación entre fotogramas",
                    "La entrega media está próxima a una cadencia esperada, sin una etapa media dominante. Los picos y la presentación requieren inspección separada.",
                    frame,budget,largest<0?Double.NaN:values[largest],m.gpuCoverage,warnings);
        }
        return result("unresolved","Sin una etapa dominante identificable",
                "Las medias disponibles no explican por sí solas el intervalo de entrega. Puede haber espera, picos, planificación o trabajo no cubierto por estas etapas.",
                frame,budget,largest<0?Double.NaN:values[largest],m.gpuCoverage,warnings);
    }

    private static Result result(String candidate,String title,String explanation,double frame,double budget,
                                 double stage,double coverage,List<String> warnings) {
        return new Result(candidate,title,explanation,frame,budget,stage,coverage,warnings.toArray(new String[0]));
    }
    public static final class Result {
        public final String confidence="heuristic";
        public final String candidate,titleEs,explanationEs;
        public final double meanFrameMs,budgetMs,stageMeanMs,gpuCoverage;
        private final String[] warnings;
        private Result(String candidate,String title,String explanation,double frame,double budget,
                       double stage,double coverage,String[] warnings) {
            this.candidate=candidate;titleEs=title;explanationEs=explanation;
            meanFrameMs=frame;budgetMs=budget;stageMeanMs=stage;gpuCoverage=coverage;this.warnings=warnings;
        }
        public String[] warnings(){return warnings.clone();}
        public String toJson() {
            StringBuilder b=new StringBuilder("{\"schema\":\"x-gaming-lab-bottleneck-v2\"");
            FrameStats.field(b,"confidence",confidence);FrameStats.field(b,"candidate",candidate);
            FrameStats.field(b,"titleEs",titleEs);FrameStats.field(b,"explanationEs",explanationEs);
            FrameStats.field(b,"limitation",LIMITATION);FrameStats.field(b,"meanFrameMs",meanFrameMs);
            FrameStats.field(b,"budgetMs",budgetMs);FrameStats.field(b,"stageMeanMs",stageMeanMs);
            FrameStats.field(b,"gpuCoverage",gpuCoverage);ComparisonAnalysis.strings(b,"warnings",warnings);
            return b.append('}').toString();
        }
    }
}
