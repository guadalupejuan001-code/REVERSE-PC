# X Gaming Lab 3.0

X Gaming Lab 3.0 is an Android graphics laboratory for measuring the user's software-computer prototype under controlled gaming workloads. The active pipeline is:

`Ether/XI -> GPU Virtual -> QSSD -> REgraphics -> physical GPU -> presentation`

The goal is not to claim that a virtual component is a second physical GPU. The goal is measurable: reduce the amount of graphics work that reaches the physical GPU while preserving the requested scene, resolution and effects.

## Responsibilities

- **Ether/XI** owns game/world state, time, inputs, transforms and logical changes. The scene quantum diagnostic uses one structured 1,000-qubit GHZ+T circuit at configuration time; the requested width is reported rather than silently reduced.
- **GPU Virtual** owns a `PhysicalWorkPlan`: visibility candidates, exact object revisions, surviving camera/shadow work, compact representation policy and measurable baseline/planned denominators.
- **QSSD** stores immutable graphics-work revisions with the original `StateBus`; a completed revision authorizes reuse only when the renderer's exact dependencies still match.
- **REgraphics** retains GPU buffers, batches equivalent work, performs sparse instance-buffer delta uploads and reuses exact shadow/scene results when their dependencies are unchanged.
- **Physical GPU** still performs the irreducible vertex, fragment, shadow and final-screen work through GLES.

## Physical Work Reduction (PWR)

PWR is reported separately for measurable categories; no unsupported single global percentage is invented.

- objects submitted to camera + shadow passes;
- vertex invocations implied by surviving meshes;
- projected fragment-area estimate (an estimate, not a hardware fragment counter);
- instance representation bytes;
- actual upload bytes are reported independently.

The denominator is the same source scene before GPU Virtual filtering/reuse. Final screen composition is outside those PWR denominators and has its own GPU timer.

## Physical GPU timers

When `GL_EXT_disjoint_timer_query` is available, three asynchronous, non-overlapping timers are recorded:

1. shadow pass;
2. main scene pass;
3. final screen/composition pass.

Their sum is the lab's physical-GPU elapsed time. It excludes `eglSwapBuffers` and the Android compositor. Swap/presentation are measured separately, so a large swap wait is not mislabeled as GPU ALU time.

## Controlled ablations

The lab exposes these matched paths:

0. GPU Virtual + QSSD — all active;
1. GPU Virtual disabled — baseline, while keeping the same REgraphics batching/instancing;
2. QSSD graphics-work memory disabled;
3. temporal reuse disabled;
4. compact representation disabled;
5. visibility criterion disabled;
6. per-object reference path — diagnostic only.

The ablation campaign repeats the all-active case before each disabled feature so the comparison keeps the same scene, seed, trajectory, resolution, load, lighting and effects.

## Compact and delta transport

Ordinary instanced objects use 44 bytes per instance instead of the prior 112-byte prepared matrix/normal payload while preserving transform, scale and RGBA as full floats. Camera-facing billboards keep the exact prepared representation because yaw-only reconstruction would not be equivalent.

Retained instance buffers compare exact object keys. Sparse changed ranges are updated with `glBufferSubData`; heavily scattered or large changes fall back to one full transfer rather than hundreds of tiny updates.

## Temporal reuse

- Shadow maps are retained only when the light projection and exact ordered caster transforms/meshes match.
- The main scene target is retained only when the visual-state hash matches. World-clock and audio-only changes do not invalidate an otherwise identical image; any visible object/camera/light/fog change does.
- A changed object does not automatically invalidate unrelated QSSD history.

## Performance target

120 FPS corresponds to approximately 8.33 ms per frame. The lab does not force that value and does not silently reduce resolution, objects, shadows or effects to claim success. The intended progression is to measure whether the physical stage crosses 30 ms, 16.67 ms, 11.1 ms and eventually approaches 8.33 ms.

Host and emulator checks establish correctness and buildability. Real PWR/FPS conclusions require matched reports from the physical device.
