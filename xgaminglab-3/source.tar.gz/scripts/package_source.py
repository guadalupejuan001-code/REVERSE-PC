#!/usr/bin/env python3
"""Package the frozen 3.0.0 source tree and verify every archive payload.

Run after build_apk.py and final QA have finished. The APK is delivered separately;
its verified hash and sourceId are recorded in SOURCE_MANIFEST.json inside the ZIP.
Only Python's standard library is required. No build or source files are changed.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parents[1]
VERSION = "3.0.0"
ARCHIVE_ROOT = "X-Gaming-Lab-" + VERSION
MANIFEST_PATH = "SOURCE_MANIFEST.json"
BUILD_METADATA = "evidence/apk-validation.json"
INCLUDE_DIRS = (
    "src", "native", "res", "assets", "vendor", "tests", "scripts", "docs",
    "evidence", "signing",
)
ROOT_FILES = ("README.md", "AndroidManifest.xml")
EXCLUDED_DIRS = {"build", "dist", "__pycache__"}
# Retain machine-readable results, reports and useful text summaries. The Android
# v2 proof bundle also keeps its validator inputs; large native-probe images and
# raw .log files remain excluded.
EVIDENCE_SUFFIXES = {".json", ".jsonl", ".md", ".csv", ".html"}
ANDROID_EVIDENCE_SUFFIXES = {".json", ".jsonl", ".py", ".png", ".xml", ".txt"}
EVIDENCE_TEXT_SUMMARIES = {
    "evidence/apk-signature.txt",
    "evidence/apk-package.txt",
    "evidence/campaign-analysis-host.txt",
}
ZIP_TIME = (1980, 1, 1, 0, 0, 0)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def file_sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def include_file(relative):
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return False
    if relative.suffix.lower() == ".pyc":
        return False
    if relative.parts[0] == "evidence":
        if relative.parts[:2] == ("evidence", "android-v2"):
            return relative.suffix.lower() in ANDROID_EVIDENCE_SUFFIXES
        return (relative.suffix.lower() in EVIDENCE_SUFFIXES
                or relative.as_posix() in EVIDENCE_TEXT_SUMMARIES)
    return True


def collect_payload():
    """Read each included file once; hashing and ZIP writing use these same bytes."""
    paths = []
    for name in ROOT_FILES:
        path = ROOT / name
        require(path.is_file() and not path.is_symlink(), "Missing regular file: " + name)
        paths.append(path)
    for name in INCLUDE_DIRS:
        directory = ROOT / name
        require(directory.is_dir() and not directory.is_symlink(), "Missing directory: " + name)
        for current, dirs, files in os.walk(directory, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in EXCLUDED_DIRS)
            for entry in dirs:
                require(not (Path(current) / entry).is_symlink(),
                        "Symlink directory is not supported: " + str(Path(current) / entry))
            for entry in sorted(files):
                path = Path(current) / entry
                relative = path.relative_to(ROOT)
                if include_file(relative):
                    require(path.is_file() and not path.is_symlink(),
                            "Non-regular source file: " + relative.as_posix())
                    paths.append(path)
    payload = {}
    for path in sorted(paths):
        relative = path.relative_to(ROOT).as_posix()
        require(relative not in payload, "Duplicate source path: " + relative)
        data = path.read_bytes()
        mode = stat.S_IMODE(path.stat().st_mode)
        payload[relative] = {"data": data, "sha256": sha256(data), "mode": mode}
    return payload


def source_id(payload):
    """Match the ordered sourceId inputs in scripts/build_apk.py exactly."""
    sources = sorted(p for p in payload if p.startswith("src/") and p.endswith(".java"))
    native = sorted(p for p in payload if p.startswith("native/") and p.count("/") == 1)
    resources = sorted(p for p in payload if p.startswith("res/") and p.endswith(".xml"))
    ordered = sources + native + resources + ["AndroidManifest.xml", "vendor/manifest.json"]
    digest = hashlib.sha256()
    for name in ordered:
        digest.update(name.encode("utf-8"))
        digest.update(payload[name]["data"])
    return digest.hexdigest()


def verify_build(payload):
    require(BUILD_METADATA in payload, "Run scripts/build_apk.py before packaging")
    metadata = json.loads(payload[BUILD_METADATA]["data"])
    for key in ("sha256", "sourceId"):
        require(isinstance(metadata.get(key), str)
                and re.fullmatch(r"[0-9a-f]{64}", metadata[key]),
                "Invalid build metadata field: " + key)
    require(metadata.get("signatureVerified") is True,
            "Build metadata does not record a verified APK signature")
    require(source_id(payload) == metadata["sourceId"],
            "Source files differ from the APK build; rebuild before packaging")

    vendor = json.loads(payload["vendor/manifest.json"]["data"])
    for entry in vendor["files"]:
        name = entry["file"]
        require(name in payload and payload[name]["sha256"] == entry["sha256"],
                "Original vendor source differs from its pinned manifest: " + name)
        if entry.get("git_blob"):
            data = payload[name]["data"]
            blob = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
            require(blob == entry["git_blob"], "Original vendor Git blob mismatch: " + name)

    provenance = json.loads(payload["assets/build-provenance.json"]["data"])
    require(provenance.get("version") == VERSION
            and provenance.get("sourceId") == metadata["sourceId"]
            and provenance.get("components") == vendor,
            "Build provenance does not match current sources and vendor manifest")
    apk_name = metadata.get("apk")
    require(isinstance(apk_name, str) and apk_name == ARCHIVE_ROOT + ".apk",
            "Unexpected APK filename in build metadata")
    apk = ROOT / "dist" / apk_name
    require(apk.is_file() and not apk.is_symlink(), "Missing final APK: " + str(apk))
    require(apk.stat().st_size == metadata.get("bytes") and file_sha256(apk) == metadata["sha256"],
            "Final APK bytes differ from build metadata")
    with zipfile.ZipFile(apk) as archive:
        require(archive.testzip() is None, "APK CRC verification failed")
        embedded = json.loads(archive.read("assets/build-provenance.json"))
        require(embedded == provenance, "APK embedded provenance differs from source assets")
    return metadata


def create_manifest(payload, metadata):
    return {
        "schema": "x-gaming-lab-source-manifest-v1",
        "version": VERSION,
        "archiveRoot": ARCHIVE_ROOT,
        "sourceId": metadata["sourceId"],
        "sourceIdAlgorithm": "scripts/build_apk.py ordered relative path UTF-8 bytes + file bytes, SHA256",
        "apk": {
            "file": metadata["apk"], "bytes": metadata["bytes"],
            "sha256": metadata["sha256"], "includedInSourceZip": False,
            "signatureVerifiedByBuild": metadata["signatureVerified"],
        },
        "buildMetadata": {"path": BUILD_METADATA, "sha256": payload[BUILD_METADATA]["sha256"]},
        "integrity": {
            "payloadHash": "SHA256",
            "manifestScope": "Every payload file; SOURCE_MANIFEST.json excludes itself to avoid a circular hash",
            "verification": "ZIP CRC, exact entry list, payload size, mode and SHA256 checked before publication",
            "signatureScope": "This manifest records hashes, not an independent signature or performance certification",
        },
        "selection": {
            "directories": list(INCLUDE_DIRS), "rootFiles": list(ROOT_FILES),
            "excludedDirectories": sorted(EXCLUDED_DIRS), "excludedFileSuffixes": [".pyc"],
            "evidenceSuffixes": sorted(EVIDENCE_SUFFIXES),
            "androidV2EvidenceSuffixes": sorted(ANDROID_EVIDENCE_SUFFIXES),
            "evidenceTextSummaries": sorted(EVIDENCE_TEXT_SUMMARIES),
            "evidenceExclusions": "PPM and raw .log files; images/XML outside the Android v2 proof bundle. Android v2 includes captured evidence required by validate_evidence.py.",
            "jsonlResultsIncluded": True,
        },
        "fileCount": len(payload),
        "files": [
            {"path": name, "bytes": len(item["data"]), "sha256": item["sha256"],
             "mode": format(item["mode"], "04o")}
            for name, item in sorted(payload.items())
        ],
    }


def write_entry(archive, name, data, mode):
    info = zipfile.ZipInfo(ARCHIVE_ROOT + "/" + name, ZIP_TIME)
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | mode) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_archive(path, payload, manifest_data):
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, "Source ZIP CRC verification failed")
        names = archive.namelist()
        expected = {ARCHIVE_ROOT + "/" + name for name in payload}
        expected.add(ARCHIVE_ROOT + "/" + MANIFEST_PATH)
        require(len(names) == len(expected) and set(names) == expected,
                "Source ZIP has missing, extra or duplicate entries")
        raw_manifest = archive.read(ARCHIVE_ROOT + "/" + MANIFEST_PATH)
        require(raw_manifest == manifest_data, "Source manifest changed during packaging")
        manifest = json.loads(raw_manifest)
        require(manifest["fileCount"] == len(payload), "Manifest file count mismatch")
        for record in manifest["files"]:
            name = ARCHIVE_ROOT + "/" + record["path"]
            data = archive.read(name)
            require(len(data) == record["bytes"] and sha256(data) == record["sha256"],
                    "Source ZIP payload hash mismatch: " + record["path"])
            mode = stat.S_IMODE(archive.getinfo(name).external_attr >> 16)
            require(mode == int(record["mode"], 8), "Source ZIP mode mismatch: " + record["path"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "dist" / (ARCHIVE_ROOT + "-source.zip"),
                        help="Output ZIP (default: project dist directory)")
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    require(output.suffix.lower() == ".zip", "Output must use a .zip suffix")
    # Keep the output out of included directories, so an earlier archive cannot
    # recursively become part of the next deliverable or overwrite source files.
    for name in INCLUDE_DIRS:
        require(ROOT / name not in output.parents, "Output must be outside included source directories")
    payload = collect_payload()
    metadata = verify_build(payload)
    manifest_data = (json.dumps(create_manifest(payload, metadata), indent=2,
                                ensure_ascii=False) + "\n").encode("utf-8")
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix="." + output.name + ".", suffix=".tmp", dir=output.parent)
    os.close(descriptor)
    temporary = Path(temporary)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9, allowZip64=True) as archive:
            for name, item in sorted(payload.items()):
                write_entry(archive, name, item["data"], item["mode"])
            write_entry(archive, MANIFEST_PATH, manifest_data, 0o644)
        verify_archive(temporary, payload, manifest_data)
        os.replace(temporary, output)
    finally:
        if temporary.exists():
            temporary.unlink()
    print(json.dumps({
        "zip": str(output), "bytes": output.stat().st_size, "sha256": file_sha256(output),
        "archiveRoot": ARCHIVE_ROOT, "payloadFiles": len(payload),
        "sourceManifestSha256": sha256(manifest_data), "sourceId": metadata["sourceId"],
        "apkSha256": metadata["sha256"], "crcAndAllPayloadHashesVerified": True,
    }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print("Source packaging failed: " + str(error), file=sys.stderr)
        sys.exit(1)
