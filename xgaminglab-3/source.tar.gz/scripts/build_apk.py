#!/usr/bin/env python3
"""Build a self-contained, locally signed Android APK with official SDK/NDK tools."""
import hashlib,json,os,pathlib,shutil,struct,subprocess,sys,zipfile
root=pathlib.Path(__file__).resolve().parents[1]
workspace=root.parent
sdk=pathlib.Path(os.environ.get('ANDROID_SDK_ROOT',str(workspace/'android-lab-tools/sdk')))
ndk=pathlib.Path(os.environ.get('ANDROID_NDK_HOME',str(workspace/'android-lab-tools/ndk/android-ndk-r27d')))
android_jar=pathlib.Path(os.environ.get('ANDROID_JAR',str(sdk/'platforms/android-35/android.jar')))
if not android_jar.exists():android_jar=workspace/'build-tools/android35.jar'
bt=pathlib.Path(os.environ.get('ANDROID_BUILD_TOOLS',str(sdk/'build-tools/35.0.0')))
if not bt.exists():bt=sdk/'android-15'
llvm=ndk/'toolchains/llvm/prebuilt/linux-x86_64'
for p in [android_jar,bt/'aapt2',bt/'lib/d8.jar',llvm/'bin/clang-18']:
 if not p.exists():raise SystemExit('Missing official build dependency: '+str(p))
build=root/'build';dist=root/'dist';build.mkdir(exist_ok=True);dist.mkdir(exist_ok=True)
def run(args,**kwargs):subprocess.run([str(a) for a in args],cwd=root,check=True,**kwargs)
run([sys.executable,'scripts/prepare_vendor.py'])
native_inputs=sorted((root/'native').glob('*'))+[root/'vendor/manifest.json']
native_hash=hashlib.sha256(b''.join(p.name.encode()+p.read_bytes() for p in native_inputs if p.is_file())).hexdigest()
includes=['-I'+str(root/p) for p in ['build/qssd-compat','build/ether-compat','vendor/mundo/native/include','vendor/reverse/src','vendor/qssd/include','vendor/gpu/include','native']]
for abi,target in [('arm64-v8a','aarch64-linux-android26'),('x86_64','x86_64-linux-android26')]:
 out=build/'lib'/abi;out.mkdir(parents=True,exist_ok=True);library=out/'libxgaminglab.so';stamp=out/'source.sha256'
 if library.exists() and stamp.exists() and stamp.read_text()==native_hash:print('Reusing verified native sources for',abi,flush=True);continue
 cmd=[llvm/'bin/clang-18','--driver-mode=g++','--target='+target,'--sysroot='+str(llvm/'sysroot'),'-std=c++20','-O2','-fPIC','-fvisibility=hidden','-ffunction-sections','-fdata-sections','-DREVERSE_PC_HAVE_BOUNDED_PRODUCT_IMPORT=1',*includes,'native/x_backend.cpp','native/component_lab.cpp','native/scene_renderer.cpp','native/android_bridge.cpp','-shared','-static-libstdc++','-pthread','-Wl,--gc-sections','-Wl,-z,max-page-size=16384','-Wl,-z,common-page-size=16384','-Wl,-soname,libxgaminglab.so','-lEGL','-lGLESv2','-landroid','-llog','-lm','-o',library]
 print('Compiling original components and graphics for',abi,flush=True);run(cmd);stamp.write_text(native_hash)

sources=sorted((root/'src').rglob('*.java'))
code_inputs=sources+sorted((root/'native').glob('*'))+sorted((root/'res').rglob('*.xml'))+[root/'AndroidManifest.xml',root/'vendor/manifest.json']
source_id=hashlib.sha256(b''.join(str(p.relative_to(root)).encode()+p.read_bytes() for p in code_inputs if p.is_file())).hexdigest()
generated=build/'generated/x/lab/gaming';generated.mkdir(parents=True,exist_ok=True)
(generated/'BuildInfo.java').write_text('package x.lab.gaming; final class BuildInfo { static final String VERSION="3.0.0"; static final String SOURCE_ID="'+source_id+'"; }\n')
assets=root/'assets';assets.mkdir(exist_ok=True)
(assets/'build-provenance.json').write_text(json.dumps({'version':'3.0.0','sourceId':source_id,'components':json.loads((root/'vendor/manifest.json').read_text()),'graphics':'Ether/XI -> GPU Virtual physical-work plan -> QSSD immutable work revision -> REgraphics retained/delta buffers -> physical GLES GPU','benchmark':'synthetic workloads; no inferred third-party-game FPS'},indent=2)+'\n')
run([bt/'aapt2','compile','--dir','res','-o',build/'compiled-res.zip'])
run([bt/'aapt2','link','--manifest','AndroidManifest.xml','-I',android_jar,'--java',build/'generated','-A','assets','--min-sdk-version','26','--target-sdk-version','35','--auto-add-overlay','-R',build/'compiled-res.zip','-o',build/'base.apk'])
classes=build/'classes';dex=build/'dex'
if classes.exists():shutil.rmtree(classes)
if dex.exists():shutil.rmtree(dex)
classes.mkdir();dex.mkdir()
source_list=build/'java-sources.list';source_list.write_text('\n'.join(str(p) for p in sources+sorted((build/'generated').rglob('*.java')))+'\n')
run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-encoding','UTF-8','--release','8','-classpath',android_jar,'-d',classes,'@'+str(source_list)])
class_list=build/'class-files.list';class_list.write_text('\n'.join(str(p) for p in sorted(classes.rglob('*.class')))+'\n')
run(['java','-cp',bt/'lib/d8.jar','com.android.tools.r8.D8','--lib',android_jar,'--min-api','26','--output',dex,'@'+str(class_list)])
unsigned=build/'unsigned.apk';shutil.copyfile(build/'base.apk',unsigned)
with zipfile.ZipFile(unsigned,'a',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(dex.glob('*.dex')):z.write(p,p.name)
 for p in sorted((build/'lib').glob('*/libxgaminglab.so')):z.write(p,'lib/'+p.parent.name+'/'+p.name)
run([bt/'zipalign','-f','4',unsigned,build/'aligned.apk'])
signing=root/'signing';signing.mkdir(exist_ok=True);key=signing/'x-gaming-lab-debug.p12'
if not key.exists():
 run(['keytool','-genkeypair','-noprompt','-keystore',key,'-storetype','PKCS12','-storepass','android','-keypass','android','-alias','xgaminglab','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=X Gaming Lab Development,O=X,C=US'])
apk=dist/'X-Gaming-Lab-3.0.0.apk'
run([bt/'apksigner','sign','--ks',key,'--ks-key-alias','xgaminglab','--ks-pass','pass:android','--key-pass','pass:android','--out',apk,build/'aligned.apk'])
with (root/'evidence/apk-signature.txt').open('w') as out:run([bt/'apksigner','verify','--verbose','--print-certs',apk],stdout=out)
with (root/'evidence/apk-package.txt').open('w') as out:run([bt/'aapt2','dump','badging',apk],stdout=out)
with zipfile.ZipFile(apk) as z:
 assert z.testzip() is None
 assert 'classes.dex' in z.namelist()
 for abi in ['arm64-v8a','x86_64']:
  binary=z.read('lib/'+abi+'/libxgaminglab.so');assert binary[:5]==b'\x7fELF\x02'
  offset=struct.unpack_from('<Q',binary,32)[0];size,count=struct.unpack_from('<HH',binary,54)
  for i in range(count):
   p=struct.unpack_from('<IIQQQQQQ',binary,offset+i*size)
   if p[0]==1:assert p[7]>=16384 and p[2]%16384==p[3]%16384,(abi,p)
report={'apk':apk.name,'bytes':apk.stat().st_size,'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'sourceId':source_id,'signatureVerified':True,'nativeLoadAlignment16KiB':True,'abis':['arm64-v8a','x86_64'],'minSdk':26,'targetSdk':35,'permissions':[],'physicalPhoneFpsMeasured':False}
(root/'evidence/apk-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
