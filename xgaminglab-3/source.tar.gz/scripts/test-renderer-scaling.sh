#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${XLAB_GL_HEADERS:?Set XLAB_GL_HEADERS to official Khronos EGL, GLES2 and KHR headers}"
mkdir -p build/graphics-scaling
"${CXX:-g++}" -std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror \
  -Inative -I"$XLAB_GL_HEADERS" native/scene_renderer.cpp tests/renderer_scaling_probe.cpp \
  -Wl,--wrap=eglGetProcAddress,--wrap=glGetString,--wrap=glGetIntegerv \
  -Wl,--wrap=glDrawArrays,--wrap=glDrawElements,--wrap=glBufferData,--wrap=glBufferSubData \
  "${XLAB_EGL_LIBRARY:--lEGL}" "${XLAB_GLES_LIBRARY:--lGLESv2}" \
  -o build/graphics-scaling/renderer-scaling-probe
MESA_GLES_VERSION_OVERRIDE=2.0 LIBGL_ALWAYS_SOFTWARE=1 \
  build/graphics-scaling/renderer-scaling-probe build/graphics-scaling | tee build/graphics-scaling/result.json
