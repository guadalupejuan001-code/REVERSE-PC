#!/usr/bin/env python3
"""Verify immutable copies, then run their original reviewed compatibility tools."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / 'vendor/manifest.json').read_text())
for item in manifest['files']:
    raw = (root / item['file']).read_bytes()
    sha256 = hashlib.sha256(raw).hexdigest()
    git_blob = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    if sha256 != item['sha256'] or git_blob != item['git_blob']:
        raise SystemExit('Unreviewed vendor source: ' + item['file'])
commands = [
    ['vendor/qssd/scripts/prepare_gpu.py', 'vendor/gpu/include', 'build/qssd-compat'],
    ['vendor/qssd/scripts/prepare_c12.py', 'vendor/gpu/include', 'build/qssd-compat'],
    ['vendor/reverse/scripts/prepare-ether-compat.py', 'vendor/mundo', 'build/ether-compat'],
]
for command in commands:
    subprocess.run([sys.executable, *command], cwd=root, check=True)
print('Verified %d original source files; generated reviewed build overlays.' % len(manifest['files']))
