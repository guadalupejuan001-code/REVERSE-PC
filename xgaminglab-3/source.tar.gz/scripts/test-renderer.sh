#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${XLAB_GL_HEADERS:?Set XLAB_GL_HEADERS to official Khronos EGL, GLES2 and KHR headers}"
mkdir -p build/graphics-probe
"${CXX:-g++}" -std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror -Inative \
  tests/presentation_tracker_test.cpp -o build/graphics-probe/presentation-tracker-test
build/graphics-probe/presentation-tracker-test | tee build/graphics-probe/presentation-result.json
"${CXX:-g++}" -std=c++17 -O2 -Wall -Wextra -Wpedantic -Werror \
  -Inative -I"$XLAB_GL_HEADERS" native/scene_renderer.cpp tests/renderer_probe.cpp \
  -Wl,--wrap=glGetIntegerv \
  "${XLAB_EGL_LIBRARY:--lEGL}" "${XLAB_GLES_LIBRARY:--lGLESv2}" \
  -o build/graphics-probe/renderer-probe
MESA_GLES_VERSION_OVERRIDE=2.0 LIBGL_ALWAYS_SOFTWARE=1 \
  build/graphics-probe/renderer-probe build/graphics-probe | tee build/graphics-probe/result.json
