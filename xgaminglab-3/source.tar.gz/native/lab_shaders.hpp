#pragma once

namespace xlab::shaders {
// GLSL ES 1.00: the adapter runs on an actual GLES2 context. No external engine.
inline constexpr const char* vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec2 aUv;
uniform mat4 uModel;
uniform mat4 uViewProjection;
uniform mat4 uLightProjection;
uniform mat3 uNormal;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec2 vUv;
varying vec4 vShadow;
void main(){
  vec4 world=uModel*vec4(aPosition,1.0);
  vWorld=world.xyz;vNormal=normalize(uNormal*aNormal);vUv=aUv;
  vShadow=uLightProjection*world;
  gl_Position=uViewProjection*world;
}
)GLSL";
inline constexpr const char* fragment = R"GLSL(
uniform sampler2D uShadow;
uniform vec3 uEye;
uniform vec3 uSun;
uniform vec3 uFog;
#if defined(XLAB_BATCH) || defined(XLAB_INSTANCED)
varying vec4 vColor;
#define uColor vColor
#else
uniform vec4 uColor;
#endif
uniform float uEnergy;
#ifdef XLAB_BATCH
varying float vMaterial;
#define uMesh vMaterial
#else
uniform float uMesh;
#endif
uniform vec2 uShadowTexel;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec2 vUv;
varying vec4 vShadow;
float readDepth(vec2 p){return dot(texture2D(uShadow,p).rg,vec2(1.0,1.0/255.0));}
float shadowVisibility(vec3 normal){
  vec3 s=vShadow.xyz/vShadow.w*0.5+0.5;
  if(s.x<0.002||s.x>0.998||s.y<0.002||s.y>0.998||s.z<0.0||s.z>1.0)return 1.0;
  float z=s.z-max(0.0018*(1.0-max(0.0,dot(normal,uSun))),0.00065);
  float a=step(z,readDepth(s.xy+uShadowTexel*vec2(-0.6,-0.6)));
  a+=step(z,readDepth(s.xy+uShadowTexel*vec2(0.6,-0.6)));
  a+=step(z,readDepth(s.xy+uShadowTexel*vec2(-0.6,0.6)));
  a+=step(z,readDepth(s.xy+uShadowTexel*vec2(0.6,0.6)));
  return a*0.25;
}
void main(){
  vec3 normal=normalize(vNormal);
  vec3 view=normalize(uEye-vWorld);
  vec3 color=uColor.rgb;
  float alpha=uColor.a;
  float emissive=0.0;
  if(uMesh>2.5&&uMesh<3.5){
    float radius=length(vUv*2.0-1.0);
    if(radius>1.0)discard;
    alpha*=1.0-smoothstep(0.3,1.0,radius);
    emissive=1.0;
  }
  if(uMesh>1.5&&uMesh<2.5){
    float checker=mod(floor(vWorld.x*0.35)+floor(vWorld.z*0.35),2.0);
    color*=mix(0.83,1.08,checker);
  }
  float diffuse=max(dot(normal,uSun),0.0);
  float visibility=shadowVisibility(normal);
  float gloss=uMesh>3.5?0.55:(uMesh>0.5&&uMesh<1.5?0.75:0.2);
  float spec=pow(max(dot(normal,normalize(uSun+view)),0.0),mix(12.0,58.0,gloss))*gloss;
  vec3 lit=color*(0.24+0.8*diffuse*visibility)*uEnergy+vec3(1.0,0.91,0.77)*spec*visibility;
  lit=mix(lit,color*(0.85+0.3*uEnergy),emissive);
  float fog=1.0-exp(-length(uEye-vWorld)*0.012);
  lit=mix(lit,uFog,min(0.93,fog));
  gl_FragColor=vec4(lit,alpha);
}
)GLSL";
inline constexpr const char* shadow_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec2 aUv;
uniform mat4 uModel;
uniform mat4 uLightProjection;
varying vec2 vUv;
void main(){vUv=aUv;gl_Position=uLightProjection*uModel*vec4(aPosition,1.0);}
)GLSL";
inline constexpr const char* shadow_fragment = R"GLSL(
#ifdef XLAB_BATCH
varying float vRound;
#define uRound vRound
#else
uniform float uRound;
#endif
varying vec2 vUv;
void main(){
  if(uRound>0.5&&length(vUv*2.0-1.0)>1.0)discard;
  // Two-channel packing works without depth-texture extensions on GLES2.
  vec2 depth=fract(vec2(1.0,255.0)*min(gl_FragCoord.z,0.99999));
  depth.x-=depth.y/255.0;
  gl_FragColor=vec4(depth,0.0,1.0);
}
)GLSL";
// Core GLES2 fallback: vertices are expanded in original primitive order into
// retained chunks. No texture, colour or coordinate quantization is introduced.
inline constexpr const char* batch_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec3 aUvMaterial;
attribute vec4 aColor;
uniform mat4 uViewProjection;
uniform mat4 uLightProjection;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec2 vUv;
varying vec4 vShadow;
varying vec4 vColor;
varying float vMaterial;
void main(){
  vec4 world=vec4(aPosition,1.0);
  vWorld=world.xyz;vNormal=normalize(aNormal);vUv=aUvMaterial.xy;
  vShadow=uLightProjection*world;vColor=aColor;vMaterial=aUvMaterial.z;
  gl_Position=uViewProjection*world;
}
)GLSL";
inline constexpr const char* batch_shadow_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec3 aUvMaterial;
uniform mat4 uLightProjection;
varying vec2 vUv;
varying float vRound;
void main(){
  vUv=aUvMaterial.xy;vRound=aUvMaterial.z>2.5&&aUvMaterial.z<3.5?1.0:0.0;
  gl_Position=uLightProjection*vec4(aPosition,1.0);
}
)GLSL";
// Compact relation-instancing route: GPU Virtual sends only translation, scale,
// yaw and RGBA8. The physical GPU reconstructs the model/normal basis. This
// preserves analytic transforms while reducing per-instance transfer from 112 B
// to 32 B and keeps billboards camera-facing without CPU matrix expansion.
inline constexpr const char* compact_instanced_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec2 aUv;
attribute vec4 aInstanceTransform; // xyz + yaw
attribute vec3 aInstanceScale;
attribute vec4 aInstanceColor;     // normalized RGBA8
uniform mat4 uViewProjection;
uniform mat4 uLightProjection;
uniform vec3 uEye;
uniform float uMesh;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec2 vUv;
varying vec4 vShadow;
varying vec4 vColor;
void main(){
  float c=cos(aInstanceTransform.w),s=sin(aInstanceTransform.w);
  vec3 right=vec3(c,0.0,-s),up=vec3(0.0,1.0,0.0),front=vec3(s,0.0,c);
  if(uMesh>2.5&&uMesh<3.5){
    front=normalize(uEye-aInstanceTransform.xyz);
    vec3 axis=abs(front.y)>0.97?vec3(0.0,0.0,1.0):vec3(0.0,1.0,0.0);
    right=normalize(cross(axis,front));up=cross(front,right);
  }
  vec3 local=aPosition*aInstanceScale;
  vec3 world3=aInstanceTransform.xyz+right*local.x+up*local.y+front*local.z;
  vec3 n=right*(aNormal.x/aInstanceScale.x)+up*(aNormal.y/aInstanceScale.y)+front*(aNormal.z/aInstanceScale.z);
  vec4 world=vec4(world3,1.0);
  vWorld=world3;vNormal=normalize(n);vUv=aUv;vShadow=uLightProjection*world;vColor=aInstanceColor;
  gl_Position=uViewProjection*world;
}
)GLSL";
inline constexpr const char* compact_instanced_shadow_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec2 aUv;
attribute vec4 aInstanceTransform;
attribute vec3 aInstanceScale;
uniform mat4 uLightProjection;
varying vec2 vUv;
void main(){
  float c=cos(aInstanceTransform.w),s=sin(aInstanceTransform.w);
  vec3 right=vec3(c,0.0,-s),up=vec3(0.0,1.0,0.0),front=vec3(s,0.0,c);
  vec3 local=aPosition*aInstanceScale;
  vec3 world=aInstanceTransform.xyz+right*local.x+up*local.y+front*local.z;
  vUv=aUv;gl_Position=uLightProjection*vec4(world,1.0);
}
)GLSL";
// Ten attributes are required for this optional route. Devices with only the
// GLES2 minimum use the four-attribute expanded route above. Matrix coefficients
// are the exact prepared floats; yaw/normal reconstruction is not approximated.
inline constexpr const char* instanced_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec2 aUv;
attribute vec4 aRow0;
attribute vec4 aRow1;
attribute vec4 aRow2;
attribute vec3 aNormal0;
attribute vec3 aNormal1;
attribute vec3 aNormal2;
attribute vec4 aInstanceColor;
uniform mat4 uViewProjection;
uniform mat4 uLightProjection;
varying vec3 vWorld;
varying vec3 vNormal;
varying vec2 vUv;
varying vec4 vShadow;
varying vec4 vColor;
void main(){
  mat4 model=mat4(vec4(aRow0.x,aRow1.x,aRow2.x,0.0),
                  vec4(aRow0.y,aRow1.y,aRow2.y,0.0),
                  vec4(aRow0.z,aRow1.z,aRow2.z,0.0),
                  vec4(aRow0.w,aRow1.w,aRow2.w,1.0));
  vec4 world=model*vec4(aPosition,1.0);
  vWorld=world.xyz;vNormal=normalize(mat3(aNormal0,aNormal1,aNormal2)*aNormal);
  vUv=aUv;vShadow=uLightProjection*world;vColor=aInstanceColor;
  gl_Position=uViewProjection*world;
}
)GLSL";
inline constexpr const char* instanced_shadow_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec2 aUv;
attribute vec4 aRow0;
attribute vec4 aRow1;
attribute vec4 aRow2;
uniform mat4 uLightProjection;
varying vec2 vUv;
void main(){
  mat4 model=mat4(vec4(aRow0.x,aRow1.x,aRow2.x,0.0),
                  vec4(aRow0.y,aRow1.y,aRow2.y,0.0),
                  vec4(aRow0.z,aRow1.z,aRow2.z,0.0),
                  vec4(aRow0.w,aRow1.w,aRow2.w,1.0));
  vUv=aUv;gl_Position=uLightProjection*model*vec4(aPosition,1.0);
}
)GLSL";
inline constexpr const char* screen_vertex = R"GLSL(
attribute vec3 aPosition;
attribute vec2 aUv;
varying vec2 vUv;
void main(){vUv=aUv;gl_Position=vec4(aPosition.xy*2.0,0.0,1.0);}
)GLSL";
inline constexpr const char* screen_fragment = R"GLSL(
uniform sampler2D uImage;
varying vec2 vUv;
void main(){
  vec3 color=texture2D(uImage,vUv).rgb;
  float vignette=1.0-0.13*dot(vUv-0.5,vUv-0.5);
  gl_FragColor=vec4(color*vignette,1.0);
}
)GLSL";
} // namespace xlab::shaders
