#pragma once
#include <cstddef>
#include <cstdint>
#include <deque>

namespace xlab {
// Tracks only measured presentation timestamps. A requested/expected time is
// deliberately absent from this API, so it cannot become a measurement.
class PresentationTracker {
 public:
  enum class State { pending, invalid, measured };
  struct Read { State state=State::pending; std::int64_t time_ns=-1; };
  struct Sample { std::uint64_t serial=0; std::int64_t time_ns=-1; };
  void reset(){queue_.clear();lost_=discarded_=processed_=0;}
  void discard_pending(){discarded_+=queue_.size();queue_.clear();}
  void submitted(std::uint64_t egl_id,std::uint64_t serial,std::int64_t now_ns){
    queue_.push_back({egl_id,serial,now_ns});
    if(queue_.size()>capacity){queue_.pop_front();++discarded_;}
  }
  void untracked_swap(){++lost_;}
  template<class Reader> Sample poll(std::int64_t now_ns,Reader&& reader){
    // One oldest newly resolved sample per frame. Bound malformed-driver work.
    for(int attempts=0;!queue_.empty()&&attempts<16;++attempts){
      const Pending entry=queue_.front();
      if(now_ns-entry.enqueued_ns>timeout_ns){queue_.pop_front();++discarded_;continue;}
      const Read read=reader(entry.egl_id);
      if(read.state==State::pending)break;
      queue_.pop_front();
      if(read.state==State::invalid||read.time_ns<=0){++lost_;continue;}
      ++processed_;return {entry.serial,read.time_ns};
    }
    return {};
  }
  std::size_t pending() const{return queue_.size();}
  std::uint64_t lost() const{return lost_;}
  std::uint64_t discarded() const{return discarded_;}
  std::uint64_t processed() const{return processed_;}
  static constexpr std::size_t capacity=256;
  static constexpr std::int64_t timeout_ns=3000000000LL;
 private:
  struct Pending {std::uint64_t egl_id,serial;std::int64_t enqueued_ns;};
  std::deque<Pending> queue_;
  std::uint64_t lost_=0,discarded_=0,processed_=0;
};
} // namespace xlab
