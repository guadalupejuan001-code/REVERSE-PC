#pragma once
#include <array>
#include <cstdint>
#include <vector>
#include <cstring>

namespace xlab {
// Exact state comparison, not a probabilistic hash. Geometry order and light matrix
// are part of the dependency key. Only a fully completed render may be retained.
struct ShadowDelta {
  std::array<float,16> projection{};
  std::vector<std::array<float,17>> casters; // model matrix + mesh identifier
  bool valid=false;
  void invalidate() noexcept { valid=false; casters.clear(); }
  bool matches(const ShadowDelta& other) const noexcept {
    if(!valid || !other.valid || casters.size()!=other.casters.size())return false;
    if(std::memcmp(projection.data(),other.projection.data(),sizeof(projection))!=0)return false;
    for(std::size_t i=0;i<casters.size();++i)
      if(std::memcmp(casters[i].data(),other.casters[i].data(),sizeof(casters[i]))!=0)return false;
    return true;
  }
};
}
