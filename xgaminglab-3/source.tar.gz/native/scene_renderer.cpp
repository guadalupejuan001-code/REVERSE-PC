#include "lab_api.hpp"
#include "lab_gl_util.hpp"
#include "lab_shaders.hpp"
#include "shadow_delta.hpp"
#include "trabajo_fisico.hpp"
#include "qssd/graphics_work_state.hpp"
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <limits>
#include <map>
#include <sstream>
#include <stdexcept>
#include <vector>

namespace xlab {
namespace {
constexpr float pi=3.14159265358979323846f;
struct V3 {float x,y,z;};
V3 add(V3 a,V3 b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
V3 sub(V3 a,V3 b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
V3 mul(V3 a,float b){return {a.x*b,a.y*b,a.z*b};}
float dot(V3 a,V3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
V3 cross(V3 a,V3 b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
float length(V3 a){return std::sqrt(dot(a,a));}
V3 norm(V3 a){float l=length(a);return l>1e-7f?mul(a,1/l):V3{0,1,0};}
V3 vec(const std::array<float,3>& a){return {a[0],a[1],a[2]};}
using M4=std::array<float,16>;
M4 product(const M4& a,const M4& b){
  M4 out{};for(int c=0;c<4;++c)for(int r=0;r<4;++r)for(int k=0;k<4;++k)out[c*4+r]+=a[k*4+r]*b[c*4+k];return out;
}
M4 perspective(float aspect){
  const float f=1/std::tan(52*pi/360),near=.15f,far=260;
  return {f/aspect,0,0,0,0,f,0,0,0,0,(far+near)/(near-far),-1,0,0,2*far*near/(near-far),0};
}
M4 ortho(float span,float near,float far){
  return {1/span,0,0,0,0,1/span,0,0,0,0,-2/(far-near),0,0,0,-(far+near)/(far-near),1};
}
M4 look_at(V3 eye,V3 look){
  const V3 forward=norm(sub(look,eye));
  const V3 up=std::abs(forward.y)>.97f?V3{0,0,1}:V3{0,1,0};
  const V3 side=norm(cross(forward,up)),vertical=cross(side,forward);
  return {side.x,vertical.x,-forward.x,0,side.y,vertical.y,-forward.y,0,side.z,vertical.z,-forward.z,0,-dot(side,eye),-dot(vertical,eye),dot(forward,eye),1};
}
struct Plane {V3 n;float d;};
std::array<Plane,6> frustum(const M4& matrix){
  std::array<Plane,6> out{};
  for(int axis=0;axis<3;++axis)for(int side=0;side<2;++side){
    const float sign=side?1.f:-1.f;
    Plane p{{matrix[3]+sign*matrix[axis],matrix[7]+sign*matrix[4+axis],matrix[11]+sign*matrix[8+axis]},matrix[15]+sign*matrix[12+axis]};
    const float l=length(p.n);if(l>0){p.n=mul(p.n,1/l);p.d/=l;}out[axis*2+side]=p;
  }
  return out;
}
bool visible(const std::array<Plane,6>& planes,V3 center,float radius){
  for(const Plane& p:planes)if(dot(p.n,center)+p.d < -radius)return false;
  return true;
}
struct Vertex {float px,py,pz,nx,ny,nz,u,v;};
void triangle(std::vector<Vertex>& vertices,V3 a,V3 b,V3 c,std::array<float,6> uv={0,0,1,0,.5f,1}){
  const V3 n=norm(cross(sub(b,a),sub(c,a)));
  const V3 points[]={a,b,c};for(int i=0;i<3;++i)vertices.push_back({points[i].x,points[i].y,points[i].z,n.x,n.y,n.z,uv[i*2],uv[i*2+1]});
}
void quad(std::vector<Vertex>& v,V3 a,V3 b,V3 c,V3 d){triangle(v,a,b,c,{0,0,1,0,1,1});triangle(v,a,c,d,{0,0,1,1,0,1});}
std::vector<Vertex> mesh_data(int mesh){
  std::vector<Vertex> v;
  if(mesh==0){
    quad(v,{-.5,-.5,.5},{.5,-.5,.5},{.5,.5,.5},{-.5,.5,.5});
    quad(v,{.5,-.5,-.5},{-.5,-.5,-.5},{-.5,.5,-.5},{.5,.5,-.5});
    quad(v,{.5,-.5,.5},{.5,-.5,-.5},{.5,.5,-.5},{.5,.5,.5});
    quad(v,{-.5,-.5,-.5},{-.5,-.5,.5},{-.5,.5,.5},{-.5,.5,-.5});
    quad(v,{-.5,.5,.5},{.5,.5,.5},{.5,.5,-.5},{-.5,.5,-.5});
    quad(v,{-.5,-.5,-.5},{.5,-.5,-.5},{.5,-.5,.5},{-.5,-.5,.5});
  }else if(mesh==1){
    const V3 top{0,.5,0},bottom{0,-.5,0};const V3 ring[]={{.5,0,0},{0,0,.5},{-.5,0,0},{0,0,-.5}};
    for(int i=0;i<4;++i){triangle(v,top,ring[(i+1)%4],ring[i]);triangle(v,bottom,ring[i],ring[(i+1)%4]);}
  }else if(mesh==2){quad(v,{-.5,0,.5},{.5,0,.5},{.5,0,-.5},{-.5,0,-.5});
  }else if(mesh==3){quad(v,{-.5,-.5,0},{.5,-.5,0},{.5,.5,0},{-.5,.5,0});
  }else if(mesh==4){
    constexpr int segments=16;
    for(int i=0;i<segments;++i){
      const float a=2*pi*i/segments,b=2*pi*(i+1)/segments;
      const V3 low_a{.5f*std::cos(a),-.5,.5f*std::sin(a)},low_b{.5f*std::cos(b),-.5,.5f*std::sin(b)};
      const V3 high_a{low_a.x,.5,low_a.z},high_b{low_b.x,.5,low_b.z};
      quad(v,low_b,low_a,high_a,high_b);triangle(v,{0,.5,0},high_b,high_a);triangle(v,{0,-.5,0},low_a,low_b);
    }
  }else throw std::invalid_argument("Unknown mesh supplied by backend");
  return v;
}
void check_gl(const char* action){
  const GLenum error=glGetError();if(error!=GL_NO_ERROR)throw std::runtime_error(std::string(action)+" GL error "+std::to_string(error));
}
GLuint compile_shader(GLenum type,const std::string& source){
  const GLuint shader=glCreateShader(type);if(!shader)throw std::runtime_error("Unable to allocate shader");
  const char* data=source.c_str();glShaderSource(shader,1,&data,nullptr);glCompileShader(shader);
  GLint ok=0;glGetShaderiv(shader,GL_COMPILE_STATUS,&ok);
  if(!ok){GLint size=0;glGetShaderiv(shader,GL_INFO_LOG_LENGTH,&size);std::string log(std::max(1,size),'\0');glGetShaderInfoLog(shader,log.size(),nullptr,log.data());glDeleteShader(shader);throw std::runtime_error("Shader compile: "+log);}
  return shader;
}
GLuint program(const std::string& precision,const char* vs,const char* fs,int layout=0){
  const GLuint vertex=compile_shader(GL_VERTEX_SHADER,precision+vs);GLuint fragment=0;
  try{fragment=compile_shader(GL_FRAGMENT_SHADER,precision+fs);}catch(...){glDeleteShader(vertex);throw;}
  const GLuint p=glCreateProgram();glAttachShader(p,vertex);glAttachShader(p,fragment);
  glBindAttribLocation(p,0,"aPosition");glBindAttribLocation(p,1,"aNormal");glBindAttribLocation(p,2,"aUv");
  if(layout==1){glBindAttribLocation(p,2,"aUvMaterial");glBindAttribLocation(p,3,"aColor");}
  if(layout==2){
    const char* names[]={"aRow0","aRow1","aRow2","aNormal0","aNormal1","aNormal2","aInstanceColor"};
    for(int i=0;i<7;++i)glBindAttribLocation(p,GLuint(3+i),names[i]);
  }
  if(layout==3){
    glBindAttribLocation(p,3,"aInstanceTransform");
    glBindAttribLocation(p,4,"aInstanceScale");
    glBindAttribLocation(p,5,"aInstanceColor");
  }
  glLinkProgram(p);
  glDeleteShader(vertex);glDeleteShader(fragment);GLint ok=0;glGetProgramiv(p,GL_LINK_STATUS,&ok);
  if(!ok){GLint size=0;glGetProgramiv(p,GL_INFO_LOG_LENGTH,&size);std::string log(std::max(1,size),'\0');glGetProgramInfoLog(p,log.size(),nullptr,log.data());glDeleteProgram(p);throw std::runtime_error("Shader link: "+log);}return p;
}
struct Target {
  GLuint fbo=0,color=0,depth=0;int width=0,height=0;
  void release(){if(fbo)glDeleteFramebuffers(1,&fbo);if(color)glDeleteTextures(1,&color);if(depth)glDeleteRenderbuffers(1,&depth);fbo=color=depth=0;width=height=0;}
  void create(int w,int h,bool nearest){
    if(w==width&&h==height&&fbo)return;
    release();width=w;height=h;
    glGenTextures(1,&color);glBindTexture(GL_TEXTURE_2D,color);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,nearest?GL_NEAREST:GL_LINEAR);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,nearest?GL_NEAREST:GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_CLAMP_TO_EDGE);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,nullptr);
    glGenRenderbuffers(1,&depth);glBindRenderbuffer(GL_RENDERBUFFER,depth);glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH_COMPONENT16,w,h);
    glGenFramebuffers(1,&fbo);glBindFramebuffer(GL_FRAMEBUFFER,fbo);glFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,color,0);glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,depth);
    if(glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE)throw std::runtime_error("GLES2 render target is incomplete");
    glBindFramebuffer(GL_FRAMEBUFFER,0);check_gl("Allocate framebuffer");
  }
};
struct Prepared {
  const Instance* source=nullptr;M4 model{};std::array<float,9> normal{};V3 center{};float radius=0,distance=0;bool camera_visible=false,shadow_visible=false;
};
Prepared prepare(const Instance& object,V3 eye,V3 forward,const std::array<Plane,6>& camera,const std::array<Plane,6>& light){
  const float values[]={object.x,object.y,object.z,object.sx,object.sy,object.sz,object.yaw,object.r,object.g,object.b,object.a};
  for(float value:values)if(!std::isfinite(value))throw std::invalid_argument("Non-finite backend object");
  if(object.mesh<0||object.mesh>4||object.sx<=0||object.sy<=0||object.sz<=0)throw std::invalid_argument("Invalid backend mesh or scale");
  Prepared out;out.source=&object;out.center={object.x,object.y,object.z};
  out.radius=.5f*std::sqrt(object.sx*object.sx+object.sy*object.sy+object.sz*object.sz);
  V3 right{std::cos(object.yaw),0,-std::sin(object.yaw)},up{0,1,0},front{std::sin(object.yaw),0,std::cos(object.yaw)};
  if(object.mesh==3){front=norm(sub(eye,out.center));const V3 axis=std::abs(front.y)>.97f?V3{0,0,1}:V3{0,1,0};right=norm(cross(axis,front));up=cross(front,right);}
  const V3 x=mul(right,object.sx),y=mul(up,object.sy),z=mul(front,object.sz);
  out.model={x.x,x.y,x.z,0,y.x,y.y,y.z,0,z.x,z.y,z.z,0,object.x,object.y,object.z,1};
  out.normal={right.x/object.sx,right.y/object.sx,right.z/object.sx,up.x/object.sy,up.y/object.sy,up.z/object.sy,front.x/object.sz,front.y/object.sz,front.z/object.sz};
  out.distance=dot(sub(out.center,eye),forward);
  out.camera_visible=visible(camera,out.center,out.radius);
  out.shadow_visible=object.casts_shadow&&object.a>=.995f&&visible(light,out.center,out.radius);
  return out;
}
using ObjectKey=std::array<float,30>;
ObjectKey object_key(const Prepared& object){
  ObjectKey key{};std::copy(object.model.begin(),object.model.end(),key.begin());
  std::copy(object.normal.begin(),object.normal.end(),key.begin()+16);
  const Instance& s=*object.source;key[25]=s.r;key[26]=s.g;key[27]=s.b;key[28]=std::clamp(s.a,0.f,1.f);key[29]=float(s.mesh);return key;
}
struct BatchVertex {float data[13];};
static_assert(sizeof(BatchVertex)==13*sizeof(float));
using InstanceUpload=std::array<float,28>;
InstanceUpload instance_upload(const Prepared& object){
  InstanceUpload value{};
  for(int row=0;row<3;++row)for(int col=0;col<4;++col)value[row*4+col]=object.model[col*4+row];
  for(int col=0;col<3;++col)for(int row=0;row<3;++row)value[12+col*4+row]=object.normal[col*3+row];
  const Instance& s=*object.source;value[24]=s.r;value[25]=s.g;value[26]=s.b;value[27]=std::clamp(s.a,0.f,1.f);return value;
}
BatchVertex expanded_vertex(const Vertex& vertex,const Prepared& object){
  const auto& m=object.model;const auto& n=object.normal;const Instance& s=*object.source;
  return {{
    m[0]*vertex.px+m[4]*vertex.py+m[8]*vertex.pz+m[12],
    m[1]*vertex.px+m[5]*vertex.py+m[9]*vertex.pz+m[13],
    m[2]*vertex.px+m[6]*vertex.py+m[10]*vertex.pz+m[14],
    n[0]*vertex.nx+n[3]*vertex.ny+n[6]*vertex.nz,
    n[1]*vertex.nx+n[4]*vertex.ny+n[7]*vertex.nz,
    n[2]*vertex.nx+n[5]*vertex.ny+n[8]*vertex.nz,
    vertex.u,vertex.v,float(s.mesh),s.r,s.g,s.b,std::clamp(s.a,0.f,1.f)}};
}
} // namespace


struct CompactInstanceUpload {
  float x,y,z,yaw,sx,sy,sz,r,g,b,a;
};
static_assert(sizeof(CompactInstanceUpload)==44);
CompactInstanceUpload compact_instance_upload(const Prepared& object){
  const auto& s=*object.source;
  return {s.x,s.y,s.z,s.yaw,s.sx,s.sy,s.sz,s.r,s.g,s.b,std::clamp(s.a,0.f,1.f)};
}
std::uint64_t matrix_revision(const M4& m){
  std::uint64_t h=1469598103934665603ULL;
  for(float f:m){std::uint32_t w;std::memcpy(&w,&f,4);for(int i=0;i<4;++i){h^=(w>>(i*8))&255U;h*=1099511628211ULL;}}
  return h;
}
struct Renderer::Impl {
  Config config{};bool initialized=false,high_precision=false;
  int surface_width=1,surface_height=1,max_texture=0,max_attributes=0,pending_upload=0,array_mode=-1;
  GLuint scene_program=0,shadow_program=0,screen_program=0,batch_program=0,batch_shadow_program=0,instance_program=0,instance_shadow_program=0,compact_instance_program=0,compact_instance_shadow_program=0;
  struct Mesh {GLuint vbo=0;int vertices=0;std::vector<Vertex> unique;std::vector<std::uint16_t> indices;};std::array<Mesh,5> meshes{};
  Target scene,shadow;
  ShadowDelta retained_shadow;
  std::uint64_t retained_scene_hash=0;bool retained_scene_valid=false;
  xgpu::PhysicalWorkAuthority work_authority;
  qssd::GraphicsWorkMemory<xgpu::PhysicalWorkPlan> work_memory{8};
  struct SceneUniforms {GLint model,normal,view,light,shadow,eye,sun,fog,color,energy,mesh,texel;} u{},batch_u{},instance_u{},compact_u{};
  struct ShadowUniforms {GLint model,light,round;} s{},batch_s{},instance_s{},compact_s{};
  GLint image=-1;
  std::vector<Prepared> prepared;
  std::array<std::vector<const Prepared*>,3> ordered; // shadow, opaque, sorted alpha
  std::string vendor,device,version;
  PFNGLDRAWARRAYSINSTANCEDEXTPROC draw_instanced=nullptr;
  PFNGLVERTEXATTRIBDIVISOREXTPROC divisor=nullptr;
  bool instance_supported=false;
  std::string instance_extension,instance_fallback="extension_unavailable";
  static constexpr std::size_t chunk_vertices=65535,instance_limit=4096;
  struct Batch {
    bool instanced=false,vertices_dirty=false,indices_dirty=false;
    int mesh=-1,object_count=0;
    GLuint vbo=0,ibo=0;std::size_t vertex_capacity=0,index_capacity=0;
    std::vector<ObjectKey> keys,next_keys;
    std::vector<BatchVertex> vertices;
    std::vector<std::uint16_t> indices,next_indices;
    std::vector<InstanceUpload> instances;
    std::vector<CompactInstanceUpload> compact_instances;
    std::vector<std::pair<std::size_t,std::size_t>> dirty_ranges; // [begin,end) instance spans
    bool compact=false;
    void release(){if(vbo)glDeleteBuffers(1,&vbo);if(ibo)glDeleteBuffers(1,&ibo);vbo=ibo=0;}
  };
  std::array<std::vector<Batch>,3> batches;
  std::array<std::size_t,3> active_batches{};
  PFNGLGENQUERIESEXTPROC gen_queries=nullptr;
  PFNGLDELETEQUERIESEXTPROC delete_queries=nullptr;
  PFNGLBEGINQUERYEXTPROC begin_query=nullptr;
  PFNGLENDQUERYEXTPROC end_query=nullptr;
  PFNGLGETQUERYIVEXTPROC query_iv=nullptr;
  PFNGLGETQUERYOBJECTUIVEXTPROC query_uiv=nullptr;
  PFNGLGETQUERYOBJECTUI64VEXTPROC query_ui64=nullptr;
  struct Timer {GLuint id[3]{0,0,0};std::uint64_t serial=0;bool pending=false;bool executed[3]{false,false,false};int active=-1;};
  std::array<Timer,8> timers{};bool timer_supported=false;std::uint64_t timer_discarded=0;

  ~Impl(){release();}
  void clear_batches(){for(auto& pass:batches){for(auto& batch:pass)batch.release();pass.clear();}active_batches.fill(0);}
  void clear_timers(bool count){
    if(!timer_supported)return;
    for(Timer& q:timers){if(q.pending&&count)++timer_discarded;q.pending=false;q.serial=0;q.active=-1;for(bool& e:q.executed)e=false;}
  }
  void release(){
    if(timer_supported&&delete_queries)for(Timer& q:timers)for(GLuint& id:q.id)if(id){delete_queries(1,&id);id=0;}
    timer_supported=false;clear_batches();retained_shadow.invalidate();scene.release();shadow.release();
    for(auto& m:meshes)if(m.vbo){glDeleteBuffers(1,&m.vbo);m.vbo=0;}
    if(scene_program)glDeleteProgram(scene_program);
    if(shadow_program)glDeleteProgram(shadow_program);
    if(screen_program)glDeleteProgram(screen_program);
    if(batch_program)glDeleteProgram(batch_program);
    if(batch_shadow_program)glDeleteProgram(batch_shadow_program);
    if(instance_program)glDeleteProgram(instance_program);
    if(instance_shadow_program)glDeleteProgram(instance_shadow_program);
    if(compact_instance_program)glDeleteProgram(compact_instance_program);
    if(compact_instance_shadow_program)glDeleteProgram(compact_instance_shadow_program);
    scene_program=shadow_program=screen_program=batch_program=batch_shadow_program=instance_program=instance_shadow_program=compact_instance_program=compact_instance_shadow_program=0;retained_scene_valid=false;work_authority.reset();work_memory.reset(8);initialized=false;
  }
  void init_instancing(){
    const char* extensions=reinterpret_cast<const char*>(glGetString(GL_EXTENSIONS));
    int major=0,minor=0;std::sscanf(version.c_str(),"OpenGL ES %d.%d",&major,&minor);
    struct Route {const char* extension;const char* draw;const char* divide;bool supported;};
    const Route routes[]={
      {"GLES3_core","glDrawArraysInstanced","glVertexAttribDivisor",major>=3},
      {"GL_EXT_instanced_arrays","glDrawArraysInstancedEXT","glVertexAttribDivisorEXT",extension_has(extensions,"GL_EXT_instanced_arrays")},
      {"GL_ANGLE_instanced_arrays","glDrawArraysInstancedANGLE","glVertexAttribDivisorANGLE",extension_has(extensions,"GL_ANGLE_instanced_arrays")},
      {"GL_NV_instanced_arrays+GL_NV_draw_instanced","glDrawArraysInstancedNV","glVertexAttribDivisorNV",extension_has(extensions,"GL_NV_instanced_arrays")&&extension_has(extensions,"GL_NV_draw_instanced")}};
    for(const Route& route:routes)if(route.supported){
      auto draw=reinterpret_cast<PFNGLDRAWARRAYSINSTANCEDEXTPROC>(eglGetProcAddress(route.draw));
      auto divide=reinterpret_cast<PFNGLVERTEXATTRIBDIVISOREXTPROC>(eglGetProcAddress(route.divide));
      if(draw&&divide){draw_instanced=draw;divisor=divide;instance_extension=route.extension;instance_supported=max_attributes>=6;instance_fallback=instance_supported?"none":"requires_six_attributes_for_compact_instances";return;}
      instance_fallback="advertised_extension_missing_entry_points";
    }
  }
  void arrays(int mode){
    if(array_mode==mode)return;
    for(int i=0;i<std::min(max_attributes,10);++i){
      const bool instanced=(mode==2&&i>=3)||(mode==3&&i>=3&&i<6);
      if(divisor)divisor(GLuint(i),instanced?1:0);
      if(i<3||(mode==1&&i==3)||(mode==2&&i<10)||(mode==3&&i<6))glEnableVertexAttribArray(GLuint(i));else glDisableVertexAttribArray(GLuint(i));
    }
    array_mode=mode;
  }
  bool virtual_enabled() const {return config.graphics_path!=1;}
  bool qssd_enabled() const {return virtual_enabled()&&config.graphics_path!=2;}
  bool reuse_enabled() const {return qssd_enabled()&&config.graphics_path!=3;}
  bool compact_enabled() const {return virtual_enabled()&&config.graphics_path!=4;}
  bool visibility_enabled() const {return virtual_enabled()&&config.graphics_path!=5;}
  void prepare_batch(int pass,const std::vector<const Prepared*>& sequence,std::size_t begin,std::size_t end,bool instanced){
    const std::size_t index=active_batches[pass]++;
    if(index>=batches[pass].size())batches[pass].emplace_back();
    Batch& batch=batches[pass][index];batch.next_keys.clear();batch.next_keys.reserve(end-begin);
    for(std::size_t i=begin;i<end;++i)batch.next_keys.push_back(object_key(*sequence[i]));
    const int mesh=instanced?sequence[begin]->source->mesh:-1;
    // Billboard transforms depend on the eye vector. Keep their exact prepared matrix
    // representation; compact yaw/scale is only used where it is image-equivalent.
    const bool compact_now=instanced&&compact_enabled()&&mesh!=3;
    const bool layout_changed=batch.instanced!=instanced||batch.compact!=compact_now||batch.mesh!=mesh||batch.keys.size()!=batch.next_keys.size();
    batch.object_count=int(end-begin);
    if(instanced){
      batch.dirty_ranges.clear();
      if(layout_changed){
        batch.dirty_ranges.emplace_back(0,end-begin);
      }else{
        std::size_t run=end-begin;
        for(std::size_t j=0;j<end-begin;++j){
          const bool changed=batch.keys[j]!=batch.next_keys[j];
          if(changed&&run==end-begin)run=j;
          if(!changed&&run!=end-begin){batch.dirty_ranges.emplace_back(run,j);run=end-begin;}
        }
        if(run!=end-begin)batch.dirty_ranges.emplace_back(run,end-begin);
      }
      if(batch.dirty_ranges.empty())return;
      batch.instanced=true;batch.compact=compact_now;batch.mesh=mesh;
      if(batch.compact){
        batch.compact_instances.resize(end-begin);batch.instances.clear();
        for(const auto& range:batch.dirty_ranges)for(std::size_t j=range.first;j<range.second;++j)batch.compact_instances[j]=compact_instance_upload(*sequence[begin+j]);
      }else{
        batch.instances.resize(end-begin);batch.compact_instances.clear();
        for(const auto& range:batch.dirty_ranges)for(std::size_t j=range.first;j<range.second;++j)batch.instances[j]=instance_upload(*sequence[begin+j]);
      }
      batch.keys.swap(batch.next_keys);batch.vertices_dirty=true;
      return;
    }
    const bool changed=layout_changed||batch.keys!=batch.next_keys;
    if(!changed)return;
    batch.instanced=false;batch.compact=false;batch.mesh=mesh;batch.keys.swap(batch.next_keys);batch.vertices_dirty=true;batch.dirty_ranges.clear();
    batch.vertices.clear();batch.next_indices.clear();
    for(std::size_t i=begin;i<end;++i){
      const Prepared& object=*sequence[i];const Mesh& mesh_data=meshes[object.source->mesh];const std::size_t offset=batch.vertices.size();
      if(offset+mesh_data.unique.size()>chunk_vertices)throw std::logic_error("16-bit graphics chunk overflow");
      for(const Vertex& v:mesh_data.unique)batch.vertices.push_back(expanded_vertex(v,object));
      for(std::uint16_t local:mesh_data.indices)batch.next_indices.push_back(std::uint16_t(offset+local));
    }
    if(batch.indices!=batch.next_indices){batch.indices.swap(batch.next_indices);batch.indices_dirty=true;}
  }
  void prepare_batches(){
    active_batches.fill(0);if(config.graphics_path==6)return;
    const bool use_instances=instance_supported;
    const std::size_t minimum_run=2;
    for(int pass=0;pass<3;++pass){
      const auto& sequence=ordered[pass];std::size_t i=0;
      const auto run_end=[&](std::size_t start){std::size_t end=start+1;while(end<sequence.size()&&sequence[end]->source->mesh==sequence[start]->source->mesh)++end;return end;};
      while(i<sequence.size()){
        const std::size_t end=use_instances?run_end(i):i+1;
        if(use_instances&&end-i>=minimum_run){
          while(i<end){const std::size_t stop=std::min(end,i+instance_limit);prepare_batch(pass,sequence,i,stop,true);i=stop;}
        }else{
          const std::size_t start=i;std::size_t vertices=0;
          while(i<sequence.size()){
            if(i>start&&use_instances&&run_end(i)-i>=minimum_run)break;
            const auto count=meshes[sequence[i]->source->mesh].unique.size();
            if(vertices+count>chunk_vertices)break;
            vertices+=count;++i;
          }
          prepare_batch(pass,sequence,start,i,false);
        }
      }
    }
  }
  void upload(GLenum target,GLuint& name,std::size_t& capacity,const void* data,std::size_t bytes,DrawStats& stats){
    if(!name)glGenBuffers(1,&name);
    glBindBuffer(target,name);
    if(capacity<bytes){std::size_t next=256;while(next<bytes)next*=2;glBufferData(target,GLsizeiptr(next),nullptr,GL_DYNAMIC_DRAW);capacity=next;}
    glBufferSubData(target,0,GLsizeiptr(bytes),data);
    if(bytes>std::size_t(std::numeric_limits<int>::max()-stats.bytes_uploaded))throw std::overflow_error("Per-frame upload counter overflow");
    stats.bytes_uploaded+=int(bytes);
  }
  template<class T>
  void upload_instance_delta(Batch& batch,const std::vector<T>& values,DrawStats& stats){
    const std::size_t total=values.size()*sizeof(T);
    if(!batch.vbo)glGenBuffers(1,&batch.vbo);
    glBindBuffer(GL_ARRAY_BUFFER,batch.vbo);
    const bool realloc=batch.vertex_capacity<total;
    if(realloc){std::size_t next=256;while(next<total)next*=2;glBufferData(GL_ARRAY_BUFFER,GLsizeiptr(next),nullptr,GL_DYNAMIC_DRAW);batch.vertex_capacity=next;}
    std::size_t dirty=0;for(const auto& r:batch.dirty_ranges)dirty+=(r.second-r.first)*sizeof(T);
    // Large/scattered deltas are cheaper and safer as one transfer. Sparse deltas
    // preserve the retained GPU buffer and upload only the exact changed spans.
    const bool full=realloc||batch.dirty_ranges.size()>32||dirty*2>=total;
    if(full){glBufferSubData(GL_ARRAY_BUFFER,0,GLsizeiptr(total),values.data());dirty=total;}
    else for(const auto& r:batch.dirty_ranges){const std::size_t off=r.first*sizeof(T),bytes=(r.second-r.first)*sizeof(T);glBufferSubData(GL_ARRAY_BUFFER,GLintptr(off),GLsizeiptr(bytes),values.data()+r.first);}
    if(dirty>std::size_t(std::numeric_limits<int>::max()-stats.bytes_uploaded))throw std::overflow_error("Per-frame upload counter overflow");
    stats.bytes_uploaded+=int(dirty);batch.dirty_ranges.clear();
  }
  void upload_batch(Batch& batch,DrawStats& stats){
    if(batch.vertices_dirty){
      if(batch.instanced){
        if(batch.compact)upload_instance_delta(batch,batch.compact_instances,stats);
        else upload_instance_delta(batch,batch.instances,stats);
      }
      else upload(GL_ARRAY_BUFFER,batch.vbo,batch.vertex_capacity,batch.vertices.data(),batch.vertices.size()*sizeof(BatchVertex),stats);
      batch.vertices_dirty=false;
    }
    if(!batch.instanced&&batch.indices_dirty){upload(GL_ELEMENT_ARRAY_BUFFER,batch.ibo,batch.index_capacity,batch.indices.data(),batch.indices.size()*sizeof(std::uint16_t),stats);batch.indices_dirty=false;}
  }
  void init_timers(){
    if(!extension_has(reinterpret_cast<const char*>(glGetString(GL_EXTENSIONS)),"GL_EXT_disjoint_timer_query"))return;
    gen_queries=reinterpret_cast<PFNGLGENQUERIESEXTPROC>(eglGetProcAddress("glGenQueriesEXT"));
    delete_queries=reinterpret_cast<PFNGLDELETEQUERIESEXTPROC>(eglGetProcAddress("glDeleteQueriesEXT"));
    begin_query=reinterpret_cast<PFNGLBEGINQUERYEXTPROC>(eglGetProcAddress("glBeginQueryEXT"));
    end_query=reinterpret_cast<PFNGLENDQUERYEXTPROC>(eglGetProcAddress("glEndQueryEXT"));
    query_iv=reinterpret_cast<PFNGLGETQUERYIVEXTPROC>(eglGetProcAddress("glGetQueryivEXT"));
    query_uiv=reinterpret_cast<PFNGLGETQUERYOBJECTUIVEXTPROC>(eglGetProcAddress("glGetQueryObjectuivEXT"));
    query_ui64=reinterpret_cast<PFNGLGETQUERYOBJECTUI64VEXTPROC>(eglGetProcAddress("glGetQueryObjectui64vEXT"));
    timer_supported=gen_queries&&delete_queries&&begin_query&&end_query&&query_iv&&query_uiv&&query_ui64;
    if(timer_supported){GLint bits=0;query_iv(GL_TIME_ELAPSED_EXT,GL_QUERY_COUNTER_BITS_EXT,&bits);timer_supported=bits>0;}
    if(timer_supported)for(Timer& q:timers)for(GLuint& id:q.id)gen_queries(1,&id);
  }
  void poll_timer(DrawStats& stats){
    stats.gpu_timer_supported=timer_supported;if(!timer_supported)return;
    GLint disjoint=0;glGetIntegerv(GL_GPU_DISJOINT_EXT,&disjoint);
    if(disjoint){clear_timers(true);stats.gpu_discarded=timer_discarded;return;}
    Timer* oldest=nullptr;for(Timer& q:timers)if(q.pending&&(!oldest||q.serial<oldest->serial))oldest=&q;
    if(oldest){
      bool ready=true;
      for(int pass=0;pass<3;++pass)if(oldest->executed[pass]){GLuint available=0;query_uiv(oldest->id[pass],GL_QUERY_RESULT_AVAILABLE_EXT,&available);if(!available){ready=false;break;}}
      if(ready){
        std::int64_t result[3]{0,0,0};
        for(int pass=0;pass<3;++pass)if(oldest->executed[pass]){GLuint64EXT value=0;query_ui64(oldest->id[pass],GL_QUERY_RESULT_EXT,&value);result[pass]=value<=std::uint64_t(std::numeric_limits<std::int64_t>::max())?std::int64_t(value):-1;}
        glGetIntegerv(GL_GPU_DISJOINT_EXT,&disjoint);
        if(disjoint){clear_timers(true);}else if(result[0]>=0&&result[1]>=0&&result[2]>=0){
          stats.shadow_gpu_ns=result[0];stats.scene_gpu_ns=result[1];stats.screen_gpu_ns=result[2];stats.gpu_ns=result[0]+result[1]+result[2];stats.gpu_serial=oldest->serial;oldest->pending=false;
        }else{oldest->pending=false;++timer_discarded;}
      }
    }
    stats.gpu_discarded=timer_discarded;
  }
  Timer* start_timer(std::uint64_t serial){
    if(!timer_supported)return nullptr;
    for(Timer& q:timers)if(!q.pending){q.serial=serial;q.pending=true;q.active=-1;for(bool& e:q.executed)e=false;return &q;}
    ++timer_discarded;return nullptr;
  }
  void begin_pass(Timer* q,int pass){if(!q)return;q->executed[pass]=true;q->active=pass;begin_query(GL_TIME_ELAPSED_EXT,q->id[pass]);}
  void end_pass(Timer* q){if(q&&q->active>=0){end_query(GL_TIME_ELAPSED_EXT);q->active=-1;}}
  void abort_timer(Timer* q){if(!q)return;if(q->active>=0){end_query(GL_TIME_ELAPSED_EXT);q->active=-1;}q->pending=false;++timer_discarded;}
  void bind_mesh(int id){
    const Mesh& mesh=meshes[id];glBindBuffer(GL_ARRAY_BUFFER,mesh.vbo);
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),nullptr);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(3*sizeof(float)));
    glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(Vertex),reinterpret_cast<void*>(6*sizeof(float)));
  }
  void mesh_draw(int id,DrawStats& stats){glDrawArrays(GL_TRIANGLES,0,meshes[id].vertices);stats.triangles+=meshes[id].vertices/3;++stats.draw_calls;}
  void batch_draw(Batch& batch,DrawStats& stats){
    upload_batch(batch,stats);
    if(batch.instanced){
      if(batch.compact){
        arrays(3);bind_mesh(batch.mesh);glBindBuffer(GL_ARRAY_BUFFER,batch.vbo);
        glVertexAttribPointer(3,4,GL_FLOAT,GL_FALSE,sizeof(CompactInstanceUpload),reinterpret_cast<void*>(0));
        glVertexAttribPointer(4,3,GL_FLOAT,GL_FALSE,sizeof(CompactInstanceUpload),reinterpret_cast<void*>(4*sizeof(float)));
        glVertexAttribPointer(5,4,GL_FLOAT,GL_FALSE,sizeof(CompactInstanceUpload),reinterpret_cast<void*>(7*sizeof(float)));
      }else{
        arrays(2);bind_mesh(batch.mesh);glBindBuffer(GL_ARRAY_BUFFER,batch.vbo);
        for(int i=0;i<7;++i)glVertexAttribPointer(GLuint(3+i),i>=3&&i<6?3:4,GL_FLOAT,GL_FALSE,sizeof(InstanceUpload),reinterpret_cast<void*>(std::size_t(i)*4*sizeof(float)));
      }
      draw_instanced(GL_TRIANGLES,0,meshes[batch.mesh].vertices,batch.object_count);
      stats.triangles+=meshes[batch.mesh].vertices/3*batch.object_count;++stats.instanced_draws;
    }else{
      arrays(1);glBindBuffer(GL_ARRAY_BUFFER,batch.vbo);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,batch.ibo);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(BatchVertex),nullptr);
      glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(BatchVertex),reinterpret_cast<void*>(3*sizeof(float)));
      glVertexAttribPointer(2,3,GL_FLOAT,GL_FALSE,sizeof(BatchVertex),reinterpret_cast<void*>(6*sizeof(float)));
      glVertexAttribPointer(3,4,GL_FLOAT,GL_FALSE,sizeof(BatchVertex),reinterpret_cast<void*>(9*sizeof(float)));
      glDrawElements(GL_TRIANGLES,GLsizei(batch.indices.size()),GL_UNSIGNED_SHORT,nullptr);
      stats.triangles+=int(batch.indices.size()/3);++stats.batched_draws;
    }
    ++stats.draw_calls;
  }
  void set_targets(){
    if(!initialized)return;
    const int w=std::max(1,std::min(max_texture,int(std::lround(surface_width*config.resolution))));
    const int h=std::max(1,std::min(max_texture,int(std::lround(surface_height*config.resolution))));
    retained_shadow.invalidate();retained_scene_valid=false;scene.create(w,h,false);shadow.create(std::min(1024,max_texture),std::min(1024,max_texture),true);
  }
};

Renderer::Renderer():impl_(new Impl){}
Renderer::~Renderer()=default;
void Renderer::initialize(){
  Impl& p=*impl_;if(p.initialized)throw std::logic_error("Renderer already initialized");
  const auto string=[](GLenum n){const auto* v=glGetString(n);return v?std::string(reinterpret_cast<const char*>(v)):std::string();};
  p.vendor=string(GL_VENDOR);p.device=string(GL_RENDERER);p.version=string(GL_VERSION);
  if(p.version.empty())throw std::runtime_error("No current GLES context");
  GLint range[2]{},bits=0;glGetShaderPrecisionFormat(GL_FRAGMENT_SHADER,GL_HIGH_FLOAT,range,&bits);p.high_precision=bits>0;
  const std::string precision=p.high_precision?"precision highp float;\n":"precision mediump float;\n";
  glGetIntegerv(GL_MAX_VERTEX_ATTRIBS,&p.max_attributes);
  p.scene_program=program(precision,shaders::vertex,shaders::fragment);p.shadow_program=program(precision,shaders::shadow_vertex,shaders::shadow_fragment);p.screen_program=program(precision,shaders::screen_vertex,shaders::screen_fragment);
  p.batch_program=program("#define XLAB_BATCH 1\n"+precision,shaders::batch_vertex,shaders::fragment,1);
  p.batch_shadow_program=program("#define XLAB_BATCH 1\n"+precision,shaders::batch_shadow_vertex,shaders::shadow_fragment,1);
  p.init_instancing();
  if(p.instance_supported){
    try{
      p.instance_program=program("#define XLAB_INSTANCED 1\n"+precision,shaders::instanced_vertex,shaders::fragment,2);
      p.instance_shadow_program=program(precision,shaders::instanced_shadow_vertex,shaders::shadow_fragment,2);
      p.compact_instance_program=program("#define XLAB_INSTANCED 1\n"+precision,shaders::compact_instanced_vertex,shaders::fragment,3);
      p.compact_instance_shadow_program=program(precision,shaders::compact_instanced_shadow_vertex,shaders::shadow_fragment,3);
    }catch(const std::exception& error){
      if(p.instance_program)glDeleteProgram(p.instance_program);
      if(p.instance_shadow_program)glDeleteProgram(p.instance_shadow_program);
      if(p.compact_instance_program)glDeleteProgram(p.compact_instance_program);
      if(p.compact_instance_shadow_program)glDeleteProgram(p.compact_instance_shadow_program);
      p.instance_program=p.instance_shadow_program=p.compact_instance_program=p.compact_instance_shadow_program=0;p.instance_supported=false;p.instance_fallback=std::string("optional_instancing_shader_failed: ")+error.what();
    }
  }
  auto location=[](GLuint program,const char* name){return glGetUniformLocation(program,name);};
  const auto scene_uniforms=[&](GLuint id){return Impl::SceneUniforms{location(id,"uModel"),location(id,"uNormal"),location(id,"uViewProjection"),location(id,"uLightProjection"),location(id,"uShadow"),location(id,"uEye"),location(id,"uSun"),location(id,"uFog"),location(id,"uColor"),location(id,"uEnergy"),location(id,"uMesh"),location(id,"uShadowTexel")};};
  const auto shadow_uniforms=[&](GLuint id){return Impl::ShadowUniforms{location(id,"uModel"),location(id,"uLightProjection"),location(id,"uRound")};};
  p.u=scene_uniforms(p.scene_program);p.batch_u=scene_uniforms(p.batch_program);p.s=shadow_uniforms(p.shadow_program);p.batch_s=shadow_uniforms(p.batch_shadow_program);
  if(p.instance_supported){
    p.instance_u=scene_uniforms(p.instance_program);p.instance_s=shadow_uniforms(p.instance_shadow_program);
    p.compact_u=scene_uniforms(p.compact_instance_program);p.compact_s=shadow_uniforms(p.compact_instance_shadow_program);
  }
  p.image=location(p.screen_program,"uImage");
  for(int id=0;id<5;++id){
    const auto vertices=mesh_data(id);auto& mesh=p.meshes[id];mesh.vertices=int(vertices.size());
    glGenBuffers(1,&mesh.vbo);glBindBuffer(GL_ARRAY_BUFFER,mesh.vbo);glBufferData(GL_ARRAY_BUFFER,vertices.size()*sizeof(Vertex),vertices.data(),GL_STATIC_DRAW);p.pending_upload+=int(vertices.size()*sizeof(Vertex));
    std::map<std::array<std::uint32_t,8>,std::uint16_t> unique;
    for(const Vertex& vertex:vertices){
      std::array<std::uint32_t,8> key{};static_assert(sizeof(key)==sizeof(Vertex));std::memcpy(key.data(),&vertex,sizeof(vertex));
      const auto found=unique.find(key);
      if(found!=unique.end())mesh.indices.push_back(found->second);
      else{const auto index=std::uint16_t(mesh.unique.size());unique.emplace(key,index);mesh.unique.push_back(vertex);mesh.indices.push_back(index);}
    }
  }
  glGetIntegerv(GL_MAX_TEXTURE_SIZE,&p.max_texture);if(p.max_texture<256)throw std::runtime_error("Insufficient GLES texture dimensions");
  p.init_timers();p.initialized=true;p.set_targets();p.arrays(0);check_gl("Initialize renderer");
}
void Renderer::resize(int width,int height){
  if(width<1||height<1||width>16384||height>16384)throw std::invalid_argument("Invalid physical surface size");
  Impl& p=*impl_;p.surface_width=width;p.surface_height=height;p.clear_timers(true);p.set_targets();
}
void Renderer::configure(const Config& config){
  if(!std::isfinite(config.resolution)||config.resolution<.25f||config.resolution>1.f)throw std::invalid_argument("Render resolution must be between 0.25 and 1.0");
  if(config.graphics_path<0||config.graphics_path>6)throw std::invalid_argument("Graphics path/ablation must be 0..6");
  Impl& p=*impl_;p.config=config;p.clear_batches();p.clear_timers(false);p.timer_discarded=0;p.retained_shadow.invalidate();p.retained_scene_valid=false;p.work_authority.reset();p.work_memory.reset(8);p.set_targets();
}
DrawStats Renderer::draw(const Packet& packet,std::uint64_t frame_serial){
  Impl& p=*impl_;if(!p.initialized)throw std::logic_error("Renderer has no context");
  DrawStats stats;stats.bytes_uploaded=p.pending_upload;p.pending_upload=0;const auto begin=monotonic_ns();
  const V3 eye=vec(packet.eye),look=vec(packet.look),sun=norm(vec(packet.sun)),forward=norm(sub(look,eye));
  const M4 view_projection=product(perspective(float(p.surface_width)/p.surface_height),look_at(eye,look));
  const float span=std::max(22.f,std::min(120.f,length(sub(eye,look))*1.8f));
  const V3 light_eye=add(look,mul(sun,span*1.5f));
  const M4 light_projection=product(ortho(span,.1f,span*4),look_at(light_eye,look));
  const auto camera_planes=frustum(view_projection),light_planes=frustum(light_projection);
  p.prepared.clear();p.prepared.reserve(packet.objects.size());for(auto& sequence:p.ordered)sequence.clear();
  std::vector<xgpu::PhysicalCandidate> candidates;candidates.reserve(packet.objects.size());
  for(const Instance& object:packet.objects){
    if(object.a<=.001f)continue;
    p.prepared.push_back(prepare(object,eye,forward,camera_planes,light_planes));
    const Prepared& prepared=p.prepared.back();
    const float distance=std::max(.15f,std::abs(prepared.distance));
    const float camera_diameter=prepared.radius/(distance*std::tan(26.f*pi/180.f))*float(p.scene.height);
    const float shadow_diameter=prepared.radius/std::max(1.f,span)*float(p.shadow.height);
    candidates.push_back({object.id,object.transform_revision,object.material_revision,std::uint32_t(object.mesh),camera_diameter,shadow_diameter,prepared.camera_visible,prepared.shadow_visible});
  }
  std::vector<std::uint32_t> mesh_vertices;mesh_vertices.reserve(p.meshes.size());for(const auto& mesh:p.meshes)mesh_vertices.push_back(std::uint32_t(mesh.vertices));
  std::uint64_t dependency_revision=matrix_revision(view_projection);dependency_revision^=matrix_revision(light_projection)+0x9e3779b97f4a7c15ULL+(dependency_revision<<6)+(dependency_revision>>2);dependency_revision^=std::uint64_t(p.scene.width)<<32|std::uint32_t(p.scene.height);
  const auto plan=p.work_authority.plan(candidates,mesh_vertices,dependency_revision,p.compact_enabled(),p.reuse_enabled(),p.visibility_enabled());
  for(std::uint32_t index:plan.shadow_indices){const Prepared& object=p.prepared[index];p.ordered[0].push_back(&object);}
  for(std::uint32_t index:plan.camera_indices){const Prepared& object=p.prepared[index];p.ordered[object.source->a<.995f||object.source->mesh==3?2:1].push_back(&object);}
  std::stable_sort(p.ordered[2].begin(),p.ordered[2].end(),[](const Prepared* a,const Prepared* b){return a->distance>b->distance;});
  stats.camera_instances=int(p.ordered[1].size()+p.ordered[2].size());stats.shadow_instances=int(p.ordered[0].size());
  stats.pwr_baseline_objects=plan.camera_candidates+plan.shadow_candidates;
  stats.pwr_baseline_vertices=plan.baseline_vertex_invocations;
  stats.pwr_baseline_fragments=plan.baseline_fragment_estimate;
  stats.pwr_baseline_bytes=plan.baseline_instance_bytes;stats.reused_objects=plan.reused_objects;stats.changed_objects=plan.changed_objects;
  p.prepare_batches();stats.geometry_ns=monotonic_ns()-begin;
  ShadowDelta candidate;candidate.valid=true;candidate.projection=light_projection;
  candidate.casters.reserve(p.ordered[0].size());
  for(const Prepared* object:p.ordered[0]){std::array<float,17> key{};std::copy(object->model.begin(),object->model.end(),key.begin());key[16]=float(object->source->mesh);candidate.casters.push_back(key);}
  const bool qssd_completed=p.qssd_enabled()&&p.work_memory.snapshot()->value->completed_revision!=0;
  const bool reuse_shadow=p.reuse_enabled()&&qssd_completed&&candidate.matches(p.retained_shadow);
  const bool reuse_scene=p.reuse_enabled()&&qssd_completed&&p.retained_scene_valid&&p.retained_scene_hash==packet.state_hash;
  stats.shadow_pass_avoided=reuse_shadow?1:0;stats.scene_pass_avoided=reuse_scene?1:0;
  const std::uint64_t camera_instances=plan.camera_indices.size(),shadow_instances=plan.shadow_indices.size();
  const std::uint64_t physical_camera_instances=reuse_scene?0:camera_instances;
  const std::uint64_t physical_shadow_instances=reuse_shadow?0:shadow_instances;
  stats.pwr_planned_objects=physical_camera_instances+physical_shadow_instances;
  stats.pwr_planned_vertices=(reuse_scene?0:plan.camera_planned_vertices)+(reuse_shadow?0:plan.shadow_planned_vertices);
  stats.pwr_planned_fragments=(reuse_scene?0:plan.camera_planned_fragments)+(reuse_shadow?0:plan.shadow_planned_fragments);
  stats.pwr_planned_bytes=(reuse_scene?0:plan.camera_planned_bytes)+(reuse_shadow?0:plan.shadow_planned_bytes);

  const auto submit_begin=monotonic_ns();p.poll_timer(stats);Impl::Timer* timer=p.start_timer(frame_serial);
  try{
    if(!reuse_shadow)p.retained_shadow.invalidate();
    glDisable(GL_BLEND);glEnable(GL_DEPTH_TEST);glDepthFunc(GL_LEQUAL);glDepthMask(GL_TRUE);glEnable(GL_CULL_FACE);glCullFace(GL_BACK);glFrontFace(GL_CCW);
    if(!reuse_shadow){
    p.begin_pass(timer,0);
    glBindFramebuffer(GL_FRAMEBUFFER,p.shadow.fbo);glViewport(0,0,p.shadow.width,p.shadow.height);glClearColor(1,1,1,1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glEnable(GL_POLYGON_OFFSET_FILL);glPolygonOffset(1.2f,2.f);
    if(p.config.graphics_path==6){
      p.arrays(0);glUseProgram(p.shadow_program);glUniformMatrix4fv(p.s.light,1,GL_FALSE,light_projection.data());
      for(const Prepared* object:p.ordered[0]){
        const auto& source=*object->source;p.bind_mesh(source.mesh);glUniformMatrix4fv(p.s.model,1,GL_FALSE,object->model.data());glUniform1f(p.s.round,source.mesh==3?1.f:0.f);p.mesh_draw(source.mesh,stats);++stats.reference_draws;
      }
    }else{
      GLuint current=0;
      for(std::size_t i=0;i<p.active_batches[0];++i){
        auto& batch=p.batches[0][i];const GLuint program_id=batch.instanced?(batch.compact?p.compact_instance_shadow_program:p.instance_shadow_program):p.batch_shadow_program;const auto& uniforms=batch.instanced?(batch.compact?p.compact_s:p.instance_s):p.batch_s;
        if(current!=program_id){glUseProgram(program_id);glUniformMatrix4fv(uniforms.light,1,GL_FALSE,light_projection.data());current=program_id;}
        if(batch.instanced)glUniform1f(uniforms.round,batch.mesh==3?1.f:0.f);
        p.batch_draw(batch,stats);
      }
    }
    glDisable(GL_POLYGON_OFFSET_FILL);
    p.end_pass(timer);
    }
    if(!reuse_scene){
    p.begin_pass(timer,1);
    glBindFramebuffer(GL_FRAMEBUFFER,p.scene.fbo);glViewport(0,0,p.scene.width,p.scene.height);glClearColor(packet.fog[0],packet.fog[1],packet.fog[2],1);glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,p.shadow.color);
    const auto scene_uniforms=[&](GLuint program_id,const Impl::SceneUniforms& uniforms){
      glUseProgram(program_id);glUniform1i(uniforms.shadow,0);
      glUniformMatrix4fv(uniforms.view,1,GL_FALSE,view_projection.data());glUniformMatrix4fv(uniforms.light,1,GL_FALSE,light_projection.data());glUniform3f(uniforms.eye,eye.x,eye.y,eye.z);glUniform3f(uniforms.sun,sun.x,sun.y,sun.z);glUniform3fv(uniforms.fog,1,packet.fog.data());glUniform1f(uniforms.energy,std::clamp(packet.light_energy,.15f,2.f));glUniform2f(uniforms.texel,1.f/p.shadow.width,1.f/p.shadow.height);
    };
    GLuint current=0;
    const auto scene_pass=[&](int pass){
      if(p.config.graphics_path==6){
        p.arrays(0);if(current!=p.scene_program){scene_uniforms(p.scene_program,p.u);current=p.scene_program;}
        for(const Prepared* object:p.ordered[pass]){
          const auto& source=*object->source;p.bind_mesh(source.mesh);
          glUniformMatrix4fv(p.u.model,1,GL_FALSE,object->model.data());glUniformMatrix3fv(p.u.normal,1,GL_FALSE,object->normal.data());glUniform4f(p.u.color,source.r,source.g,source.b,std::clamp(source.a,0.f,1.f));glUniform1f(p.u.mesh,float(source.mesh));p.mesh_draw(source.mesh,stats);++stats.reference_draws;
        }
      }else{
        for(std::size_t i=0;i<p.active_batches[pass];++i){
          auto& batch=p.batches[pass][i];const GLuint program_id=batch.instanced?(batch.compact?p.compact_instance_program:p.instance_program):p.batch_program;const auto& uniforms=batch.instanced?(batch.compact?p.compact_u:p.instance_u):p.batch_u;
          if(current!=program_id){scene_uniforms(program_id,uniforms);current=program_id;}
          if(batch.instanced)glUniform1f(uniforms.mesh,float(batch.mesh));
          p.batch_draw(batch,stats);
        }
      }
    };
    scene_pass(1);
    glEnable(GL_BLEND);glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);glDepthMask(GL_FALSE);glDisable(GL_CULL_FACE);scene_pass(2);
    glDisable(GL_BLEND);glDisable(GL_DEPTH_TEST);glDepthMask(GL_TRUE);
    p.end_pass(timer);
    p.retained_scene_hash=packet.state_hash;p.retained_scene_valid=true;
    }
    p.begin_pass(timer,2);
    glBindFramebuffer(GL_FRAMEBUFFER,0);glViewport(0,0,p.surface_width,p.surface_height);glUseProgram(p.screen_program);glActiveTexture(GL_TEXTURE0);glBindTexture(GL_TEXTURE_2D,p.scene.color);glUniform1i(p.image,0);p.arrays(0);p.bind_mesh(3);p.mesh_draw(3,stats);
    p.end_pass(timer);
    check_gl("Draw scene and present adapter");
    if(!reuse_shadow)p.retained_shadow=std::move(candidate);
    if(p.qssd_enabled())p.work_memory.publish(plan,dependency_revision,frame_serial);
  }catch(...){p.abort_timer(timer);throw;}
  stats.submit_ns=monotonic_ns()-submit_begin;stats.width=p.scene.width;stats.height=p.scene.height;stats.gpu_discarded=p.timer_discarded;return stats;
}
std::string Renderer::capabilities() const {
  const Impl& p=*impl_;std::ostringstream s;
  s<<"{\"adapter\":\"xlab-gles2-physical-adapter\",\"world_owner\":\"original_backend_packet\",\"gl_vendor\":"<<json_string(p.vendor)<<",\"gl_renderer\":"<<json_string(p.device)<<",\"gl_version\":"<<json_string(p.version)
   <<",\"requested_graphics_path\":"<<p.config.graphics_path<<",\"graphics_route\":"<<json_string(p.config.graphics_path==6?"reference_per_object":p.instance_supported?"ordered_instancing_and_retained_batches":"retained_gles2_batches")
   <<",\"instancing_supported\":"<<(p.instance_supported?"true":"false")<<",\"instancing_extension\":"<<json_string(p.instance_extension)<<",\"instancing_fallback\":"<<json_string(p.instance_fallback)<<",\"max_vertex_attributes\":"<<p.max_attributes
   <<",\"retained_batch_buffers\":true,\"batch_max_vertices\":"<<Impl::chunk_vertices<<",\"batch_index_bits\":16,\"instance_chunk_limit\":"<<Impl::instance_limit<<",\"primitive_order_preserved\":true,\"upload_bytes_scope\":\"mesh initialization plus changed batch/instance payload; allocation padding excluded\""
   <<",\"gles_shader_version\":100,\"retained_mesh_buffers\":true,\"alpha_sorted_back_to_front\":true,\"camera_frustum_culling\":true,\"offscreen_shadow_casters\":true,\"directional_shadow_map\":true,\"shadow_cascades\":1,\"shadow_resolution\":"<<p.shadow.width
   <<",\"shadow_storage\":\"RGBA8 packed RG depth; opaque casters; four-sample PCF\",\"fragment_highp\":"<<(p.high_precision?"true":"false")<<",\"gpu_timer_supported\":"<<(p.timer_supported?"true":"false")
   <<",\"gpu_timer_scope\":\"three asynchronous non-overlapping elapsed queries: shadow, scene and final screen pass; total is their sum; excludes swap and Android compositor; paired by original serial; disjoint discarded\""
   <<",\"physical_work_authority\":"<<(p.virtual_enabled()?"true":"false")
   <<",\"qssd_graphics_work_memory\":"<<(p.qssd_enabled()?"true":"false")
   <<",\"temporal_reuse\":"<<(p.reuse_enabled()?"true":"false")
   <<",\"compact_instances\":"<<(p.compact_enabled()?"true":"false")
   <<",\"visibility_criterion\":"<<(p.visibility_enabled()?"\"0.5 projected pixel/texel diameter\"":"null")
   <<",\"pwr_scope\":\"objects/vertices/fragment-area-estimate/instance-bytes for camera+shadow object work only; screen composition is outside the denominator\""
   <<",\"render_resolution_scale\":"<<p.config.resolution<<",\"render_width\":"<<p.scene.width<<",\"render_height\":"<<p.scene.height<<"}";return s.str();
}
} // namespace xlab
