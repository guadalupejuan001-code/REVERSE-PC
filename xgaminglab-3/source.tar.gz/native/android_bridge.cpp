#include "lab_api.hpp"
#include "lab_gl_util.hpp"
#include "presentation_tracker.hpp"
#include "component_lab.hpp"
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <jni.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <memory>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <unordered_map>

namespace {
using namespace xlab;
std::atomic<std::uint64_t> next_context{1};
std::atomic<jlong> next_handle{1};

// Same admission boundary as Backend: a vsync sample can precede a touch that
// arrived before the worker drew it. Do not count that touch until it is causal.
struct InputAdmission {
  std::int64_t origin_ns=0,sampled_ns=0,last_event_ns=0;
  void reset(std::int64_t now_ns){origin_ns=sampled_ns=now_ns;last_event_ns=0;}
  std::int64_t advance(std::int64_t frame_ns){sampled_ns=std::max(sampled_ns,frame_ns);return sampled_ns;}
  bool consume(std::int64_t event_ns){
    if(event_ns<=last_event_ns||event_ns<origin_ns||event_ns>sampled_ns)return false;
    last_event_ns=event_ns;return true;
  }
};

std::string egl_failure(const char* action){
  std::ostringstream out;out<<action<<" (EGL 0x"<<std::hex<<eglGetError()<<")";return out.str();
}
struct Session {
  const std::thread::id owner=std::this_thread::get_id();
  const std::uint64_t generation=next_context.fetch_add(1);
  ANativeWindow* window=nullptr;
  EGLDisplay display=EGL_NO_DISPLAY;
  EGLContext context=EGL_NO_CONTEXT;
  EGLSurface surface=EGL_NO_SURFACE;
  EGLConfig egl_config=nullptr;
  std::unique_ptr<Backend> backend;
  std::unique_ptr<Renderer> renderer;
  Config config{};
  int width=1,height=1,egl_major=0,egl_minor=0,min_swap_interval=-1,max_swap_interval=-1;
  bool initialized=false,lost=false,present_supported=false,presentation_hint_supported=false;
  bool swap_request_accepted=false,last_hint_accepted=false;
  std::string egl_vendor,egl_version;
  std::uint64_t serial=0,input_events=0;
  InputAdmission input_admission;
  PFNEGLGETNEXTFRAMEIDANDROIDPROC next_frame_id=nullptr;
  PFNEGLGETFRAMETIMESTAMPSANDROIDPROC get_timestamps=nullptr;
  PFNEGLGETFRAMETIMESTAMPSUPPORTEDANDROIDPROC timestamp_supported=nullptr;
  PFNEGLPRESENTATIONTIMEANDROIDPROC presentation_time=nullptr;
  PresentationTracker presentations;

  ~Session(){shutdown();}
  void check_owner() const {
    if(owner!=std::this_thread::get_id())throw std::logic_error("NativeBridge must be used and closed on its EGL render thread");
  }
  void require_surface() const {
    check_owner();if(lost||!initialized)throw std::runtime_error("EGL surface lost; close this handle and create a new surface session");
  }
  void shutdown(){
    // Java serializes create/frame/configure/close on its one render thread.
    // No finalizer or UI thread is allowed to delete a live EGL context.
    renderer.reset();backend.reset();presentations.reset();
    if(display!=EGL_NO_DISPLAY){
      if(context!=EGL_NO_CONTEXT)eglMakeCurrent(display,EGL_NO_SURFACE,EGL_NO_SURFACE,EGL_NO_CONTEXT);
      if(surface!=EGL_NO_SURFACE)eglDestroySurface(display,surface);
      if(context!=EGL_NO_CONTEXT)eglDestroyContext(display,context);
      if(initialized)eglTerminate(display);
    }
    surface=EGL_NO_SURFACE;context=EGL_NO_CONTEXT;display=EGL_NO_DISPLAY;initialized=false;
    if(window){ANativeWindow_release(window);window=nullptr;}
  }
  void init(JNIEnv* env,jobject java_surface){
    if(!java_surface)throw std::invalid_argument("Surface is required");
    window=ANativeWindow_fromSurface(env,java_surface);if(!window)throw std::runtime_error("Surface has no native window");
    display=eglGetDisplay(EGL_DEFAULT_DISPLAY);if(display==EGL_NO_DISPLAY)throw std::runtime_error(egl_failure("eglGetDisplay failed"));
    if(!eglInitialize(display,&egl_major,&egl_minor))throw std::runtime_error(egl_failure("eglInitialize failed"));initialized=true;
    const EGLint attributes[]={EGL_SURFACE_TYPE,EGL_WINDOW_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_ES2_BIT,EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_DEPTH_SIZE,16,EGL_STENCIL_SIZE,0,EGL_NONE};
    EGLint count=0;if(!eglChooseConfig(display,attributes,&egl_config,1,&count)||count<1)throw std::runtime_error(egl_failure("No GLES2 window configuration"));
    EGLint visual=0;eglGetConfigAttrib(display,egl_config,EGL_NATIVE_VISUAL_ID,&visual);
    eglGetConfigAttrib(display,egl_config,EGL_MIN_SWAP_INTERVAL,&min_swap_interval);eglGetConfigAttrib(display,egl_config,EGL_MAX_SWAP_INTERVAL,&max_swap_interval);
    if(ANativeWindow_setBuffersGeometry(window,0,0,visual)<0)throw std::runtime_error("Unable to set native surface pixel format");
    if(!eglBindAPI(EGL_OPENGL_ES_API))throw std::runtime_error(egl_failure("eglBindAPI failed"));
    const EGLint context_attributes[]={EGL_CONTEXT_CLIENT_VERSION,2,EGL_NONE};
    context=eglCreateContext(display,egl_config,EGL_NO_CONTEXT,context_attributes);if(context==EGL_NO_CONTEXT)throw std::runtime_error(egl_failure("eglCreateContext failed"));
    surface=eglCreateWindowSurface(display,egl_config,window,nullptr);if(surface==EGL_NO_SURFACE)throw std::runtime_error(egl_failure("eglCreateWindowSurface failed"));
    if(!eglMakeCurrent(display,surface,surface,context))throw std::runtime_error(egl_failure("eglMakeCurrent failed"));
    eglQuerySurface(display,surface,EGL_WIDTH,&width);eglQuerySurface(display,surface,EGL_HEIGHT,&height);width=std::max(1,width);height=std::max(1,height);
    const auto egl_text=[&](EGLint name){const char* text=eglQueryString(display,name);return text?std::string(text):std::string();};
    egl_vendor=egl_text(EGL_VENDOR);egl_version=egl_text(EGL_VERSION);
    const std::string extensions=egl_text(EGL_EXTENSIONS);
    if(extension_has(extensions.c_str(),"EGL_ANDROID_get_frame_timestamps")){
      next_frame_id=reinterpret_cast<PFNEGLGETNEXTFRAMEIDANDROIDPROC>(eglGetProcAddress("eglGetNextFrameIdANDROID"));
      get_timestamps=reinterpret_cast<PFNEGLGETFRAMETIMESTAMPSANDROIDPROC>(eglGetProcAddress("eglGetFrameTimestampsANDROID"));
      timestamp_supported=reinterpret_cast<PFNEGLGETFRAMETIMESTAMPSUPPORTEDANDROIDPROC>(eglGetProcAddress("eglGetFrameTimestampSupportedANDROID"));
      present_supported=next_frame_id&&get_timestamps&&timestamp_supported&&
        eglSurfaceAttrib(display,surface,EGL_TIMESTAMPS_ANDROID,EGL_TRUE)&&
        timestamp_supported(display,surface,EGL_DISPLAY_PRESENT_TIME_ANDROID);
    }
    if(extension_has(extensions.c_str(),"EGL_ANDROID_presentation_time")){
      presentation_time=reinterpret_cast<PFNEGLPRESENTATIONTIMEANDROIDPROC>(eglGetProcAddress("eglPresentationTimeANDROID"));presentation_hint_supported=presentation_time!=nullptr;
    }
    backend.reset(new Backend);renderer.reset(new Renderer);renderer->initialize();renderer->resize(width,height);
    configure(config);
  }
  void configure(const Config& next){
    require_surface();
    if(next.scene<CALIBRATION||next.scene>OFFSCREEN||next.load<0||next.load>4||next.target_hz<1||next.target_hz>1000||next.graphics_path<0||next.graphics_path>6||!std::isfinite(next.resolution)||next.resolution<.25f||next.resolution>1.f)
      throw std::invalid_argument("Invalid scene, load, refresh target or resolution");
    config=next;const std::int64_t origin=monotonic_ns();
    backend->configure(config,origin);input_admission.reset(origin);renderer->configure(config);
    swap_request_accepted=eglSwapInterval(display,config.coordinated?1:0)==EGL_TRUE;
    presentations.reset();serial=0;input_events=0;last_hint_accepted=false;
  }
  void resize(int w,int h){
    require_surface();renderer->resize(w,h);width=w;height=h;presentations.discard_pending();
  }
  void poll_present(double* metrics,std::int64_t now){
    if(!present_supported)return;
    const auto sample=presentations.poll(now,[&](std::uint64_t egl_id){
      const EGLint name=EGL_DISPLAY_PRESENT_TIME_ANDROID;EGLnsecsANDROID value=EGL_TIMESTAMP_PENDING_ANDROID;
      if(!get_timestamps(display,surface,egl_id,1,&name,&value)||value==EGL_TIMESTAMP_INVALID_ANDROID)
        return PresentationTracker::Read{PresentationTracker::State::invalid,-1};
      if(value==EGL_TIMESTAMP_PENDING_ANDROID)return PresentationTracker::Read{};
      return PresentationTracker::Read{PresentationTracker::State::measured,value};
    });
    metrics[PRESENT_NS]=double(sample.time_ns);metrics[PRESENT_ID]=double(sample.serial);
  }
  void frame(std::int64_t frame_time,std::int64_t expected,std::int64_t input_ns,float x,float y,bool pressed,double* metrics){
    require_surface();
    const std::int64_t begin=monotonic_ns();
    if(frame_time<=0)frame_time=begin;
    frame_time=input_admission.advance(frame_time);
    if(!std::isfinite(x)||!std::isfinite(y))throw std::invalid_argument("Non-finite input position");
    std::fill(metrics,metrics+METRIC_COUNT,0.0);metrics[GPU_NS]=-1;metrics[PRESENT_NS]=-1;metrics[INPUT_TO_SUBMIT_NS]=-1;
    const std::uint64_t this_serial=++serial;
    const Input input{x,y,input_ns,pressed};const Packet& packet=backend->sample(frame_time,input);
    const bool fresh_input=input_admission.consume(input_ns);
    if(fresh_input)++input_events;
    const DrawStats draw=renderer->draw(packet,this_serial);const std::int64_t submitted=monotonic_ns();
    EGLuint64KHR egl_id=0;const bool has_id=present_supported&&next_frame_id(display,surface,&egl_id);
    if(presentation_hint_supported&&expected>0)last_hint_accepted=presentation_time(display,surface,expected)==EGL_TRUE;
    else last_hint_accepted=false;
    const std::int64_t swap_begin=monotonic_ns();const bool swapped=eglSwapBuffers(display,surface)==EGL_TRUE;const std::int64_t swap_end=monotonic_ns();
    std::string failure;if(!swapped){failure=egl_failure("eglSwapBuffers failed; surface session must be recreated");lost=true;}
    if(swapped&&present_supported){
      if(has_id)presentations.submitted(egl_id,this_serial,swap_end);
      else presentations.untracked_swap();
      poll_present(metrics,swap_end);
    }
    metrics[SERIAL]=double(this_serial);metrics[SOURCE_REVISION]=double(packet.source_revision);metrics[BEGIN_NS]=double(begin);
    metrics[CPU_NS]=double(packet.cpu_ns);metrics[QSSD_NS]=double(packet.qssd_ns);metrics[VIRTUAL_GPU_NS]=double(packet.virtual_gpu_ns);
    metrics[GEOMETRY_NS]=double(draw.geometry_ns);metrics[DRAW_SUBMIT_NS]=double(draw.submit_ns);metrics[SWAP_NS]=double(swap_end-swap_begin);
    metrics[GPU_NS]=double(draw.gpu_ns);metrics[GPU_SAMPLE_ID]=double(draw.gpu_serial);metrics[GPU_DISCARDED]=double(draw.gpu_discarded);
    metrics[PRESENT_PENDING]=double(presentations.pending());metrics[PRESENT_LOST]=double(presentations.lost());metrics[PRESENT_PROCESSED]=double(presentations.processed());metrics[PRESENT_DISCARDED]=double(presentations.discarded());
    metrics[OBJECTS]=double(packet.objects.size());metrics[TRIANGLES]=draw.triangles;metrics[DRAW_CALLS]=draw.draw_calls;metrics[WORK_ITEMS]=packet.work_items;metrics[PHYSICS_STEPS]=packet.physics_steps;
    metrics[STATE_AGE_NS]=double(std::max<std::int64_t>(0,submitted-packet.source_ns));
    if(fresh_input&&input_ns<=submitted)metrics[INPUT_TO_SUBMIT_NS]=double(submitted-input_ns);
    metrics[RENDER_WIDTH]=draw.width;metrics[RENDER_HEIGHT]=draw.height;metrics[SURFACE_WIDTH]=width;metrics[SURFACE_HEIGHT]=height;
    metrics[CACHE_HITS]=packet.cache_hits;metrics[CACHE_MISSES]=packet.cache_misses;metrics[UPLOAD_BYTES]=draw.bytes_uploaded;
    metrics[PRESENT_SUPPORTED]=present_supported?1:0;metrics[GPU_TIMER_SUPPORTED]=draw.gpu_timer_supported?1:0;metrics[CONTEXT_GENERATION]=double(generation);
    // IEEE double stores all 53 bits exactly. This field is an explicit compact fingerprint.
    metrics[STATE_HASH]=double(packet.state_hash&((std::uint64_t(1)<<53)-1));metrics[INPUT_EVENTS]=double(input_events);
    metrics[PREPARED_REGIONS]=packet.prepared_regions;metrics[HOT_REGION_BUILDS]=packet.hot_region_builds;metrics[BUDGET_NS]=1e9/config.target_hz;metrics[SWAP_SUCCEEDED]=swapped?1:0;
    metrics[AUDIO_HZ]=packet.audio_hz;metrics[AUDIO_GAIN]=packet.audio_gain;
    metrics[CAMERA_INSTANCES]=draw.camera_instances;metrics[SHADOW_INSTANCES]=draw.shadow_instances;
    metrics[INSTANCED_DRAWS]=draw.instanced_draws;metrics[BATCHED_DRAWS]=draw.batched_draws;metrics[REFERENCE_DRAWS]=draw.reference_draws;metrics[GRAPHICS_PATH]=config.graphics_path;
    metrics[QUANTUM_GATES]=double(packet.quantum_gates);metrics[QUANTUM_CIRCUITS]=double(packet.quantum_circuits);metrics[QUANTUM_QUBITS]=packet.quantum_qubits;metrics[QUANTUM_SIGNAL]=packet.quantum_signal;
    metrics[SHADOW_GPU_NS]=double(draw.shadow_gpu_ns);metrics[SCENE_GPU_NS]=double(draw.scene_gpu_ns);metrics[SCREEN_GPU_NS]=double(draw.screen_gpu_ns);
    metrics[PWR_BASELINE_OBJECTS]=double(draw.pwr_baseline_objects);metrics[PWR_PLANNED_OBJECTS]=double(draw.pwr_planned_objects);
    metrics[PWR_BASELINE_VERTICES]=double(draw.pwr_baseline_vertices);metrics[PWR_PLANNED_VERTICES]=double(draw.pwr_planned_vertices);
    metrics[PWR_BASELINE_FRAGMENTS]=double(draw.pwr_baseline_fragments);metrics[PWR_PLANNED_FRAGMENTS]=double(draw.pwr_planned_fragments);
    metrics[PWR_BASELINE_BYTES]=double(draw.pwr_baseline_bytes);metrics[PWR_PLANNED_BYTES]=double(draw.pwr_planned_bytes);
    metrics[REUSED_OBJECTS]=double(draw.reused_objects);metrics[CHANGED_OBJECTS]=double(draw.changed_objects);
    metrics[SHADOW_PASS_AVOIDED]=double(draw.shadow_pass_avoided);metrics[SCENE_PASS_AVOIDED]=double(draw.scene_pass_avoided);
    metrics[END_NS]=double(monotonic_ns());
    if(!swapped)throw std::runtime_error(failure);
  }
  std::string capabilities() const {
    check_owner();std::ostringstream out;
    out<<"{\"schema\":1,\"clock\":\"CLOCK_MONOTONIC; Java System.nanoTime and frame/input timestamps\",\"context_generation\":"<<generation
       <<",\"egl_vendor\":"<<json_string(egl_vendor)<<",\"egl_version\":"<<json_string(egl_version)<<",\"gles_context_requested\":2"
       <<",\"present_timestamps_supported\":"<<(present_supported?"true":"false")<<",\"present_timestamp_kind\":\"EGL_DISPLAY_PRESENT_TIME_ANDROID; never expected-time substitute\""
       <<",\"presentation_hint_supported\":"<<(presentation_hint_supported?"true":"false")<<",\"last_hint_accepted\":"<<(last_hint_accepted?"true":"false")
       <<",\"swap_interval_requested\":"<<(config.coordinated?1:0)<<",\"swap_interval_request_accepted\":"<<(swap_request_accepted?"true":"false")<<",\"config_min_swap_interval\":"<<min_swap_interval<<",\"config_max_swap_interval\":"<<max_swap_interval
       <<",\"effective_swap_interval_measured\":false,\"direct_mode_may_be_hardware_throttled\":true,\"state_hash_bits\":53,\"input_events_scope\":\"monotonic event timestamps accepted at backend sample time; not all OS touch samples\""
       <<",\"backend_provenance\":"<<json_string(backend?backend->provenance():std::string("unavailable"))<<",\"renderer\":"<<(renderer?renderer->capabilities():"null")<<"}";return out.str();
  }
};
std::mutex registry_mutex;
std::unordered_map<jlong,std::shared_ptr<Session>> sessions;
std::shared_ptr<Session> lookup(jlong handle){
  std::lock_guard<std::mutex> lock(registry_mutex);auto it=sessions.find(handle);
  if(it==sessions.end())throw std::invalid_argument("Closed or unknown native lab handle");return it->second;
}
void throw_java(JNIEnv* env,const std::exception& error){
  if(env->ExceptionCheck())return;jclass type=env->FindClass("java/lang/IllegalStateException");if(type)env->ThrowNew(type,error.what());
}
} // namespace

extern "C" JNIEXPORT jlong JNICALL Java_x_lab_gaming_NativeBridge_create(JNIEnv* env,jclass,jobject surface){
  try{auto session=std::make_shared<Session>();session->init(env,surface);const jlong id=next_handle.fetch_add(1);std::lock_guard<std::mutex> lock(registry_mutex);sessions.emplace(id,session);return id;}
  catch(const std::exception& error){throw_java(env,error);return 0;}
}
extern "C" JNIEXPORT void JNICALL Java_x_lab_gaming_NativeBridge_resize(JNIEnv* env,jclass,jlong handle,jint width,jint height){
  try{lookup(handle)->resize(width,height);}catch(const std::exception& error){throw_java(env,error);}
}
extern "C" JNIEXPORT void JNICALL Java_x_lab_gaming_NativeBridge_configure(JNIEnv* env,jclass,jlong handle,jint scene,jint load,jboolean coordinated,jfloat resolution,jint target_hz,jint graphics_path){
  try{Config config;config.scene=scene;config.load=load;config.coordinated=coordinated;config.resolution=resolution;config.target_hz=target_hz;config.graphics_path=graphics_path;lookup(handle)->configure(config);}catch(const std::exception& error){throw_java(env,error);}
}
extern "C" JNIEXPORT void JNICALL Java_x_lab_gaming_NativeBridge_frame(JNIEnv* env,jclass,jlong handle,jlong frame_time,jlong expected,jlong input_ns,jfloat x,jfloat y,jboolean pressed,jobject buffer){
  try{
    if(!buffer)throw std::invalid_argument("Metrics require a native-order direct ByteBuffer");
    void* address=env->GetDirectBufferAddress(buffer);const jlong capacity=env->GetDirectBufferCapacity(buffer);
    if(!address||capacity<jlong(METRIC_COUNT*sizeof(double))||reinterpret_cast<std::uintptr_t>(address)%alignof(double))throw std::invalid_argument("Metrics buffer must hold 80 aligned native doubles");
    lookup(handle)->frame(frame_time,expected,input_ns,x,y,pressed,static_cast<double*>(address));
  }catch(const std::exception& error){throw_java(env,error);}
}
extern "C" JNIEXPORT jstring JNICALL Java_x_lab_gaming_NativeBridge_capabilities(JNIEnv* env,jclass,jlong handle){
  try{const std::string text=lookup(handle)->capabilities();return env->NewStringUTF(text.c_str());}catch(const std::exception& error){throw_java(env,error);return nullptr;}
}
extern "C" JNIEXPORT void JNICALL Java_x_lab_gaming_NativeBridge_close(JNIEnv* env,jclass,jlong handle){
  try{
    std::shared_ptr<Session> session;
    {std::lock_guard<std::mutex> lock(registry_mutex);auto it=sessions.find(handle);if(it==sessions.end())return;session=it->second;session->check_owner();sessions.erase(it);}
    session->shutdown();
  }catch(const std::exception& error){throw_java(env,error);}
}

extern "C" JNIEXPORT jstring JNICALL Java_x_lab_gaming_NativeBridge_probeCapabilities(JNIEnv* env,jclass){
  try{const std::string value=xlab::component_capabilities();return env->NewStringUTF(value.c_str());}
  catch(const std::exception& e){throw_java(env,e);return nullptr;}
}
extern "C" JNIEXPORT jstring JNICALL Java_x_lab_gaming_NativeBridge_probe(JNIEnv* env,jclass,jint kind,jint load,jlong seed,jstring directory){
  try{
    if(!directory)throw std::invalid_argument("A private checkpoint directory is required");
    const char* raw=env->GetStringUTFChars(directory,nullptr);if(!raw)return nullptr;
    std::string path(raw);env->ReleaseStringUTFChars(directory,raw);
    xlab::ComponentRequest request;request.kind=kind;request.load=load;request.seed=static_cast<std::uint64_t>(seed);request.directory=path;
    const std::string value=xlab::run_component(request).json();return env->NewStringUTF(value.c_str());
  }catch(const std::exception& e){throw_java(env,e);return nullptr;}
}
