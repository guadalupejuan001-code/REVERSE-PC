#include "component_lab.hpp"
#include "lab_api.hpp"
#include "qssd/c12_bridge.hpp"
#include "qssd/state_bus.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <limits>
#include <map>
#include <sstream>
#include <stdexcept>

namespace xlab {
namespace {
using Clock = std::chrono::steady_clock;
constexpr float pi = 3.14159265358979323846f;
constexpr std::uint32_t seed = 37;
constexpr std::size_t region_capacity = 8;
std::int64_t ns(Clock::time_point begin) {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() -
                                                              begin)
      .count();
}
std::uint32_t bits(float x) {
  std::uint32_t out;
  std::memcpy(&out, &x, 4);
  return out;
}
float real(std::uint32_t x) {
  float out;
  std::memcpy(&out, &x, 4);
  return out;
}
std::uint32_t mix(std::uint32_t x) {
  x ^= x >> 16;
  x *= 0x7feb352dU;
  x ^= x >> 15;
  x *= 0x846ca68bU;
  return x ^ (x >> 16);
}
float unit(std::uint32_t x) { return float(mix(x) & 65535U) / 65535.f; }
int saturate(std::uint64_t n) {
  return int(std::min<std::uint64_t>(n, INT32_MAX));
}
std::uint32_t tick_at(std::int64_t now, std::int64_t origin) {
  const auto elapsed = now > origin ? std::uint64_t(now - origin) : 0;
  const auto ticks = (elapsed / 1000000000ULL) * 120ULL +
                     (elapsed % 1000000000ULL) * 120ULL / 1000000000ULL;
  return std::uint32_t(std::min<std::uint64_t>(ticks, UINT32_MAX));
}
float finite_axis(float value) {
  return std::isfinite(value) ? std::clamp(value, -1.f, 1.f) : 0.f;
}
Instance object(int mesh, float x, float y, float z, float sx, float sy,
                float sz, float r, float g, float b, float a = 1, float yaw = 0,
                bool shadow = true) {
  Instance v;
  v.mesh = mesh;
  v.x = x;
  v.y = y;
  v.z = z;
  v.sx = sx;
  v.sy = sy;
  v.sz = sz;
  v.r = r;
  v.g = g;
  v.b = b;
  v.a = a;
  v.yaw = yaw;
  v.casts_shadow = shadow;
  return v;
}
void put(std::vector<Instance> &out, int mesh, float x, float y, float z,
         float sx, float sy, float sz, float r, float g, float b, float a = 1,
         float yaw = 0, bool shadow = true) {
  out.push_back(object(mesh, x, y, z, sx, sy, sz, r, g, b, a, yaw, shadow));
}

struct Region {
  std::shared_ptr<const std::vector<Instance>> objects;
  std::uint64_t last_use = 0;
};
using Regions = std::map<int, Region>;
struct World {
  qssd::Lease motion{};
  std::shared_ptr<const std::vector<float>> phases;
  std::shared_ptr<const Regions> regions = std::make_shared<const Regions>();
  std::uint32_t tick = 0;
  float control_x = 0, control_z = 0, ball_y = 0;
  bool contact = false;
};
std::uint32_t read32(const qssd::Lease &lease, unsigned address) {
  std::uint32_t result = 0;
  for (unsigned j = 0; j < 4; ++j) {
    const auto value = lease.epoch->cpu.memory().read(
        std::to_string(address + j), lease.epoch->cpu.core());
    if (!value.deterministic)
      throw std::runtime_error("lab CPU output must be classical");
    result |= std::uint32_t(value.value) << (j * 8);
  }
  return result;
}
xgpu::Kernel motion_kernel() {
  using O = xgpu::StateOp;
  return {{{O::Index, 0},
           {O::LoadGlobal, 1, 0},
           {O::Constant, 2, 0, 0, 0, 4095},
           {O::BitAnd, 3, 1, 2},
           {O::FloatFromUnsigned, 4, 3},
           {O::Constant, 5, 0, 0, 0, bits(1.f / 4096.f)},
           {O::FloatMultiply, 6, 4, 5},
           {O::Output, 6},
           {O::Halt}}};
}
void hash_word(std::uint64_t &h, std::uint32_t value) {
  for (unsigned i = 0; i < 4; ++i) {
    h ^= (value >> (i * 8)) & 255;
    h *= 1099511628211ULL;
  }
}
std::uint64_t revision_hash(std::initializer_list<std::uint32_t> words) {
  std::uint64_t h=1469598103934665603ULL;for(auto w:words)hash_word(h,w);return h;
}
void stamp_instances(Packet& p,int scene) {
  for(std::size_t i=0;i<p.objects.size();++i){
    auto& v=p.objects[i];v.id=(std::uint64_t(std::uint32_t(scene))<<56)|std::uint64_t(i+1);
    v.transform_revision=revision_hash({bits(v.x),bits(v.y),bits(v.z),bits(v.sx),bits(v.sy),bits(v.sz),bits(v.yaw)});
    v.material_revision=revision_hash({std::uint32_t(v.mesh),bits(v.r),bits(v.g),bits(v.b),bits(v.a),v.casts_shadow?1U:0U});
  }
}
std::uint64_t visible_hash(const Packet &p) {
  std::uint64_t h = 1469598103934665603ULL;
  for (float v : p.eye)
    hash_word(h, bits(v));
  for (float v : p.look)
    hash_word(h, bits(v));
  for (float v : p.sun)
    hash_word(h, bits(v));
  for (float v : p.fog)
    hash_word(h, bits(v));
  // Visual reuse is keyed only by values that can change the rendered image.
  // World-clock/audio advance independently and must not invalidate an otherwise identical frame.
  hash_word(h, bits(p.light_energy));
  hash_word(h, std::uint32_t(p.objects.size()));
  for (const auto &v : p.objects) {
    for (float f : {v.x, v.y, v.z, v.sx, v.sy, v.sz, v.yaw, v.r, v.g, v.b, v.a})
      hash_word(h, bits(f));
    hash_word(h, std::uint32_t(v.mesh));
    hash_word(h, v.casts_shadow ? 1 : 0);
  }
  return h;
}
} // namespace

struct Backend::Impl {
  Config config;
  std::int64_t origin = 0, last_now = 0, last_event = 0;
  std::uint32_t previous_tick = 0;
  bool configured = false, bound = false;
  qssd::Space space;
  SceneQuantumSignal quantum;
  qssd::StateBus<World> world{World{}, 2};
  Packet packet;
  std::uint64_t uses = 0, hits = 0, misses = 0, prepared = 0, hot = 0,
                cpu_programs = 0, virtual_gpu_dispatches = 0, shared_handoffs = 0;
  int actors() const {
    static const int regular[] = {24, 80, 240, 2400, 12000},
                     fx[] = {96, 320, 960, 6000, 24000};
    return config.scene == CALIBRATION
               ? 4
               : (config.scene == EFFECTS ? fx[config.load]
                                          : regular[config.load]);
  }
  bool streaming() const {
    return config.scene == OPEN_WORLD || config.scene == OFFSCREEN;
  }
  void configure(const Config &c, std::int64_t now) {
    config = c;
    config.scene = std::clamp(c.scene, 0, 7);
    config.load = std::clamp(c.load, 0, 4);
    origin = last_now = now;
    last_event = 0;
    previous_tick = 0;
    configured = true;
    bound = false;
    space = qssd::Space();
    world = qssd::StateBus<World>(World{}, 2);
    packet = Packet{};
    uses = hits = misses = prepared = hot = cpu_programs = virtual_gpu_dispatches =
        shared_handoffs = 0;
    // XI owns the persistent movement anchors and velocities. All stores below
    // execute in the original QuantumRuntime transaction / InverseMemory.
    space.execute_cpu(
        "#!reverse-pc-machine-v1\nstore32 104 0\nstore32 108 32768\nstore32 "
        "112 32768\nstore32 116 1000\nstore32 120 1000\nhalt\n");
    // Original 1000-qubit structured GHZ+T evolution runs once per configuration.
    // Its global-X correlation is explicitly projected into XI memory; GPU Virtual
    // receives the later CPU-authored classical coefficient, not a qubit.
    quantum = prepare_scene_quantum(space, seed);
  }
  std::string cpu_program(std::uint32_t tick, const Input &input,
                          std::int64_t now) {
    std::ostringstream p;
    p << "#!reverse-pc-machine-v1\n";
    const int max_x = config.scene == FIGHTING ? 2400 : 8000;
    // Saturating contact is solved analytically from the input event anchor.
    // Sampling 30, 60 or 120 times/sec does not change the trajectory.
    auto axis = [&](int anchor, int velocity, int result,
                    const std::string &elapsed, int lower, int upper) {
      p << "load32 r1 " << anchor << "\nsub r1 32768\nload32 r2 " << velocity
        << "\nsub r2 1000\nmul r2 " << elapsed
        << "\ndiv r2 40\nadd r1 r2\ncmp r1 " << lower << "\njge low" << result
        << "\nset r1 " << lower << "\nset r8 1\nlabel low" << result
        << "\ncmp r1 " << upper << "\njle high" << result << "\nset r1 "
        << upper << "\nset r8 1\nlabel high" << result
        << "\nadd r1 32768\nstore32 " << result << " r1\n";
    };
    // A newly delivered touch may be newer than this sampled vsync. Keep the
    // previous accepted control state until the original timestamp is due;
    // clamping it to now would apply it early and repeatedly re-anchor motion.
    const auto event = input.event_ns;
    if (event <= now && event > last_event && event >= origin) {
      const auto et = tick_at(event, origin);
      p << "set r0 " << et << "\nload32 r3 104\nsub r0 r3\nset r8 0\n";
      axis(108, 116, 108, "r0", -8000, max_x);
      axis(112, 120, 112, "r0", -8000, 8000);
      const int vx =
          input.pressed ? int(std::lround(finite_axis(input.x) * 1000)) : 0;
      const int vz =
          input.pressed ? int(std::lround(finite_axis(input.y) * 1000)) : 0;
      p << "store32 104 " << et << "\nstore32 116 " << vx + 1000
        << "\nstore32 120 " << vz + 1000 << "\n";
      last_event = event;
    }
    p << "set r0 " << tick
      << "\nstore32 100 r0\nload32 r3 104\nsub r0 r3\nset r8 0\n";
    axis(108, 116, 124, "r0", -8000, max_x);
    axis(112, 120, 128, "r0", -8000, 8000);
    p << "store32 132 r8\nset r10 " << tick
      << "\nmod r10 120\nset r11 120\nsub r11 r10\nmul r10 r11\nmul r10 "
         "10\ndiv r10 12\nstore32 136 r10\n";
    // A compact polynomial is authored by XI and published by QSSD, not
    // independently reconstructed by the renderer or the lab adapter.
    p << "set r4 " << tick << "\nmul r4 9\nadd r4 " << seed
      << "\nload32 r5 4112\nadd r4 r5\nmod r4 4294967296\nstore32 4096 "
         "r4\nstore32 4100 97\nhalt\n";
    return p.str();
  }
  std::shared_ptr<const std::vector<Instance>> build_region(int region) {
    auto out = std::make_shared<std::vector<Instance>>();
    const float z = region * 20.f;
    if (streaming()) {
      put(*out, 2, 0, -.04f, z, 44, 1, 20, .09f, .18f, .14f, 1, 0, false);
      put(*out, 2, 0, 0, z, 4.4f, 1, 20, .21f, .24f, .22f, 1, 0, false);
      const int count = 12 * (config.load + 1);
      for (int i = 0; i < count; ++i) {
        const auto id =
            mix(std::uint32_t(region) * 8731U + std::uint32_t(i) + seed);
        const float x = (i & 1 ? 1.f : -1.f) * (4 + 16 * unit(id)),
                    zz = z - 9 + 18 * unit(id + 1),
                    height = 1.5f + 3 * unit(id + 2);
        put(*out, 4, x, height * .22f, zz, .36f, height * .44f, .36f, .25f,
            .16f, .10f);
        put(*out, 1, x, height * .69f, zz, 2, height, 2, .08f,
            .28f + .16f * unit(id + 3), .16f);
        if ((i % 4) == 0)
          put(*out, 1, x * .8f, .35f, zz + 1, .9f, .7f, 1.2f, .26f, .33f, .34f);
      }
    } else if (config.scene == MOBA) {
      put(*out, 2, 0, -.04f, 0, 34, 1, 30, .055f, .14f, .13f, 1, 0, false);
      for (int lane = -1; lane <= 1; ++lane) {
        put(*out, 2, 0, 0, lane * 7.f, 28, 1, 2.7f, .24f, .26f, .28f, 1, 0,
            false);
        for (int side : {-1, 1}) {
          put(*out, 4, side * 11.f, 1.3f, lane * 7.f, 1.4f, 2.6f, 1.4f,
              side < 0 ? .08f : .66f, .32f, side < 0 ? .8f : .18f);
          put(*out, 1, side * 11.f, 3, lane * 7.f, 1.7f, 1, 1.7f, .45f, .7f,
              .85f);
        }
      }
      for (int i = 0; i < 18 * (config.load + 1); ++i) {
        float a = 2 * pi * i / (18 * (config.load + 1));
        put(*out, 1, 15 * std::cos(a), .7f, 12 * std::sin(a), 1.4f, 1.4f, 1.4f,
            .08f, .25f, .17f);
      }
    } else if (config.scene == FIGHTING) {
      put(*out, 2, 0, 0, 0, 15, 1, 11, .18f, .21f, .28f, 1, 0, false);
      for (int i = 0; i < 9; ++i)
        put(*out, 0, (i - 4) * 1.6f, .12f, -4.5f, 1.4f, .24f, .2f, .12f, .62f,
            .72f);
      for (int i = 0; i < 18 * (config.load + 1); ++i) {
        float a = 2 * pi * i / (18 * (config.load + 1));
        put(*out, 0, 8 * std::cos(a), 1.2f, 6 * std::sin(a), .7f, 2.4f, .7f,
            .14f, .18f, .27f);
      }
    } else if (config.scene == SHOOTER) {
      put(*out, 2, 0, -.02f, 8, 14, 1, 55, .13f, .15f, .21f, 1, 0, false);
      for (int i = 0; i < 12; ++i) {
        float zz = i * 4.f - 12;
        for (int side : {-1, 1}) {
          put(*out, 0, side * 6.f, 2, zz, .5f, 4, 3.7f, .17f, .22f, .31f);
          put(*out, 0, side * 5.7f, 3.5f, zz, .08f, .15f, 2.4f, .1f, .8f, 1);
        }
        if (i % 3 == 0)
          put(*out, 0, (i & 1 ? 2.f : -2.f), .6f, zz, 2, 1.2f, 1.5f, .27f, .30f,
              .35f);
      }
    } else if (config.scene == RACING) {
      put(*out, 2, 0, -.08f, 15, 100, 1, 100, .08f, .20f, .15f, 1, 0, false);
      for (int i = -6; i < 22; ++i) {
        float zz = i * 3.f, xx = 3 * std::sin(zz * .05f),
              yaw = std::atan(.15f * std::cos(zz * .05f));
        put(*out, 2, xx, 0, zz, 8, 1, 3.3f, .13f, .16f, .20f, 1, yaw, false);
        put(*out, 2, xx, .012f, zz, .10f, 1, 1.3f, .9f, .8f, .37f, 1, yaw,
            false);
        for (int side : {-1, 1})
          put(*out, 0, xx + side * 4.6f, .35f, zz, .25f, .7f, 2.6f, .60f, .22f,
              .20f, 1, yaw);
      }
    } else if (config.scene == EFFECTS) {
      put(*out, 2, 0, -.1f, 0, 25, 1, 25, .035f, .045f, .07f, 1, 0, false);
      put(*out, 4, 0, .7f, 0, 3, 1.4f, 3, .16f, .23f, .30f);
    } else {
      put(*out, 2, 0, -.05f, 0, 14, 1, 14, .08f, .14f, .19f, 1, 0, false);
      put(*out, 0, 0, .7f, 0, 1.4f, 1.4f, 1.4f, .1f, .7f, .8f);
    }
    return out;
  }
  void take_region(Regions &cache, int key, bool prefetch,
                   std::vector<Instance> &out) {
    auto it = cache.find(key);
    if (it == cache.end()) {
      if (cache.size() >= region_capacity) {
        auto oldest = std::min_element(
            cache.begin(), cache.end(), [](const auto &a, const auto &b) {
              return a.second.last_use < b.second.last_use;
            });
        cache.erase(oldest);
      }
      it = cache.emplace(key, Region{build_region(key), ++uses}).first;
      ++misses;
      if (prefetch)
        ++prepared;
      else
        ++hot;
    } else {
      ++hits;
      it->second.last_use = ++uses;
    }
    if (!prefetch)
      out.insert(out.end(), it->second.objects->begin(),
                 it->second.objects->end());
  }
  void fighters(Packet &p, const World &w) {
    for (int side = 0; side < 2; ++side) {
      const float sign = side ? -1.f : 1.f,
                  x = side ? 1.8f : -1.8f + w.control_x,
                  zz = w.control_z * .12f;
      const float gait = std::sin((*w.phases)[side] * 2 * pi) * .20f;
      const float rr = side ? .85f : .1f, bb = side ? .2f : .85f;
      put(p.objects, 0, x, 1.65f, zz, .85f, 1.05f, .55f, rr, .35f, bb);
      put(p.objects, 1, x, 2.5f, zz, .58f, .6f, .58f, .77f, .66f, .51f);
      for (int limb : {-1, 1}) {
        put(p.objects, 0, x + limb * .23f, .65f, zz + limb * gait, .30f, 1.15f,
            .35f, .13f, .18f, .28f);
        put(p.objects, 0, x + limb * .65f + sign * gait, 1.75f, zz, .55f, .30f,
            .36f, rr, .45f, bb);
      }
      put(p.objects, 1, x + sign * (.78f + std::max(0.f, gait)), 1.85f, zz,
          .33f, .32f, .33f, w.contact ? 1.f : rr, w.contact ? .85f : .4f, bb);
    }
    if (w.contact)
      for (int i = 0; i < 16; ++i) {
        float a = i * pi / 8;
        put(p.objects, 1, .7f + std::cos(a) * .6f, 1.7f + std::sin(a) * .6f,
            .1f, .12f, .12f, .12f, 1, .76f, .12f, 1, 0, false);
      }
  }
  const Packet &sample(std::int64_t requested, const Input &input) {
    if (!configured)
      configure(Config{}, requested);
    const auto now = std::max(last_now, requested);
    last_now = now;
    const auto tick = tick_at(now, origin);
    const float t = float(tick) / 120.f;
    // Reuse the presentation vector at massive loads. The immutable QSSD
    // world inputs remain separately owned; only this derived packet is reset.
    auto retained_objects = std::move(packet.objects);
    retained_objects.clear();
    packet = Packet{};
    packet.objects = std::move(retained_objects);
    const auto count = std::size_t(actors());
    const auto expected_objects = config.scene == RACING ? count * 2 + 512
        : (config.scene == MOBA || config.scene == SHOOTER) ? count * 4 / 3 + 512
        : count + 512;
    if (packet.objects.capacity() < expected_objects)
      packet.objects.reserve(expected_objects);
    packet.quantum_gates = quantum.gates;
    packet.quantum_circuits = quantum.circuits;
    packet.quantum_qubits = quantum.qubits;
    packet.quantum_signal = float(quantum.xx);
    packet.seconds = t;
    packet.source_revision = tick;
    packet.source_ns = origin + std::int64_t(tick / 120) * 1000000000LL +
                       std::int64_t(tick % 120) * 1000000000LL / 120;
    packet.physics_steps = saturate(std::uint64_t(tick) - previous_tick);
    previous_tick = tick;
    auto start = Clock::now();
    space.execute_cpu(cpu_program(tick, input, now));
    ++cpu_programs;
    packet.cpu_ns = ns(start);
    start = Clock::now();
    space.publish_cpu_rule("motion", actors(), "4096", 2);
    if (!bound) {
      space.bind("cpu:motion", "motion");
      space.route("cpu:motion", "ssd:motion");
      space.route("ssd:motion", "gpu:motion");
      bound = true;
    }
    auto lease = space.acquire("gpu:motion");
    packet.qssd_ns = ns(start);
    start = Clock::now();
    qssd::C12Window window(lease);
    const auto job = window.enqueue(motion_kernel(), lease.field->count);
    if (!window.run() || !window.engine().dispatch(job).output_valid.full() ||
        !window.source_pointer_preserved())
      throw std::runtime_error("GPU Virtual motion dispatch failed");
    ++virtual_gpu_dispatches;
    ++shared_handoffs;
    auto phases = std::make_shared<std::vector<float>>();
    phases->reserve(lease.field->count);
    xgpu::ValueReader reader(window.engine().dispatch(job).output);
    for (xgpu::Index i = 0; i < lease.field->count; ++i)
      phases->push_back(real(reader.at(i)));
    packet.virtual_gpu_ns = ns(start);
    packet.work_items = int(phases->size());
    World next;
    next.motion = lease;
    next.phases = phases;
    next.tick = tick;
    next.control_x = (int(read32(lease, 124)) - 32768) / 1000.f;
    next.control_z = (int(read32(lease, 128)) - 32768) / 1000.f;
    next.contact = read32(lease, 132) != 0;
    next.ball_y = read32(lease, 136) / 1000.f;
    auto regions = std::make_shared<Regions>(*world.snapshot()->value->regions);
    float travel = 0;
    if (config.scene == OPEN_WORLD) {
      travel = std::fmod(t * 2.5f, 400.f);
      packet.eye = {6 + next.control_x * .3f, 5.5f, travel - 10};
      packet.look = {next.control_x * .1f, 1, travel + 10};
      packet.fog = {.16f, .26f, .29f};
    } else if (config.scene == OFFSCREEN) {
      float cycle = std::fmod(t, 32.f);
      travel = 8 + cycle * 2;
      float turn = std::clamp((cycle - 8) / 4, 0.f, 1.f) * pi;
      packet.eye = {next.control_x * .4f, 4, travel};
      packet.look = {std::sin(turn) * 12, 2, travel - std::cos(turn) * 12};
      packet.fog = {.10f, .18f, .21f};
    }
    start = Clock::now();
    if (streaming()) {
      const int center = int(std::floor(travel / 20));
      for (int region = center - 1; region <= center + 1; ++region)
        take_region(*regions, region, false, packet.objects);
      if (config.coordinated)
        take_region(*regions, center + 2, true, packet.objects);
    } else
      take_region(*regions, 0, false, packet.objects);
    next.regions = regions;
    auto committed =
        world.publish(std::move(next), "world-clock-and-resources");
    packet.qssd_ns += ns(start);
    const World &w = *committed->value;
    if (config.scene == MOBA) {
      packet.eye = {0 + w.control_x * .1f, 19, 21 + w.control_z * .1f};
      packet.look = {0, 0, 0};
      for (int i = 0; i < actors(); ++i) {
        float phase = (*w.phases)[i], xx = -10 + phase * 20,
              zz = ((i % 3) - 1) * 7.f + (i % 2 ? .5f : -.5f);
        bool red = i % 2;
        put(packet.objects, red ? 0 : 1, red ? -xx : xx, .6f, zz, .55f, 1.2f,
            .55f, red ? .80f : .12f, .40f, red ? .20f : .85f);
        if (i % 4 == 0)
          put(packet.objects, 1, xx + 1.2f, .9f, zz, .15f, .15f, .35f, 1, .8f,
              .2f, 1, pi * .5f, false);
      }
      put(packet.objects, 1, w.control_x, 1.1f, w.control_z, 1.2f, 2.2f, 1.2f,
          .2f, .85f, 1);
    } else if (config.scene == OPEN_WORLD) {
      // Actor identity is spatial (region/local slot), so a camera move does
      // not drag wildlife with it or restart its animation on re-entry.
      const int center = int(std::floor(travel / 20));
      for (int region = center - 1; region <= center + 1; ++region)
        for (int i = 0; i < actors() / 3; ++i) {
          const auto id =
              mix(std::uint32_t(region) * 7919U + std::uint32_t(i) + seed);
          const float phase = (*w.phases)[id % w.phases->size()];
          put(packet.objects, 1, (i % 2 ? 1.f : -1.f) * (3 + phase * 6), .6f,
              region * 20.f - 8 + 16 * unit(id + 5), .55f, 1.2f, .55f, .6f, .4f,
              .2f, 1, phase * 2 * pi);
        }
    } else if (config.scene == FIGHTING) {
      packet.eye = {0, 5.2f, 10};
      packet.look = {0, 1.4f, 0};
      fighters(packet, w);
      for (int i = 0; i < actors(); ++i) {
        float phase = (*w.phases)[i], a = phase * 2 * pi;
        put(packet.objects, 1, std::cos(a) * (5 + i % 3), .35f, std::sin(a) * 4,
            .18f, .18f, .18f, .3f, .6f, .8f, .8f, 0, false);
      }
    } else if (config.scene == SHOOTER) {
      packet.eye = {w.control_x * .4f, 2.2f, -12 + w.control_z * .25f};
      packet.look = {w.control_x * .15f, 1.8f, 18};
      for (int i = 0; i < actors(); ++i) {
        float phase = (*w.phases)[i], zz = -2 + (i % 12) * 3.4f;
        put(packet.objects, 0, -3 + phase * 6, 1.4f, zz, .75f, 1.6f, .25f, .75f,
            .22f, .19f);
        if (i % 3 == 0)
          put(packet.objects, 1, 0, 1.7f, -10 + phase * 45, .09f, .09f, .55f, 1,
              .8f, .1f, 1, 0, false);
      }
    } else if (config.scene == RACING) {
      float forward = std::fmod(t * 5, 42.f);
      packet.eye = {3 * std::sin(forward * .05f) + w.control_x * .12f, 3.5f,
                    forward - 10};
      packet.look = {3 * std::sin((forward + 15) * .05f), .6f, forward + 15};
      for (int i = 0; i < actors(); ++i) {
        float zz = -6 + (*w.phases)[i] * 65,
              xx = 3 * std::sin(zz * .05f) + (i % 2 ? 1.8f : -1.8f),
              yaw = std::atan(.15f * std::cos(zz * .05f));
        put(packet.objects, 0, xx, .45f, zz, 1.35f, .7f, 2.4f,
            .2f + (i % 3) * .25f, .35f, .8f - (i % 3) * .25f, 1, yaw);
        put(packet.objects, 0, xx, .98f, zz, 1.1f, .4f, 1.2f, .11f, .18f, .24f,
            1, yaw);
      }
    } else if (config.scene == EFFECTS) {
      packet.eye = {0, 6, 13};
      packet.look = {0, 2, 0};
      for (int i = 0; i < actors(); ++i) {
        float phase = (*w.phases)[i], a = phase * 2 * pi + i * 2.399963f,
              r = 1 + float(i % 13) * .24f;
        put(packet.objects, 3, std::cos(a) * r, 1 + phase * 6, std::sin(a) * r,
            .8f + phase, 1 + phase, .3f, 1, .28f + phase * .6f, .1f,
            .17f + phase * .30f, 0, false);
      }
    } else if (config.scene == OFFSCREEN) {
      // The mill and ballistic object use world time even while behind the eye.
      // Geometry is always present; the physical renderer performs visibility.
      put(packet.objects, 0, 3, 2.2f, 60, 3, 4.4f, 3, .42f, .29f, .18f);
      put(packet.objects, 1, 3, 5.4f, 60, 4, 2.2f, 4, .18f, .29f, .27f);
      float angle = (*w.phases)[0] * 2 * pi;
      for (int blade = 0; blade < 4; ++blade) {
        float a = angle + blade * pi / 2;
        put(packet.objects, 0, 3 + std::cos(a) * 1.6f,
            3.6f + std::sin(a) * 1.6f, 58.35f, .65f, 1, .14f, .77f, .69f, .47f,
            1, a);
      }
      put(packet.objects, 1, 0, .3f + w.ball_y, 58, .6f, .6f, .6f,
          w.contact ? 1.f : .15f, .78f, .9f);
      for (int i = 0; i < actors(); ++i) {
        float phase = (*w.phases)[i];
        put(packet.objects, 1, -5 + phase * 10, .35f, 48 + (i % 20), .25f, .7f,
            .25f, .5f, .62f, .24f, 1, phase * 2 * pi);
      }
      const float distance =
          std::sqrt(packet.eye[0] * packet.eye[0] +
                    (packet.eye[2] - 60) * (packet.eye[2] - 60));
      packet.audio_hz = 160 + 80 * (*w.phases)[0];
      packet.audio_gain = .10f / (1 + distance * .12f);
      packet.light_energy = .8f + .2f * std::sin(angle);
    } else {
      packet.eye = {0, 5, 10};
      packet.look = {0, 1, 0};
      for (int i = 0; i < actors(); ++i)
        put(packet.objects, 1, -3 + i * 2, 1 + (*w.phases)[i] * 2, 1, .5f, .5f,
            .5f, .3f, .8f, .9f);
    }
    if (config.scene != OFFSCREEN) {
      packet.audio_hz = 180 + 40 * (*w.phases)[0];
      packet.audio_gain = .012f;
    }
    stamp_instances(packet,config.scene);
    packet.cache_hits = saturate(hits);
    packet.cache_misses = saturate(misses);
    packet.prepared_regions = saturate(prepared);
    packet.hot_region_builds = saturate(hot);
    packet.state_hash = visible_hash(packet);
    return packet;
  }
};
Backend::Backend() : impl_(std::make_unique<Impl>()) {}
Backend::~Backend() = default;
void Backend::configure(const Config &c, std::int64_t now) {
  impl_->configure(c, now);
}
const Packet &Backend::sample(std::int64_t now, const Input &input) {
  return impl_->sample(now, input);
}
std::string Backend::provenance() const {
  std::ostringstream out;
  out << "{\"schema\":\"x-gaming-lab-backend-v2\",\"gpu_virtual\":"
         "\"f828a28468e73bf2f517d45080e11383bd14ba5c\",\"qssd\":"
         "\"376b1334dd2dde6093a2988ee12325590941573d\",\"mundo_x\":"
         "\"1f925786522aba91f72707ad1638a8edcdd31a8f\",\"reverse_xi_"
         "extension\":\"166fd1a5ebc41feb9407647fe8e45ad71cf47147\",\"seed\":"
      << seed
      << ",\"execution\":\"original components execute on host CPU; GLES "
         "renderer uses physical GPU\",\"cpu_scope\":\"XI persistent input "
         "anchors, analytic bounded contact, ballistic height, world clock and "
         "GPU Virtual coefficient authoring; no quantum speedup "
         "claim\",\"qssd_scope\":\"Space CPU authority and immutable shared "
         "Field; StateBus immutable world/resource "
         "graph\",\"gpu_virtual_scope\":\"original GPU Virtual execution computes every dynamic "
         "actor phase from XI-authored field; visible motion and audio consume "
         "results\",\"baseline\":\"both modes retain an 8-region LRU; "
         "coordinated streaming prepares next region; direct builds once on "
         "arrival; other scene workloads "
         "identical\",\"physics_steps_semantics\":\"120Hz world ticks crossed "
         "this sample; analytic evolution, not solver "
         "iterations\",\"work_items_semantics\":\"GPU Virtual output lanes read this "
         "sample\",\"cache_counter_semantics\":\"cumulative since "
         "configure\",\"offscreen_scope\":\"analytic world clock and ballistic "
         "object; source-distance audio; global light modulation; no acoustic "
         "propagation or local light-field solver\",\"cpu_programs\":"
      << impl_->cpu_programs << ",\"virtual_gpu_dispatches\":" << impl_->virtual_gpu_dispatches
      << ",\"shared_field_handoffs\":" << impl_->shared_handoffs
      << ",\"cpu_rule_input_bytes\":" << impl_->space.cpu_rule_input_bytes()
      << ",\"qssd_routed_references\":" << impl_->space.routed_references()
      << ",\"state_bus_serial\":" << impl_->world.stats().serial
      << ",\"load\":" << impl_->config.load
      << ",\"dynamic_actor_budget\":" << impl_->actors()
      << ",\"quantum_gates\":" << impl_->quantum.gates
      << ",\"quantum_circuits\":" << impl_->quantum.circuits
      << ",\"quantum_qubits\":" << impl_->quantum.qubits
      << ",\"quantum_signal_global_x\":" << impl_->quantum.xx
      << ",\"quantum_projection_q10\":" << impl_->quantum.projected_q10
      << ",\"quantum_scope\":\"original 1000-qubit structured GHZ+T once per configure; global-X observation explicitly projected to XI memory and consumed by the GPU Virtual-visible phase; no quantum gates per frame or physical quantum GPU claim\""
      << ",\"retained_regions\":"
      << impl_->world.snapshot()->value->regions->size() << "}";
  return out.str();
}
} // namespace xlab
