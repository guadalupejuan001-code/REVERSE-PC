#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace qssd {
class Space;
}
namespace xlab {
enum ComponentKind { XI = 0, QUANTUM = 1, GPU_VIRTUAL = 2, QSSD = 3, INTEGRATED = 4 };
struct ComponentRequest {
  int kind = XI, load = 0;
  std::uint64_t seed = 37;
  std::string directory;
};
struct ComponentSubtest {
  std::string name, unit, scope;
  bool passed = true;
  std::uint64_t checks = 0, failures = 0, work_items = 0;
  std::uint64_t checksum = 14695981039346656037ULL;
  std::uint64_t expected_checksum = 14695981039346656037ULL;
  double max_error = 0;
  std::int64_t elapsed_ns = 0;
  std::map<std::string, std::uint64_t> sizes, counters;
  std::map<std::string, double> observations;
  std::map<std::string, std::string> attributes;
  std::vector<std::string> errors;
};
struct ComponentReport {
  int kind = XI, load = 0;
  std::uint64_t seed = 37;
  std::string name, unit, scope;
  bool passed = true;
  std::uint64_t checks = 0, failures = 0, work_items = 0;
  std::uint64_t checksum = 14695981039346656037ULL;
  double max_error = 0;
  std::int64_t elapsed_ns = 0;
  std::vector<ComponentSubtest> subtests;
  std::string json() const;
};
ComponentReport run_component(const ComponentRequest &request);
std::string component_capabilities();

// Shared by the actual scene backend and its causal diagnostic. The original
// runtime owns the configured qubits. The optional gate-removal experiment is testable:
// omitting T changes the measured XX observable and the downstream CPU field.
struct SceneQuantumSignal {
  std::uint64_t gates = 0, circuits = 0;
  int qubits = 0;
  double xx = 0, norm = 0;
  std::uint32_t projected_q10 = 0;
};
SceneQuantumSignal prepare_scene_quantum(qssd::Space &space,
                                         std::uint64_t seed = 37,
                                         bool phase_gate = true);
} // namespace xlab
