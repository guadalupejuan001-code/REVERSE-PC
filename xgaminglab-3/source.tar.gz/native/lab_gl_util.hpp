#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <time.h>

namespace xlab {
inline std::int64_t monotonic_ns() {
  timespec value{};
  clock_gettime(CLOCK_MONOTONIC, &value);
  return std::int64_t(value.tv_sec) * 1000000000LL + value.tv_nsec;
}
inline std::string json_string(const std::string& value) {
  std::string out = "\"";
  for (unsigned char ch : value) {
    switch (ch) {
      case '\\': out += "\\\\"; break;
      case '"': out += "\\\""; break;
      case '\n': out += "\\n"; break;
      case '\r': out += "\\r"; break;
      case '\t': out += "\\t"; break;
      default:
        if (ch < 32) { char escaped[7]; std::snprintf(escaped, sizeof escaped, "\\u%04x", ch); out += escaped; }
        else out += char(ch);
    }
  }
  return out + '"';
}
inline bool extension_has(const char* list, const char* name) {
  if (!list || !name || !*name) return false;
  const std::string all = std::string(" ") + list + " ";
  return all.find(std::string(" ") + name + " ") != std::string::npos;
}
} // namespace xlab
