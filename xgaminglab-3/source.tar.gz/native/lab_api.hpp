#pragma once
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace xlab {
enum Scene { CALIBRATION=0, MOBA=1, OPEN_WORLD=2, FIGHTING=3, SHOOTER=4, RACING=5, EFFECTS=6, OFFSCREEN=7 };
struct Config { int scene=MOBA; int load=1; bool coordinated=true; float resolution=0.75f; int target_hz=120; int graphics_path=0; };
struct Input { float x=0, y=0; std::int64_t event_ns=0; bool pressed=false; };
struct Instance {
  float x=0,y=0,z=0,sx=1,sy=1,sz=1,yaw=0;
  float r=1,g=1,b=1,a=1;
  int mesh=0; // 0 box, 1 octahedron, 2 ground plane, 3 billboard, 4 cylinder
  bool casts_shadow=true;
  std::uint64_t id=0,transform_revision=0,material_revision=0;
};
struct Packet {
  std::vector<Instance> objects;
  std::array<float,3> eye{0,12,18}, look{0,0,0};
  std::array<float,3> sun{-0.5f,1.0f,0.4f};
  std::array<float,3> fog{0.035f,0.055f,0.085f};
  float seconds=0, light_energy=1, audio_hz=220, audio_gain=0.02f;
  std::uint64_t source_revision=0, state_hash=0;
  std::int64_t source_ns=0, cpu_ns=0, qssd_ns=0, virtual_gpu_ns=0;
  int physics_steps=0, work_items=0, cache_hits=0, cache_misses=0, prepared_regions=0, hot_region_builds=0;
  std::uint64_t quantum_gates=0, quantum_circuits=0;
  int quantum_qubits=0;
  float quantum_signal=0;
};
// Original XI/Ether + original QSSD + original GPU Virtual. Implementation is in x_backend.cpp.
class Backend {
 public:
  Backend(); ~Backend();
  void configure(const Config&,std::int64_t now_ns);
  const Packet& sample(std::int64_t now_ns,const Input&);
  std::string provenance() const;
 private: struct Impl; std::unique_ptr<Impl> impl_;
};
struct DrawStats {
  std::int64_t geometry_ns=0,submit_ns=0,gpu_ns=-1,shadow_gpu_ns=-1,scene_gpu_ns=-1,screen_gpu_ns=-1;
  std::uint64_t gpu_serial=0,gpu_discarded=0;
  int triangles=0,draw_calls=0,bytes_uploaded=0,width=0,height=0; bool gpu_timer_supported=false;
  int camera_instances=0,shadow_instances=0,instanced_draws=0,batched_draws=0,reference_draws=0;
  std::uint64_t pwr_baseline_objects=0,pwr_planned_objects=0,pwr_baseline_vertices=0,pwr_planned_vertices=0;
  std::uint64_t pwr_baseline_fragments=0,pwr_planned_fragments=0,pwr_baseline_bytes=0,pwr_planned_bytes=0;
  std::uint64_t reused_objects=0,changed_objects=0;
  int shadow_pass_avoided=0,scene_pass_avoided=0;
};
// This renderer owns only the physical presentation adapter. No second world state.
class Renderer {
 public:
  Renderer(); ~Renderer();
  void initialize();
  void resize(int width,int height);
  void configure(const Config&);
  DrawStats draw(const Packet&,std::uint64_t frame_serial);
  std::string capabilities() const;
 private: struct Impl; std::unique_ptr<Impl> impl_;
};
enum Metric {
  SERIAL=0,SOURCE_REVISION=1,BEGIN_NS=2,CPU_NS=3,QSSD_NS=4,VIRTUAL_GPU_NS=5,
  GEOMETRY_NS=6,DRAW_SUBMIT_NS=7,SWAP_NS=8,END_NS=9,GPU_NS=10,
  PRESENT_NS=11,PRESENT_ID=12,PRESENT_PENDING=13,PRESENT_LOST=14,
  OBJECTS=15,TRIANGLES=16,DRAW_CALLS=17,WORK_ITEMS=18,PHYSICS_STEPS=19,
  STATE_AGE_NS=20,INPUT_TO_SUBMIT_NS=21,RENDER_WIDTH=22,RENDER_HEIGHT=23,
  SURFACE_WIDTH=24,SURFACE_HEIGHT=25,CACHE_HITS=26,CACHE_MISSES=27,
  UPLOAD_BYTES=28,PRESENT_SUPPORTED=29,GPU_TIMER_SUPPORTED=30,CONTEXT_GENERATION=31,
  STATE_HASH=32,INPUT_EVENTS=33,PREPARED_REGIONS=34,HOT_REGION_BUILDS=35,
  BUDGET_NS=36,SWAP_SUCCEEDED=37,PRESENT_PROCESSED=38,PRESENT_DISCARDED=39,
  GPU_SAMPLE_ID=40,GPU_DISCARDED=41,
  AUDIO_HZ=42,AUDIO_GAIN=43,
  CAMERA_INSTANCES=44,SHADOW_INSTANCES=45,INSTANCED_DRAWS=46,BATCHED_DRAWS=47,
  REFERENCE_DRAWS=48,GRAPHICS_PATH=49,
  QUANTUM_GATES=50,QUANTUM_CIRCUITS=51,QUANTUM_QUBITS=52,QUANTUM_SIGNAL=53,
  SHADOW_GPU_NS=54,SCENE_GPU_NS=55,SCREEN_GPU_NS=56,
  PWR_BASELINE_OBJECTS=57,PWR_PLANNED_OBJECTS=58,PWR_BASELINE_VERTICES=59,PWR_PLANNED_VERTICES=60,
  PWR_BASELINE_FRAGMENTS=61,PWR_PLANNED_FRAGMENTS=62,PWR_BASELINE_BYTES=63,PWR_PLANNED_BYTES=64,
  REUSED_OBJECTS=65,CHANGED_OBJECTS=66,SHADOW_PASS_AVOIDED=67,SCENE_PASS_AVOIDED=68,
  METRIC_COUNT=80
};
} // namespace xlab
