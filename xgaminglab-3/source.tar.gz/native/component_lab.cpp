#include "component_lab.hpp"
#include "qssd/c12_bridge.hpp"
#include "qssd/state_bus.hpp"
#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstring>
#include <fcntl.h>
#include <iomanip>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <unistd.h>

namespace xlab {
namespace {
using Clock = std::chrono::steady_clock;
constexpr std::uint64_t fnv_prime = 1099511628211ULL;
const std::uint32_t xi_sizes[] = {64, 512, 4096, 16384, 65536};
const std::uint32_t lane_sizes[] = {256, 4096, 16384, 65536, 262144};
const unsigned bell_pairs[] = {1, 8, 32, 64, 128};
const unsigned ghz_widths[] = {3, 32, 128, 512, 1025};
const unsigned interference_rounds[] = {1, 8, 32, 128, 256};
const unsigned oracle_rounds[] = {1, 2, 4, 8, 16};
std::int64_t elapsed(Clock::time_point begin) {
  return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() -
                                                              begin)
      .count();
}
std::uint32_t bits(float v) {
  std::uint32_t n;
  std::memcpy(&n, &v, 4);
  return n;
}
float real(std::uint32_t v) {
  float f;
  std::memcpy(&f, &v, 4);
  return f;
}
void hash64(std::uint64_t &h, std::uint64_t n) {
  for (unsigned i = 0; i < 8; ++i) {
    h ^= (n >> (8 * i)) & 255;
    h *= fnv_prime;
  }
}
std::string hex(std::uint64_t n) {
  std::ostringstream o;
  o << std::hex << std::setw(16) << std::setfill('0') << n;
  return o.str();
}
std::string quote(const std::string &s) {
  std::ostringstream o;
  o << '"';
  for (unsigned char c : s) {
    if (c == '"' || c == '\\')
      o << '\\' << char(c);
    else if (c < 32)
      o << "\\u00" << std::hex << std::setw(2) << std::setfill('0')
        << unsigned(c) << std::dec;
    else
      o << char(c);
  }
  o << '"';
  return o.str();
}
std::string number(double v) {
  if (!std::isfinite(v))
    return "null";
  std::ostringstream o;
  o << std::setprecision(17) << v;
  return o.str();
}
void check(ComponentSubtest &s, bool ok, const std::string &what) {
  ++s.checks;
  if (!ok) {
    ++s.failures;
    s.passed = false;
    if (s.errors.size() < 16)
      s.errors.push_back(what);
  }
}
void exact(ComponentSubtest &s, std::uint64_t actual, std::uint64_t expected,
           const std::string &what) {
  hash64(s.checksum, actual);
  hash64(s.expected_checksum, expected);
  check(s, actual == expected, what);
}
void near(ComponentSubtest &s, double actual, double expected, double tolerance,
          const std::string &what) {
  const double e = std::abs(actual - expected);
  if (std::isfinite(e))
    s.max_error = std::max(s.max_error, e);
  else
    s.max_error = std::numeric_limits<double>::infinity();
  check(s, std::isfinite(actual) && e <= tolerance, what);
  if (std::isfinite(actual))
    hash64(s.checksum, std::uint64_t(std::llround((actual + 4) * 1e9)));
  hash64(s.expected_checksum,
         std::uint64_t(std::llround((expected + 4) * 1e9)));
}
template <class F>
void subtest(ComponentReport &r, const std::string &name,
             const std::string &unit, const std::string &scope, F f) {
  ComponentSubtest s;
  s.name = name;
  s.unit = unit;
  s.scope = scope;
  auto start = Clock::now();
  try {
    f(s);
  } catch (const std::exception &e) {
    check(s, false, std::string("exception: ") + e.what());
  } catch (...) {
    check(s, false, "unknown exception");
  }
  s.elapsed_ns = elapsed(start);
  r.checks += s.checks;
  r.failures += s.failures;
  r.passed = r.passed && s.passed;
  r.work_items += s.work_items;
  r.max_error = std::max(r.max_error, s.max_error);
  hash64(r.checksum, s.checksum);
  r.subtests.push_back(std::move(s));
}
std::uint32_t cpu_word(const qssd::Space &space, unsigned base) {
  const auto epoch = space.epoch();
  std::uint32_t word = 0;
  for (unsigned i = 0; i < 4; ++i) {
    auto b =
        epoch->cpu.memory().read(std::to_string(base + i), epoch->cpu.core());
    if (!b.deterministic)
      throw std::runtime_error("CPU read unexpectedly quantum");
    word |= std::uint32_t(b.value) << (8 * i);
  }
  return word;
}
std::uint32_t xi_oracle(std::uint32_t n, std::uint64_t seed) {
  std::uint32_t sum = 0;
  for (std::uint32_t i = 0; i < n; ++i) {
    const std::uint32_t v = (i * 97U + std::uint32_t(seed & 65535)) & 65535U;
    sum += v * v;
  }
  return sum;
}
std::string xi_program(std::uint32_t n, std::uint64_t seed, bool quantum) {
  std::ostringstream p;
  p << "#!reverse-pc-machine-v1\nset r0 0\nset r1 0\nlabel loop\nset r2 "
       "r0\nmul r2 97\nadd r2 "
    << (seed & 65535)
    << "\nmod r2 65536\nmul r2 r2\nadd r1 r2\nmod r1 4294967296\nadd r0 1\ncmp "
       "r0 "
    << n << "\njlt loop\nstore32 8192 r1\nmod r1 65536\n";
  if (quantum)
    p << "load32 r3 4112\nadd r1 r3\n";
  p << "store32 4096 r1\nstore32 4100 97\nhalt\n";
  return p.str();
}
void record_core(ComponentSubtest &s, const mundo_x::QuantumRuntime &rt) {
  auto c = rt.core().stats();
  auto q = rt.core().quantum_stats();
  s.sizes["activeQubitsPeak"] =
      std::max(s.sizes["activeQubitsPeak"], std::uint64_t(c.active_qubits));
  s.sizes["largestEntangledComponentPeak"] =
      std::max(s.sizes["largestEntangledComponentPeak"],
               std::uint64_t(c.largest_component));
  s.sizes["representationPayloadBytesPeak"] =
      std::max(s.sizes["representationPayloadBytesPeak"],
               std::uint64_t(q.payload_bytes));
  s.counters["coreRevision"] = c.revision;
  s.counters["cliffordComponents"] = q.clifford;
  s.counters["adaptiveComponents"] = q.adaptive;
  s.counters["reducedComponents"] = q.reduced;
  s.counters["TInstructionsRetained"] = q.t_gates;
  s.counters["storedFactorAmplitudes"] = q.amplitudes;
  s.counters["storedReducedCoefficients"] = q.coefficients;
  s.observations["norm"] = q.norm;
}
void gates(mundo_x::QuantumRuntime &runtime,
           const std::vector<std::string> &commands, ComponentSubtest &s) {
  std::string p = "begin\n";
  for (const auto &c : commands)
    p += c + '\n';
  p += "end\n";
  runtime.execute(p);
  s.work_items += commands.size();
  s.counters["gatesExecuted"] += commands.size();
  record_core(s, runtime);
}
xgpu::Kernel transform_kernel() {
  using O = xgpu::StateOp;
  return {{{O::Index, 0},
           {O::LoadGlobal, 1, 0},
           {O::FloatFromUnsigned, 1, 1},
           {O::Constant, 2, 0, 0, 0, bits(.125f)},
           {O::FloatMultiply, 3, 1, 2},
           {O::Constant, 4, 0, 0, 0, bits(3.5f)},
           {O::FloatAdd, 5, 3, 4},
           {O::FloatMultiply, 6, 5, 5},
           {O::StoreGlobal, 0, 0, 6},
           {O::Output, 6},
           {O::Halt}}};
}
xgpu::Kernel tile_kernel() {
  using O = xgpu::StateOp;
  return {{{O::Index, 0},
           {O::LocalIndex, 1},
           {O::LoadGlobal, 2, 0},
           {O::StoreShared, 0, 1, 2},
           {O::Barrier},
           {O::Constant, 3, 0, 0, 0, 63},
           {O::BitXor, 4, 1, 3},
           {O::LoadShared, 5, 4},
           {O::Output, 5},
           {O::Halt}}};
}
std::uint32_t transform_oracle(std::uint32_t input) {
  volatile float a = float(input);
  volatile float b = a * .125f;
  volatile float c = b + 3.5f;
  volatile float d = c * c;
  return bits(d);
}
void c12_run(qssd::Space &space, std::uint32_t n, std::uint32_t base,
             ComponentSubtest &s) {
  space.publish_cpu_rule("diagnostic", n, "4096", 2);
  space.bind("cpu:diagnostic", "diagnostic");
  space.route("cpu:diagnostic", "ssd:diagnostic");
  space.route("ssd:diagnostic", "gpu:diagnostic");
  auto lease = space.acquire("gpu:diagnostic");
  qssd::C12Window window(lease);
  check(s, window.source_pointer_preserved(),
        "GPU Virtual did not retain original immutable source pointer");
  const auto first = window.enqueue(transform_kernel(), n, 64);
  const auto second = window.enqueue(tile_kernel(), n, 64, 64, {first});
  check(s, window.run(), "GPU Virtual dispatch step budget exhausted");
  check(s,
        window.engine().dispatch(first).output_valid.full() &&
            window.engine().dispatch(second).output_valid.full(),
        "GPU Virtual output incomplete");
  xgpu::ValueReader a(window.engine().dispatch(first).output),
      b(window.engine().dispatch(second).output);
  for (std::uint32_t i = 0; i < n; ++i) {
    const auto original = std::uint32_t(base + i * 97U);
    const auto permuted = (i / 64) * 64 + ((i % 64) ^ 63U);
    const auto actual = a.at(i), expected = transform_oracle(original);
    const auto tile_actual = b.at(i),
               tile_expected =
                   transform_oracle(std::uint32_t(base + permuted * 97U));
    exact(s, actual, expected,
          "GPU Virtual float transform differs from independent host oracle");
    exact(s, tile_actual, tile_expected,
          "GPU Virtual shared tile crossed a workgroup or ignored dependency");
    const double error =
        std::max(std::abs(double(real(actual)) - real(expected)),
                 std::abs(double(real(tile_actual)) - real(tile_expected)));
    s.max_error = std::isfinite(error)
                      ? std::max(s.max_error, error)
                      : std::numeric_limits<double>::infinity();
  }
  const auto &c = window.engine().counters();
  s.counters["dispatches"] += 2;
  s.counters["executorSteps"] += c.steps;
  s.counters["logicalGlobalReads"] += c.global_reads;
  s.counters["logicalGlobalWrites"] += c.global_writes;
  s.counters["logicalSharedReads"] += c.shared_reads;
  s.counters["logicalSharedWrites"] += c.shared_writes;
  s.counters["barrierReleases"] += c.barrier_releases;
  s.counters["relationNodesCreated"] += c.relation_nodes_created;
  s.counters["scalarLaneEvaluations"] += c.scalar_lane_evaluations;
  s.counters["sharedSourceHandoffs"] += 1;
  s.sizes["lanes"] = n;
  s.sizes["groups"] = n / 64;
  s.sizes["localSize"] = 64;
  s.sizes["outputWordsObserved"] += 2ULL * n;
  s.work_items += 2ULL * n;
}
struct TemporaryFile {
  int fd = -1;
  std::string path;
  ~TemporaryFile() {
    if (fd >= 0)
      ::close(fd);
    if (!path.empty())
      ::unlink(path.c_str());
  }
};
std::string file_roundtrip(const std::string &bytes,
                           const std::string &directory, ComponentSubtest &s) {
  if (directory.empty())
    throw std::invalid_argument("A private checkpoint directory is required");
  std::string pattern = directory + "/xlab-qssd-XXXXXX";
  std::vector<char> path(pattern.begin(), pattern.end());
  path.push_back(0);
  TemporaryFile file;
  file.fd = ::mkstemp(path.data());
  if (file.fd < 0)
    throw std::runtime_error("Unable to create checkpoint file: " +
                             std::string(std::strerror(errno)));
  file.path = path.data();
  auto begin = Clock::now();
  std::size_t off = 0;
  while (off < bytes.size()) {
    const auto n = ::write(file.fd, bytes.data() + off, bytes.size() - off);
    if (n < 0 && errno == EINTR)
      continue;
    if (n <= 0)
      throw std::runtime_error("Checkpoint write failed");
    off += std::size_t(n);
  }
  if (::fsync(file.fd) != 0)
    throw std::runtime_error("Checkpoint fsync failed");
  s.counters["fileWriteNs"] = elapsed(begin);
  if (::close(file.fd) != 0)
    throw std::runtime_error("Checkpoint close failed");
  file.fd = -1;
  begin = Clock::now();
  file.fd = ::open(file.path.c_str(), O_RDONLY);
  if (file.fd < 0)
    throw std::runtime_error("Checkpoint reopen failed");
  std::string read;
  read.reserve(bytes.size());
  char buffer[8192];
  for (;;) {
    const auto n = ::read(file.fd, buffer, sizeof buffer);
    if (n < 0 && errno == EINTR)
      continue;
    if (n < 0)
      throw std::runtime_error("Checkpoint read failed");
    if (n == 0)
      break;
    if (read.size() + std::size_t(n) > 64U * 1024U * 1024U)
      throw std::runtime_error("Checkpoint read budget exceeded");
    read.append(buffer, std::size_t(n));
  }
  s.counters["fileReadNs"] = elapsed(begin);
  s.sizes["checkpointBytes"] = bytes.size();
  s.counters["fileBytesWritten"] = bytes.size();
  s.counters["fileBytesRead"] = read.size();
  s.counters["fsyncCalls"] = 1;
  check(s, read == bytes, "Filesystem checkpoint bytes changed");
  return read;
}
void xi_suite(ComponentReport &r, const ComponentRequest &request) {
  subtest(r, "XI integer vector reduction", "integer_vector_elements",
          "Original XI interpreter + InverseMemory; independent modular "
          "arithmetic oracle",
          [&](ComponentSubtest &s) {
            qssd::Space space;
            const auto n = xi_sizes[request.load];
            space.execute_cpu(xi_program(n, request.seed, false));
            const auto expected = xi_oracle(n, request.seed);
            exact(s, cpu_word(space, 8192), expected,
                  "XI vector reduction mismatch");
            exact(s, cpu_word(space, 4096), expected & 65535U,
                  "XI field coefficient mismatch");
            s.work_items = n;
            s.sizes["vectorElements"] = n;
            s.counters["runtimeProgramsExecuted"] = 1;
            s.counters["memoryRevision"] =
                space.epoch()->cpu.memory().stats().revision;
            s.counters["quantumGatesExecuted"] =
                space.epoch()->cpu.core().stats().revision;
            exact(s, s.counters["quantumGatesExecuted"], 0,
                  "Classical XI diagnostic unexpectedly mutated quantum state");
            const auto before = reverse_pc::rvpc2::save(space.epoch()->cpu);
            bool rejected = false;
            try {
              space.execute_cpu("#!reverse-pc-machine-v1\nstore32 8192 5\nset "
                                "r0 1\ndiv r0 0\nhalt\n");
            } catch (const std::exception &) {
              rejected = true;
            }
            check(s, rejected, "Invalid XI transaction accepted");
            check(s, reverse_pc::rvpc2::save(space.epoch()->cpu) == before,
                  "Failed XI transaction changed committed CPU state");
          });
}
void quantum_suite(ComponentReport &r, const ComponentRequest &request) {
  subtest(
      r, "Bell correlations and seeded measurement", "quantum_gates",
      "Original H/CX stabilizer evolution; Born measurement; snapshot RNG "
      "replay",
      [&](ComponentSubtest &s) {
        mundo_x::QuantumRuntime rt;
        rt.execute("seed " + std::to_string(request.seed) + "\n");
        std::vector<std::string> program;
        for (unsigned i = 0; i < bell_pairs[request.load]; ++i) {
          const auto a = std::to_string(2 * i), b = std::to_string(2 * i + 1);
          program.push_back("h " + a);
          program.push_back("cx " + a + " " + b);
        }
        gates(rt, program, s);
        s.sizes["bellPairs"] = bell_pairs[request.load];
        std::string measurements;
        for (unsigned i = 0; i < bell_pairs[request.load]; ++i) {
          const auto a = std::to_string(2 * i), b = std::to_string(2 * i + 1);
          near(s, rt.core().expectation({{a, 'X'}, {b, 'X'}}), 1, 1e-12,
               "Bell XX correlation");
          near(s, rt.core().expectation({{a, 'Z'}, {b, 'Z'}}), 1, 1e-12,
               "Bell ZZ correlation");
          near(s, rt.core().probability_one(a), .5, 1e-12, "Bell marginal");
          measurements += "measure " + a + "\nmeasure " + b + "\n";
        }
        const auto checkpoint = reverse_pc::rvpc2::save(rt);
        auto replay = reverse_pc::rvpc2::restore(checkpoint);
        auto output = rt.execute(measurements);
        check(s, replay.execute(measurements) == output,
              "Restored seeded quantum measurement sequence changed");
        std::mt19937_64 independent_rng(request.seed);
        for (unsigned i = 0; i < bell_pairs[request.load]; ++i) {
          const auto a = rt.core().z_determinism(std::to_string(2 * i)),
                     b = rt.core().z_determinism(std::to_string(2 * i + 1));
          check(s, a != 0 && a == b, "Bell measured outcomes not correlated");
          exact(s, a > 0 ? 0 : 1, independent_rng() & 1U,
                "Bell sample differs from independent seeded half-probability "
                "oracle");
        }
        s.counters["measurementsExecuted"] = 2 * bell_pairs[request.load];
        s.counters["snapshotRestores"] = 1;
        record_core(s, rt);
      });
  subtest(r, "GHZ and exact inverse", "quantum_gates",
          "Finite Clifford GHZ family; all-Z marginals, global-X correlation, "
          "inverse circuit",
          [&](ComponentSubtest &s) {
            mundo_x::QuantumRuntime rt;
            const auto width = ghz_widths[request.load];
            std::vector<std::string> p{"h 0"};
            for (unsigned i = 1; i < width; ++i)
              p.push_back("cx 0 " + std::to_string(i));
            gates(rt, p, s);
            std::vector<mundo_x::InfiniteCore::Term> all_x;
            for (unsigned i = 0; i < width; ++i) {
              const auto a = std::to_string(i);
              all_x.push_back({a, 'X'});
              near(s, rt.core().probability_one(a), .5, 1e-12, "GHZ marginal");
              if (i)
                near(s, rt.core().expectation({{"0", 'Z'}, {a, 'Z'}}), 1, 1e-12,
                     "GHZ correlated pair");
            }
            near(s, rt.core().expectation(all_x), 1, 1e-12,
                 "GHZ global-X coherence");
            p.clear();
            for (unsigned i = width - 1; i > 0; --i)
              p.push_back("cx 0 " + std::to_string(i));
            p.push_back("h 0");
            gates(rt, p, s);
            for (unsigned i = 0; i < width; ++i)
              near(s, rt.core().probability_one(std::to_string(i)), 0, 1e-12,
                   "GHZ inverse did not recover zero");
            s.sizes["ghzQubits"] = width;
            s.attributes["stateFamily"] =
                "Clifford GHZ, not arbitrary dense amplitudes";
          });
  subtest(r, "Non-Clifford T interference and inverse", "quantum_gates",
          "Original REVERSE-integrated QuantumBlock T/TDG over original Mundo "
          "core; small independent blocks",
          [&](ComponentSubtest &s) {
            mundo_x::QuantumRuntime rt;
            const double expected = std::sqrt(.5);
            for (unsigned i = 0; i < interference_rounds[request.load]; ++i) {
              const auto a = std::to_string(50000 + i);
              gates(rt, {"h " + a, "t " + a}, s);
              near(s, rt.core().expectation({{a, 'X'}}), expected, 2e-12,
                   "T interference X");
              near(s, rt.core().expectation({{a, 'Y'}}), expected, 2e-12,
                   "T interference Y");
              near(s, rt.core().expectation({{a, 'Z'}}), 0, 2e-12,
                   "T interference Z");
              near(s, rt.core().quantum_stats().norm, 1, 2e-11, "T state norm");
              gates(rt, {"tdg " + a, "h " + a}, s);
              near(s, rt.core().probability_one(a), 0, 2e-12, "T inverse");
            }
            s.sizes["independentOneQubitCircuits"] =
                interference_rounds[request.load];
            check(s, s.counters["TInstructionsRetained"] > 0,
                  "Non-Clifford instruction evidence absent");
            s.attributes["stateFamily"] = "Independent one-qubit non-Clifford "
                                          "blocks; no large dense-state claim";
          });
  subtest(r, "Two-qubit marked-state oracle", "quantum_gates",
          "Original H/X/CZ Grover iteration; chosen marked basis state has "
          "independently known deterministic output",
          [&](ComponentSubtest &s) {
            mundo_x::QuantumRuntime rt;
            const unsigned marked = unsigned(request.seed & 3);
            for (unsigned i = 0; i < oracle_rounds[request.load]; ++i) {
              const auto a = std::to_string(60000 + 2 * i),
                         b = std::to_string(60001 + 2 * i);
              std::vector<std::string> p{"h " + a, "h " + b};
              if (!(marked & 1))
                p.push_back("x " + a);
              if (!(marked & 2))
                p.push_back("x " + b);
              p.push_back("cz " + a + " " + b);
              if (!(marked & 1))
                p.push_back("x " + a);
              if (!(marked & 2))
                p.push_back("x " + b);
              for (const auto &cmd : std::vector<std::string>{
                       "h " + a, "h " + b, "x " + a, "x " + b,
                       "cz " + a + " " + b, "x " + a, "x " + b, "h " + a,
                       "h " + b})
                p.push_back(cmd);
              gates(rt, p, s);
              near(s, rt.core().probability_one(a), (marked & 1) ? 1 : 0, 1e-12,
                   "Marked oracle bit0");
              near(s, rt.core().probability_one(b), (marked & 2) ? 1 : 0, 1e-12,
                   "Marked oracle bit1");
            }
            s.sizes["oracleQubitsPerCircuit"] = 2;
            s.sizes["oracleCircuits"] = oracle_rounds[request.load];
            s.sizes["markedState"] = marked;
          });
}
void c12_suite(ComponentReport &r, const ComponentRequest &request) {
  subtest(r, "GPU Virtual transform and shared workgroup permutation",
          "output_words_verified",
          "Original CPU-produced field + GPU Virtual two dependent dispatches; "
          "binary32 affine/quadratic transform, 64-lane shared tiles/barriers",
          [&](ComponentSubtest &s) {
            qssd::Space space;
            const auto base = std::uint32_t(request.seed & 65535);
            space.execute_cpu("#!reverse-pc-machine-v1\nstore32 4096 " +
                              std::to_string(base) +
                              "\nstore32 4100 97\nhalt\n");
            c12_run(space, lane_sizes[request.load], base, s);
            s.counters["cpuRuleBytesObserved"] = space.cpu_rule_input_bytes();
          });
}
void qssd_suite(ComponentReport &r, const ComponentRequest &request) {
  subtest(
      r, "Immutable ports, snapshots and file restore", "field_words_verified",
      "Original Space aliases/revisions and StateBus versions; actual "
      "temporary file write/fsync/read/restore, OS cache may participate",
      [&](ComponentSubtest &s) {
        qssd::Space space;
        const auto n = lane_sizes[request.load],
                   base = std::uint32_t(request.seed & 65535);
        space.execute_cpu("#!reverse-pc-machine-v1\nstore32 4096 " +
                          std::to_string(base) + "\nstore32 4100 97\nhalt\n");
        space.publish_cpu_rule("data", n, "4096", 2);
        space.bind("cpu:data", "data");
        space.route("cpu:data", "ssd:data");
        space.route("ssd:data", "gpu:data");
        const auto old = space.acquire("gpu:data");
        check(s,
              old.field == space.acquire("cpu:data").field &&
                  old.field == space.acquire("ssd:data").field,
              "Port aliases copied original field");
        space.patch("cpu:data", n / 2, base ^ 0x51a37U);
        auto current = space.acquire("gpu:data");
        exact(s, old.at(n / 2), std::uint32_t(base + (n / 2) * 97U),
              "Pinned old lease mutated");
        check(s,
              current.identity == old.identity &&
                  current.revision == old.revision + 1,
              "QSSD identity/revision mismatch");
        struct Graph {
          qssd::FieldPtr field;
          std::uint64_t marker;
        };
        qssd::StateBus<Graph> bus(Graph{old.field, 0}, 4);
        auto initial = bus.snapshot();
        bus.bookmark("original", initial);
        bus.publish(Graph{current.field, 1}, "patch");
        auto branch = bus.fork();
        branch.publish(Graph{current.field, 2}, "independent-branch");
        exact(s, bus.snapshot()->value->marker, 1,
              "Fork overwrote parent graph");
        bus.rewind(initial->serial);
        check(s, bus.snapshot()->value->field == old.field,
              "Rewind lost pinned original resource");
        exact(s, bus.bookmark("original")->value->marker, 0,
              "Bookmark mutated");
        auto begin = Clock::now();
        auto checkpoint = space.checkpoint();
        s.counters["checkpointSerializeNs"] = elapsed(begin);
        const auto read = file_roundtrip(checkpoint, request.directory, s);
        begin = Clock::now();
        auto restored = qssd::Space::restore(read);
        s.counters["checkpointRestoreNs"] = elapsed(begin);
        check(s, restored.checkpoint() == checkpoint,
              "Checkpoint restore changed full authority");
        auto output = restored.acquire("gpu:data");
        check(s,
              output.field == restored.acquire("cpu:data").field &&
                  output.field == restored.acquire("ssd:data").field,
              "Restore broke alias topology");
        for (std::uint32_t i = 0; i < n; ++i)
          exact(s, output.at(i),
                i == n / 2 ? base ^ 0x51a37U : std::uint32_t(base + i * 97U),
                "Restored logical field changed");
        auto corrupt = checkpoint;
        corrupt[corrupt.size() / 2] ^= 1;
        bool rejected = false;
        try {
          (void)qssd::Space::restore(corrupt);
        } catch (const std::exception &) {
          rejected = true;
        }
        check(s, rejected, "Corrupt checkpoint accepted");
        check(s, space.checkpoint() == checkpoint,
              "Corrupt restore affected existing authority");
        s.work_items = n;
        s.sizes["logicalFieldWords"] = n;
        s.counters["snapshotRestores"] = 1;
        s.counters["corruptionsRejected"] = rejected ? 1 : 0;
        s.counters["stateBusSerial"] = bus.stats().serial;
        s.counters["cpuRuleBytesObserved"] = space.cpu_rule_input_bytes();
        s.counters["routedReferences"] = space.routed_references();
      });
  subtest(
      r, "Original simulated Bell byte transfer", "qubits_transferred",
      "Eight explicit original Bell protocols preserve an external entangled "
      "reference and old pinned QuantumGpuView; all execute on host CPU",
      [&](ComponentSubtest &s) {
        qssd::Space space;
        space.execute_cpu("seed " + std::to_string(request.seed) +
                          "\nh 100\nt 100\ncx 100 200\n");
        space.publish_quantum_byte("byte", "5000", "100");
        space.bind("cpu:byte", "byte");
        space.route("cpu:byte", "ssd:byte");
        space.route("ssd:byte", "gpu:byte");
        qssd::QuantumGpuView before(space.acquire("gpu:byte"));
        check(s, !before.quantum_byte().deterministic,
              "Quantum byte collapsed before transfer");
        const double expected = std::sqrt(.5);
        near(s, before.expectation({{"100", 'X'}, {"200", 'X'}}), expected,
             2e-12, "Initial quantum phase correlation");
        const auto receipts =
            space.teleport_quantum_byte("gpu:byte", "100", "300", "400");
        qssd::QuantumGpuView after(space.acquire("gpu:byte"));
        check(s,
              !after.quantum_byte().deterministic &&
                  after.quantum_byte().handle == "qbyte:5000@400",
              "Quantum binding failed to move");
        near(s, after.expectation({{"400", 'X'}, {"200", 'X'}}), expected,
             2e-12, "Transfer lost XX phase correlation");
        near(s, after.expectation({{"400", 'Z'}, {"200", 'Z'}}), 1, 2e-12,
             "Transfer lost entanglement");
        near(s, before.expectation({{"100", 'X'}, {"200", 'X'}}), expected,
             2e-12, "Old quantum lease changed");
        check(s, before.quantum_byte().handle == "qbyte:5000@100",
              "Pinned binding changed");
        auto saved = space.checkpoint();
        auto recovered = qssd::Space::restore(saved);
        qssd::QuantumGpuView resumed(recovered.acquire("gpu:byte"));
        near(s, resumed.expectation({{"400", 'X'}, {"200", 'X'}}), expected,
             2e-12, "Restored quantum phase changed");
        bool rejected = false;
        try {
          qssd::C12Window invalid(recovered.acquire("gpu:byte"));
        } catch (const std::exception &) {
          rejected = true;
        }
        check(s, rejected,
              "GPU Virtual silently treated quantum handle as classical data");
        unsigned corrections = 0;
        std::string receipt_bits;
        for (const auto &receipt : receipts) {
          corrections += unsigned(receipt.m0) + unsigned(receipt.m1);
          receipt_bits += receipt.m0 ? '1' : '0';
          receipt_bits += receipt.m1 ? '1' : '0';
        }
        s.attributes["measuredBellReceiptBits"] = receipt_bits;
        s.work_items = receipts.size();
        s.sizes["transferredQubits"] = receipts.size();
        s.sizes["externalReferenceQubits"] = 1;
        s.counters["bellMeasurements"] = 2 * receipts.size();
        s.counters["quantumGatesExecuted"] =
            3 + 4 * receipts.size() + corrections;
        s.counters["classicalCorrectionGates"] = corrections;
        record_core(s, recovered.epoch()->cpu);
      });
}
void integrated_suite(ComponentReport &r, const ComponentRequest &request) {
  subtest(
      r, "Quantum observable to XI to QSSD to GPU Virtual", "output_words_verified",
      "Original 1000-qubit structured GHZ+T state -> global-X observation -> XI Q10 "
      "coefficient -> original QSSD field -> dependent GPU Virtual transform; disk "
      "checkpoint restores quantum and classical authorities",
      [&](ComponentSubtest &s) {
        qssd::Space space;
        const auto quantum = prepare_scene_quantum(space, request.seed);
        near(s, quantum.xx, std::sqrt(.5), 2e-12,
             "Integrated observable mismatch");
        near(s, quantum.norm, 1, 2e-12, "Integrated norm");
        const auto n = xi_sizes[request.load];
        space.execute_cpu(xi_program(n, request.seed, true));
        const auto reduction = xi_oracle(n, request.seed);
        const auto projected =
            std::uint32_t(std::llround(std::sqrt(.5) * 1024));
        const auto base = (reduction & 65535U) + projected;
        exact(s, cpu_word(space, 8192), reduction,
              "Integrated XI vector result");
        exact(s, cpu_word(space, 4096), base,
              "Quantum observation did not reach XI field coefficient");
        c12_run(space, lane_sizes[request.load], base, s);
        const auto checkpoint = space.checkpoint();
        auto restored = qssd::Space::restore(
            file_roundtrip(checkpoint, request.directory, s));
        check(s, restored.checkpoint() == checkpoint,
              "Integrated complete restore mismatch");
        qssd::QuantumGpuView quantum_restored(
            restored.acquire("gpu:scene-quantum"));
        std::vector<mundo_x::InfiniteCore::Term> restored_all_x;
        restored_all_x.reserve(1000);
        for (int i = 0; i < 1000; ++i)
          restored_all_x.push_back({std::to_string(100000 + i), 'X'});
        near(s, quantum_restored.expectation(restored_all_x), quantum.xx, 2e-12,
             "Integrated restored quantum correlation");
        exact(
            s,
            restored.acquire("gpu:diagnostic").at(lane_sizes[request.load] - 1),
            std::uint32_t(base + (lane_sizes[request.load] - 1) * 97U),
            "Restored GPU Virtual source field changed");
        s.counters["quantumGatesExecuted"] = quantum.gates;
        s.counters["quantumCircuitsExecuted"] = quantum.circuits;
        s.sizes["quantumQubits"] = quantum.qubits;
        s.sizes["xiVectorElements"] = n;
        s.counters["quantumObservableQ10"] = quantum.projected_q10;
        s.observations["quantumXX"] = quantum.xx;
        s.counters["cpuRuleBytesObserved"] = space.cpu_rule_input_bytes();
      });
}
} // namespace

SceneQuantumSignal prepare_scene_quantum(qssd::Space &space, std::uint64_t seed,
                                         bool phase_gate) {
  constexpr int width = 1000;
  constexpr int base = 100000;
  for (int i = 0; i < width; ++i) {
    if (space.epoch()->cpu.core().z_determinism(std::to_string(base + i)) != 1)
      throw std::invalid_argument("Scene quantum initializer requires fresh zero qubits");
  }
  const auto before = space.epoch()->cpu.core().stats().revision;
  std::ostringstream program;
  program << "seed " << seed << "\nh " << base << "\n";
  if (phase_gate) program << "t " << base << "\n";
  for (int i = 1; i < width; ++i)
    program << "cx " << base << ' ' << (base + i) << "\n";
  space.execute_cpu(program.str());
  space.publish_quantum_byte("scene-quantum", "9000", std::to_string(base));
  space.bind("cpu:scene-quantum", "scene-quantum");
  space.route("cpu:scene-quantum", "ssd:scene-quantum");
  space.route("ssd:scene-quantum", "gpu:scene-quantum");
  qssd::QuantumGpuView view(space.acquire("gpu:scene-quantum"));
  std::vector<mundo_x::InfiniteCore::Term> all_x;
  all_x.reserve(width);
  for (int i = 0; i < width; ++i)
    all_x.push_back({std::to_string(base + i), 'X'});
  SceneQuantumSignal out;
  out.gates = space.epoch()->cpu.core().stats().revision - before;
  out.circuits = 1;
  out.qubits = int(space.epoch()->cpu.core().stats().active_qubits);
  out.xx = view.expectation(all_x);
  out.norm = space.epoch()->cpu.core().quantum_stats().norm;
  if (!std::isfinite(out.xx) || out.xx < -.0000001 || out.xx > 1.0000001)
    throw std::runtime_error("Invalid scene quantum observation");
  out.projected_q10 =
      std::uint32_t(std::llround(std::clamp(out.xx, 0., 1.) * 1024));
  space.execute_cpu("#!reverse-pc-machine-v1\nstore32 4112 " +
                    std::to_string(out.projected_q10) + "\nhalt\n");
  return out;
}

std::string ComponentReport::json() const {
  std::ostringstream o;
  o << "{\"schema\":\"x-gaming-lab-components-v2\",\"name\":" << quote(name)
    << ",\"kind\":" << kind << ",\"load\":" << load << ",\"seed\":" << seed
    << ",\"passed\":" << (passed ? "true" : "false") << ",\"checks\":" << checks
    << ",\"failures\":" << failures << ",\"workItems\":" << work_items
    << ",\"unit\":" << quote(unit) << ",\"checksum\":" << quote(hex(checksum))
    << ",\"maxError\":" << number(max_error) << ",\"elapsedNs\":" << elapsed_ns
    << ",\"scope\":" << quote(scope) << ",\"subtests\":[";
  bool first = true;
  for (const auto &s : subtests) {
    if (!first)
      o << ',';
    first = false;
    o << "{\"name\":" << quote(s.name)
      << ",\"passed\":" << (s.passed ? "true" : "false")
      << ",\"checks\":" << s.checks << ",\"failures\":" << s.failures
      << ",\"workItems\":" << s.work_items << ",\"unit\":" << quote(s.unit)
      << ",\"checksum\":" << quote(hex(s.checksum))
      << ",\"expectedChecksum\":" << quote(hex(s.expected_checksum))
      << ",\"maxError\":" << number(s.max_error)
      << ",\"elapsedNs\":" << s.elapsed_ns << ",\"scope\":" << quote(s.scope);
    auto ints = [&](const char *name, const auto &values) {
      o << ",\"" << name << "\":{";
      bool f = true;
      for (const auto &[key, value] : values) {
        if (!f)
          o << ',';
        f = false;
        o << quote(key) << ':' << value;
      }
      o << '}';
    };
    ints("sizes", s.sizes);
    ints("counters", s.counters);
    o << ",\"observations\":{";
    bool f = true;
    for (const auto &[key, value] : s.observations) {
      if (!f)
        o << ',';
      f = false;
      o << quote(key) << ':' << number(value);
    }
    o << "},\"attributes\":{";
    f = true;
    for (const auto &[key, value] : s.attributes) {
      if (!f)
        o << ',';
      f = false;
      o << quote(key) << ':' << quote(value);
    }
    o << "},\"errors\":[";
    for (std::size_t i = 0; i < s.errors.size(); ++i) {
      if (i)
        o << ',';
      o << quote(s.errors[i]);
    }
    o << "]}";
  }
  o << "]}";
  return o.str();
}
ComponentReport run_component(const ComponentRequest &request) {
  const char *names[] = {"CPU XI", "Quantum core", "GPU Virtual",
                         "QSSD state and storage", "Integrated chain"};
  ComponentReport r;
  r.kind = request.kind;
  r.load = request.load;
  r.seed = request.seed;
  r.name = request.kind >= 0 && request.kind < 5 ? names[request.kind]
                                                 : "Invalid component";
  r.unit = request.kind == XI        ? "integer_vector_elements"
           : request.kind == QUANTUM ? "quantum_gates"
           : request.kind == GPU_VIRTUAL || request.kind == INTEGRATED
               ? "output_words_verified"
               : "mixed_subtest_items";
  r.scope = "Bounded deterministic diagnostics of original host-CPU "
            "components. No physical quantum hardware, quantum speedup, "
            "physical GPU throughput or raw SSD bandwidth claim.";
  const auto start = Clock::now();
  if (request.kind < 0 || request.kind > 4 || request.load < 0 ||
      request.load > 4)
    subtest(r, "Request validation", "requests", "No workload executed",
            [](ComponentSubtest &s) {
              check(s, false, "kind and load must be within 0..4");
            });
  else if (request.kind == XI)
    xi_suite(r, request);
  else if (request.kind == QUANTUM)
    quantum_suite(r, request);
  else if (request.kind == GPU_VIRTUAL)
    c12_suite(r, request);
  else if (request.kind == QSSD)
    qssd_suite(r, request);
  else
    integrated_suite(r, request);
  r.elapsed_ns = elapsed(start);
  return r;
}
std::string component_capabilities() {
  return R"JSON({"schema":"x-gaming-lab-components-v3","configured":{"loadLevels":5,"seedDefault":37,"boundedBatches":true,"cancellation":"between batches","physicalQuantumHardware":false,"quantumGpuGateExecution":false},"activeInScenes":{"quantumCore":"original 1000-qubit structured GHZ+T circuit once per configure; global-X observation projected explicitly to XI Q10 coefficient","cpu":"original XI controls, world state and revision authoring","qssd":"original immutable state authority plus retained graphics-work revisions","gpuVirtual":"original executable relations plus physical-work plan: visibility, compact representation, delta dependencies and reuse decisions","physicalGpu":"GLES rasterization only for work surviving the plan"},"activeInDiagnostics":{"XI":"integer reduction and transactional failure rollback","QUANTUM":"Bell correlations/seeded measurement; GHZ up to 1025 qubits and inverse; non-Clifford T/TDG interference; marked-state oracle","GPU_VIRTUAL":"two dependent original dispatches, binary32 affine/quadratic transform, shared-memory permutation/barriers and physical-work planning","QSSD":"immutable aliases, leases, StateBus fork/rewind, corruption rejection, file checkpoint, Bell byte transfer and graphics-work revisions","INTEGRATED":"quantum observable -> XI state/revisions -> GPU Virtual plan -> QSSD immutable work state -> physical renderer"},"loadSizes":{"xiVectorElements":[64,512,4096,16384,65536],"gpuVirtualLanes":[256,4096,16384,65536,262144],"bellPairs":[1,8,32,64,128],"ghzQubits":[3,32,128,512,1025],"oneQubitInterferenceCircuits":[1,8,32,128,256],"twoQubitOracleCircuits":[1,2,4,8,16],"sceneQuantumQubits":1000,"sceneActors":[24,80,240,2400,12000],"sceneEffects":[96,320,960,6000,24000]},"representationScope":"Large GHZ/Bell cases use the core's structured representation; they are not dense arbitrary 2^N-amplitude arrays. No hidden qubit reduction is performed by the diagnostic. Physical rendering remains conventional GLES hardware work after GPU Virtual filtering/compaction.","originals":{"mundoX":"1f925786522aba91f72707ad1638a8edcdd31a8f","reverseIntegration":"166fd1a5ebc41feb9407647fe8e45ad71cf47147","qssd":"376b1334dd2dde6093a2988ee12325590941573d","gpuVirtual":"f828a28468e73bf2f517d45080e11383bd14ba5c"}})JSON";
}
} // namespace xlab
